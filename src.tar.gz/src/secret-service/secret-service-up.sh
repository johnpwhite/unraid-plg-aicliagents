#!/bin/bash
source "$(dirname "${BASH_SOURCE[0]}")/../scripts/storage/resolve_paths.sh" || { echo 'resolve_paths.sh missing' >&2; exit 1; }
# secret-service-up.sh — idempotent per-user bring-up of the AICliAgents Secret
# Service (Bug #1042 / docs/specs/SECRET_SERVICE.md).
#
# Starts a private D-Bus session bus plus the keyring daemon for the calling
# user, reused across that user's agent sessions. Keyring-using agents (e.g.
# Antigravity CLI) can then persist their auth token instead of re-prompting
# every session.
#
# Usage:  secret-service-up.sh <user> <home_dir>
# Output: the session-bus address on stdout (unix:path=...) on success.
# Exit:   0 on success, non-zero on failure — callers proceed without it and
#         the agent simply falls back to interactive auth.
set -u

USER_NAME="${1:-$(whoami)}"
HOME_DIR="${2:-$HOME}"

PLUGIN="/usr/local/emhttp/plugins/unraid-aicliagents"
DAEMON="$PLUGIN/src/secret-service/secret-service-daemon"
SS_BASE="${MOUNT_ROOT}/secret-service"
RTDIR="$SS_BASE/$USER_NAME"
SOCK="$RTDIR/bus"
ADDR="unix:path=$SOCK"
STORE="$HOME_DIR/.local/share/aicli-keyring/keyring.json"
BUS_PID="$RTDIR/bus.pid"
DAEMON_PID="$RTDIR/daemon.pid"
LOG="$RTDIR/daemon.log"

# #337: the shared spawn helper — new session, stdin /dev/null, own log, no
# inherited descriptor. Both daemons below outlive this script.
# shellcheck source=src/scripts/aicli-detach.sh
. "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/../scripts/aicli-detach.sh"

[ -x "$DAEMON" ] || { echo "secret-service: daemon binary missing or not executable: $DAEMON" >&2; exit 1; }
command -v dbus-daemon >/dev/null 2>&1 || { echo "secret-service: dbus-daemon not on PATH" >&2; exit 1; }

# Runtime base is world-writable so non-root agent users can create their own
# per-user subdir; the per-user dir itself is private (0700).
mkdir -p "$SS_BASE" 2>/dev/null
chmod 0777 "$SS_BASE" 2>/dev/null
mkdir -p "$RTDIR" 2>/dev/null
chmod 0700 "$RTDIR" 2>/dev/null

_alive() {
    # GitHub #7: a bare kill -0 trusts a recycled PID. Unraid recycles PIDs
    # fast, so a dead daemon's old PID can already belong to another process,
    # which this would then wrongly call "alive". Confirm the live process
    # still runs the expected binary before trusting the PID.
    local p expected cmd
    p=$(cat "$1" 2>/dev/null) || return 1
    [ -n "$p" ] || return 1
    kill -0 "$p" 2>/dev/null || return 1
    case "$1" in
        *bus.pid) expected="dbus-daemon" ;;
        *daemon.pid) expected="secret-service-daemon" ;;
        *) return 0 ;;
    esac
    cmd=$(tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null)
    [[ "$cmd" == *"$expected"* ]]
}

# Fast path — already running for this user.
if [ -S "$SOCK" ] && _alive "$BUS_PID" && _alive "$DAEMON_PID"; then
    echo "$ADDR"
    exit 0
fi

# Serialise bring-up so two concurrent sessions don't race two buses onto the
# same socket path.
exec 9>"$RTDIR/.up.lock"
flock 9

# Re-check under the lock — another session may have just brought it up.
if [ -S "$SOCK" ] && _alive "$BUS_PID" && _alive "$DAEMON_PID"; then
    echo "$ADDR"
    exit 0
fi

# #827: both daemons outlive the agent session that starts them, so they get a
# clean environment. Before, they kept the session's BINARY=, NODE_PATH= and
# AGENT_ID=, which name the agent's install tree, and the version release step
# read them as "this agent is in use" until a reboot.
SS_ENV=(env -i "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin" "HOME=$HOME_DIR" "USER=$USER_NAME" "LANG=${LANG:-C}")

# Clear any stale remnants.
_alive "$DAEMON_PID" && kill "$(cat "$DAEMON_PID" 2>/dev/null)" 2>/dev/null
_alive "$BUS_PID" && kill "$(cat "$BUS_PID" 2>/dev/null)" 2>/dev/null
rm -f "$SOCK" "$BUS_PID" "$DAEMON_PID" 2>/dev/null

# Private session bus at a fixed, predictable address.
# dbus-daemon forks itself; run it with every inherited fd above 2 closed so
# the forked bus keeps none of the caller's descriptors (#337).
aicli_run_closed "${SS_ENV[@]}" dbus-daemon --session --address="$ADDR" --nopidfile --fork --print-pid >"$BUS_PID" 2>/dev/null
_i=0
while [ ! -S "$SOCK" ] && [ "$_i" -lt 25 ]; do sleep 0.2; _i=$((_i + 1)); done
[ -S "$SOCK" ] || { echo "secret-service: session bus did not start" >&2; exit 1; }

# Keyring daemon on that bus — detached so it outlives this session and is
# reused by the user's next agent launch. It writes DAEMON_PID once it owns
# org.freedesktop.secrets, which doubles as the readiness signal below.
mkdir -p "$(dirname "$STORE")" 2>/dev/null
aicli_detach --log "$LOG" -- "${SS_ENV[@]}" "DBUS_SESSION_BUS_ADDRESS=$ADDR" "$DAEMON" --store "$STORE" --pidfile "$DAEMON_PID" >/dev/null

_i=0
while [ "$_i" -lt 25 ]; do
    if _alive "$DAEMON_PID"; then
        echo "$ADDR"
        exit 0
    fi
    sleep 0.2
    _i=$((_i + 1))
done
echo "secret-service: daemon did not claim org.freedesktop.secrets" >&2
exit 1
