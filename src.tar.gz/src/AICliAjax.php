<?php
/**
 * <module_context>
 *     <name>AICliAjax</name>
 *     <description>Thin AJAX dispatcher routing actions to focused handler classes.</description>
 *     <dependencies>AICliAgentsManager, ValidationService, TerminalHandler, StorageHandler, AgentHandler, UtilityHandler</dependencies>
 *     <constraints>Under 100 lines. Shared middleware only: CSRF, error handling, time limits.</constraints>
 * </module_context>
 */
ob_start(); // Absorb any stray output from included files before JSON is emitted
error_reporting(E_ALL);
ini_set('display_errors', '0');
set_time_limit(30);

// Forgejo #367: pin this request to ONE plugin generation. `src` is a link
// that an update repoints at any moment. Resolve it once, here, and load every
// file through the result. Two includes through the link can land in two
// generations and declare a class twice (a fatal "Cannot redeclare class").
// clearstatcache drops a stale cached answer for the link (PHP keeps resolved
// paths for up to 120 s in a php-fpm worker).
// The pin comes FIRST. No file is loaded before it.
if (!defined('AICLI_GEN_SRC')) {
    clearstatcache(true, '/usr/local/emhttp/plugins/unraid-aicliagents/src');
    define('AICLI_GEN_SRC', realpath('/usr/local/emhttp/plugins/unraid-aicliagents/src') ?: '/usr/local/emhttp/plugins/unraid-aicliagents/src');
}
// The shutdown handler needs this pure decision class. Load it from the pinned
// generation. The manager below loads the same file by __DIR__, so
// require_once skips it there.
require_once AICLI_GEN_SRC . '/includes/services/ValidationService.php';

// Fatal Error Handler
register_shutdown_function(function() {
    // A fatal error can stop the page before the manager loads SecretPaths.
    // The handler loads no file. It uses the state folder from the environment
    // and falls back to the default folder when the class is not loaded yet.
    if (!class_exists('AICliAgents\\Services\\ValidationService', false)) {
        return;
    }
    $fatal = \AICliAgents\Services\ValidationService::fatalErrorResponse(error_get_last());
    if ($fatal !== null) {
        if (class_exists('AICliAgents\\Services\\SecretPaths', false)) {
            $stateRoot = \AICliAgents\Services\SecretPaths::stateRoot();
        } else {
            $envRoot = getenv('AICLI_STATE_ROOT');
            $stateRoot = ($envRoot !== false && $envRoot !== '') ? rtrim($envRoot, '/') : '/tmp/unraid-aicliagents';
        }
        $logFile = $stateRoot . '/debug.log';
        @file_put_contents($logFile, "[" . date("Y-m-d H:i:s") . "] " . $fatal['log'] . "\n", FILE_APPEND);
        if (!headers_sent()) {
            header('Content-Type: application/json');
            echo json_encode($fatal['body']);
        }
    }
});
// Forgejo #835 (docs/specs/AJAX_START_UP_COST.md): the Manager registers the class loader (includes/Autoload.php).
// A handler, a service or a helper loads when the request first uses it, so a request compiles only what it needs.
// No handler is required here.

// Forgejo #422 (docs/specs/NOTEBOOK_LEAN_BOOT.md): a Notebook read answers after a small start-up. The full start-up
// below is about 6 MB of PHP that the server compiles on every request (it has no opcache).
$aicliLean = isset($_GET['action']) && \AICliAgents\Services\ValidationService::isLeanNotebookRead($_GET['action']);
if ($aicliLean) {
    require_once AICLI_GEN_SRC . '/includes/NotebookLeanBoot.php';
} else {
require_once AICLI_GEN_SRC . '/includes/AICliAgentsManager.php';
}
use AICliAgents\Services\ValidationService;

// R-176: a storage or history change comes as POST, with the action and the parameters in the body, so
// the CSRF token is never in a URL. The handlers read $_GET, so the body fields fill the keys the query
// does not have. local_prepend.php has already checked the token of the POST.
if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? '')) === 'POST'
    && in_array((string)($_GET['action'] ?? $_POST['action'] ?? ''), ValidationService::POST_ONLY_ACTIONS, true)) {
    foreach ($_POST as $postKey => $postVal) {
        if (!isset($_GET[$postKey])) $_GET[$postKey] = $postVal;
    }
}

if (isset($_GET['action'])) {
    // NOTEBOOK_HANG_OBSERVABILITY.md R2: time the whole request.
    $ajaxT0 = \AICliAgents\Services\PerfTrace::start();
    $action = $_GET['action'];
    // External Relay MCP is bearer-authenticated JSON-RPC, not browser AJAX.
    // It must bypass CSRF only for this one dedicated endpoint.
    if ($action === 'relay_http_mcp') {
        ob_end_clean();
        require AICLI_GEN_SRC . '/AICliRelayMcp.php';
        exit;
    }
    if ($action !== 'filetree') {
        header('Content-Type: application/json');
    }

    // R-176: a changing storage or history action is refused as GET (the token would sit in the URL).
    $methodRefusal = ValidationService::methodRefusal($action, $_SERVER['REQUEST_METHOD'] ?? null);
    if ($methodRefusal !== null) {
        aicli_log("Refused action $action: not a POST request", AICLI_LOG_WARN, "AICliAjax");
        ob_end_clean();
        echo json_encode(['status' => 'error', 'message' => $methodRefusal]);
        exit;
    }

    // WORKSPACE_UPLOAD_MULTI_CHUNKED.md R5: PHP silently drops a POST body
    // bigger than post_max_size and empties $_POST — that would otherwise
    // fail the CSRF check below and hide the real cause behind "Invalid CSRF
    // Token". Catch it here, before CSRF, for the two upload actions only.
    // The decision is ValidationService::uploadOversizeRefusal() (unit tested with the four actions,
    // the Content-Length and the empty $_POST).
    if (in_array($action, ValidationService::UPLOAD_ACTIONS, true)) {
        $oversize = ValidationService::uploadOversizeRefusal(
            $action, $_SERVER, $_POST, \AICliAgents\Handlers\UtilityHandler::getUploadLimits()['post_max_bytes']);
        if ($oversize !== null) {
            aicli_log($oversize['log'], AICLI_LOG_ERROR, "AICliAjax");
            ob_end_clean();
            echo json_encode(['status' => 'error', 'message' => $oversize['message']]);
            exit;
        }
    }

    // #515: the browser sends upload data as URL-safe base64 (enc=b64url).
    // Standard base64 in a URL-encoded form grows each '+' and '/' to 3 bytes,
    // so a full chunk of a binary file passed post_max_size, PHP dropped the
    // form and Unraid answered with HTML. (Multipart is no way out: it hangs on
    // Unraid's nginx, D-405.) Turn it back into standard base64 here, once,
    // for the handlers' strict base64_decode. A request without enc is left alone.
    // The decision is UtilityHandler::decodeUploadBody() (unit tested). NotebookHandler reads $_REQUEST.
    // A lean Notebook read is no upload action, so it has nothing to decode (and UtilityHandler is not loaded).
    foreach ($aicliLean ? [] : \AICliAgents\Handlers\UtilityHandler::decodeUploadBody($action, $_POST) as $b64Key => $b64Val) {
        $_POST[$b64Key] = $b64Val;
        $_REQUEST[$b64Key] = $b64Val;
    }

    // Validate session ID
    $rawId = $_GET['id'] ?? 'default';
    $id = ValidationService::validateId($rawId) ?: 'default';

    // S4 (REVIEW_2026-09-13_EVENTS_AND_SECURITY.md#S4): a short, explicit list of
    // read-only actions that a browser fetches as a raw byte stream, not JSON —
    // for example an <audio src> for a voice clip. Such a request cannot carry a
    // CSRF token (the tag has no way to add a header or a form field), and it is
    // safe to exempt: the resource id is unguessable and expiring, and the
    // session cookie still applies. A write action must NEVER appear here.
    // notebook_asset: a media tag cannot send a token. Read only, path validated to the
    // notebook's assets/ folder (NotebookHandler::rawAsset, NotebookService::assetPath).

    // CSRF Validation — see PLUGIN_STANDARDS.md Lesson 3.
    // local_prepend.php (auto_prepend_file) validates CSRF from $_POST or X-CSRF-TOKEN
    // header for POST requests, then unsets them. We re-check here from $_REQUEST
    // (which retains the GET copy) so GET-based callers also pass.
    // The decision is ValidationService::csrfDecision() (unit tested): an exempt raw read is never
    // refused, every other action needs the server token. S10: its log line names the action and
    // says only whether a token arrived. It never holds the expected or the received token.
    $var = ValidationService::isCsrfExemptRead($action) ? [] : @parse_ini_file("/var/local/emhttp/var.ini");
    $csrf =ValidationService::csrfDecision($action, trim((string)($var['csrf_token'] ?? '')), $_REQUEST, $_SERVER);
    if ($csrf['refusal'] !== null) {
        aicli_log((string)$csrf['log'], AICLI_LOG_ERROR, "AICliAjax");
        ob_end_clean();
        echo json_encode(['status' => 'error', 'message' => $csrf['refusal']]);
        exit;
    }

    // R-06 trace correlation: adopt the client's X-Aicli-Trace header (or the
    // `trace` query param — the React ajaxUrl() builder can't set headers), else
    // generate a fresh 8-hex id. Format-validated by TraceContext::setId, so a
    // hostile value can never reach a log line or a shell env prefix. Every
    // aicli_log line below (including "Handling AJAX Request") carries [t:<id>].
    $rawTrace = (string)($_SERVER['HTTP_X_AICLI_TRACE'] ?? ($_REQUEST['trace'] ?? ''));
    if (!\AICliAgents\Services\TraceContext::setId($rawTrace)) {
        \AICliAgents\Services\TraceContext::setId(\AICliAgents\Services\TraceContext::generate());
    }

    // R2: one end-of-request line, for every request, also one that ends in an exception or in a raw
    // handler that calls exit. The flag keeps it to one line. A request of 2000 ms or more also writes
    // the perf stage ajax.slow and a WARN line. Both only while the setting perf_trace is on. A trace never throws.
    $ajaxDone = false;
    $ajaxFinish = function () use (&$ajaxDone, &$action, &$id, $ajaxT0): void {
        if ($ajaxDone) return;
        $ajaxDone = true;
        try {
            $safeName = preg_replace('/[^a-zA-Z0-9_.-]/', '', substr((string)(is_scalar($action) ? $action : ''), 0, 64));
            // Off by default (NOTEBOOK_HANG_OBSERVABILITY.md R12): no trace line and no AJAX done line
            // unless the Debug Console switch "Performance trace" is on.
            if (\AICliAgents\Services\PerfTrace::enabled()) {
                $ms = \AICliAgents\Services\PerfTrace::point('ajax.slow', $ajaxT0, 2000, "action=$safeName");
                aicli_log("AJAX done: $safeName ($id) ms=$ms", AICLI_LOG_DEBUG, "AICliAjax");
            }
        } catch (\Throwable $e) {
            // A trace must never break the request it measures.
        }
    };
    register_shutdown_function($ajaxFinish);

    try {
        // Log milestone actions at INFO, everything else at DEBUG.
        // The workspace-menu actions are milestones too: they are things a PERSON
        // did, and at DEBUG they were invisible — on 2026-09-11 a continue arrived
        // that the operator did not expect, and the request that sent it left no
        // line at all at the default log level. continue_session additionally
        // records who asked (TerminalHandler::recordContinue).
        $milestones = ['start', 'stop', 'restart', 'install_agent', 'uninstall_agent', 'consolidate_storage', 'convert_storage', 'remove_old_versions', 'clear_home_caches', 'history_move', 'history_bring_back', 'remove_leftover', 'clean_agent_tmp', 'boot_archive_start', 'boot_restore_start', 'persist_home', 'repair_agent_storage', 'repair_home_storage', 'save', 'wipe_storage',
            'continue_session', 'graceful_close', 'restart_fresh', 'reload_onto_current', 'refresh_bridge', 'workspace_export', 'stop_unreachable', 'view_unreachable'];
        $logLvl = in_array($action, $milestones) ? AICLI_LOG_INFO : AICLI_LOG_DEBUG;
        aicli_log("Handling AJAX Request: $action ($id)", $logLvl, "AICliAjax");

        // D-405: Increase limits for file upload actions (base64 POST data can be large).
        // VOICE_INPUT.md R2: voice_transcribe posts a base64 clip up to 4 MiB
        // decoded (~5.4 MB base64) and its own engine call can take up to 30s,
        // so it shares this same allowance.
        if (in_array($action, ['save_file', 'save_file_chunk', 'save_pasted_image', 'voice_transcribe', 'notebook_asset_upload', 'notebook_import'])) {
            @ini_set('post_max_size', '64M');
            @ini_set('upload_max_filesize', '64M');
            set_time_limit(120);
        }

        // Initialize environment (skip mount for non-mount actions)
        $mustMountActions = ['start', 'restart', 'install_agent', 'uninstall_agent', 'migrate_agents'];
        // A lean Notebook read skips the plugin self-heal (supervisor check, boot sweep): every other action and the
        // page itself run it, and a Notebook read must not pay for it.
        if (!$aicliLean) {
            aicli_ensure_init(!in_array($action, $mustMountActions));
        }

        // Route to handler - raw output actions first
        if ($action === 'filetree') {
            ob_end_clean();
            \AICliAgents\Handlers\UtilityHandler::rawFiletree();
        } elseif ($action === 'get_install_status') {
            ob_end_clean();
            \AICliAgents\Handlers\AgentHandler::rawInstallStatus();
        } elseif ($action === 'diag_bundle_download') {
            // R-08: raw zip stream (path-traversal guarded basename under the
            // support dir — see DiagnosticsHandler::safeBundleName).
            ob_end_clean();
            \AICliAgents\Handlers\DiagnosticsHandler::rawBundleDownload();
        } elseif ($action === 'workspace_export_download') {
            // T-11: raw tar.gz stream (path-traversal guarded basename under
            // the bundles dir — see BundleHandler::safeBundleName).
            ob_end_clean();
            \AICliAgents\Handlers\BundleHandler::rawBundleDownload();
        } elseif ($action === 'voice_clip') {
            // AGENT_VOICE.md: raw mp3 stream (id shape-validated in the handler
            // against /^v_[0-9a-f]{16}$/ before it ever reaches a path).
            ob_end_clean();
            \AICliAgents\Handlers\VoiceHandler::rawVoiceClip();
        } elseif ($action === 'notebook_asset') {
            // ARTEFACTS_CONTRACT.md section 5: raw image/video/audio/pdf from the notebook's
            // assets/ folder; the path is validated inside the handler. CSRF-exempt (read only).
            ob_end_clean();
            \AICliAgents\Handlers\NotebookHandler::rawAsset();
        } elseif ($action === 'notebook_export') {
            // Raw download. NOT CSRF-exempt: the link carries csrf_token in its query, like
            // workspace_export_download.
            ob_end_clean();
            \AICliAgents\Handlers\NotebookHandler::rawExport();
        } elseif ($action === 'get_task_status') {
            // Task status file is already JSON - read and output directly.
            // SECURITY: $user gets interpolated into a filesystem path so
            // validate before use. Accept only POSIX-ish usernames or the
            // literal "agents" sentinel.
            $user = $_GET['user'] ?? '';
            if (empty($user)) {
                $type = $_GET['type'] ?? 'agents';
                $user = ($type === 'agents') ? 'agents' : getAICliConfig()['user'];
            }
            ob_end_clean();
            if (!ValidationService::isTaskStatusUser((string)$user)) {
                header('Content-Type: application/json');
                echo json_encode(['progress' => 0, 'step' => 'invalid user']);
            } else {
                $file = \AICliAgents\Services\SecretPaths::stateRoot() . "/task-status-$user";
                header('Content-Type: application/json');
                // nosemgrep: php.lang.security.injection.echoed-request.echoed-request
                if (file_exists($file)) echo file_get_contents($file);
                else echo json_encode(['progress' => 0, 'step' => 'Starting...']);
            }
        } else {
            // Standard JSON handlers
            $result = $aicliLean ? \AICliAgents\Handlers\NotebookHandler::handle($action, $id) : (\AICliAgents\Handlers\TerminalHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\StorageHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\AgentHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\TmuxHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\ArgsHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\AutoLaunchHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\EnvHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\SshHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\RunScriptsHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\ActivityHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\HubHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\GitHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\DiagnosticsHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\BundleHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\AssetsHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\AgentRelayHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\VoiceHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\FavouritesHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\HistoryHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\BootSpaceHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\BootArchiveHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\AutoContinueHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\NotebookHandler::handle($action, $id)
                   ?? \AICliAgents\Handlers\UtilityHandler::handle($action, $id));

            ob_end_clean();
            if ($result !== null) {
                // EVENT_FIRST_RECONCILIATION.md R4/R5: every reconcile read needs
                // a server-clock `ts` so a subscriber can drop a push message
                // older than the last snapshot it applied. This is the one place
                // every standard handler's JSON answer passes through, so stamp
                // it here instead of in each handler. A handler that already set
                // its own `ts` keeps it.
                if (is_array($result) && !array_key_exists('ts', $result)) {
                    $result['ts'] = \AICliAgents\Services\NchanService::nowMs();
                }
                // json_encode output served as application/json — no browser
                // HTML parser involved. Not a user-controlled HTML sink.
                // nosemgrep: php.lang.security.injection.echoed-request.echoed-request
                echo json_encode($result);
            } else {
                $safeAction = preg_replace('/[^a-zA-Z0-9_.-]/', '', substr((string)$action, 0, 64));
                aicli_log("Unknown AJAX action: $safeAction", AICLI_LOG_WARN, 'AICliAjax');
                // Same: JSON response, not HTML. $action has already reached
                // the dispatcher's switch without matching a handler.
                // nosemgrep: php.lang.security.injection.echoed-request.echoed-request
                echo json_encode(['status' => 'error', 'message' => "Unknown action: $action"]);
            }
        }
    } catch (\Throwable $e) {
        aicli_log("AJAX EXCEPTION [$action]: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine(), AICLI_LOG_ERROR);
        $config = getAICliConfig();
        $response = ['status' => 'error', 'message' => $e->getMessage()];
        if (($config['log_level'] ?? 2) >= 3) {
            $response['trace'] = $e->getTraceAsString();
        }
        ob_end_clean();
        echo json_encode($response);
        $ajaxFinish();
    }
    $ajaxFinish();

    exit;
}
