<?php
/**
 * apply-tmux-json.php — emit `tmux set-option` commands for an allow-listed
 * JSON settings file. Invoked by aicli-shell.sh's apply_tmux_json helper:
 *
 *   php apply-tmux-json.php <settings.json> <target-session> [<more-settings.json>...] | bash
 *
 * TERMINAL_FAST_ATTACH.md S4: the launcher passes every tier file that exists in ONE call
 * (quirk file, agent JSON, workspace JSON); the files are applied in the order given.
 *
 * T-03: the allowed/append key lists are single-sourced from
 * TmuxService::ALLOWED_KEYS / ::APPEND_KEYS — any future extension of the PHP
 * consts is automatically reflected in the shell tier. Lives in a script file
 * (not `php -r`) per the publish anti-pattern rule: backslash namespaces
 * inside a double-quoted `php -r` body are eaten by bash.
 *
 * Every option is targeted at one session. APPEND_KEYS emit `-a -t` once per entry (#371); all other
 * keys emit `-t`. The tmux server is shared by every workspace, so `-g` would
 * allow the last attached workspace to overwrite all others (#67).
 */

declare(strict_types=1);

$srcRoot = dirname(__DIR__, 2);
require_once $srcRoot . '/includes/AICliAgentsManager.php';
require_once $srcRoot . '/includes/services/TmuxService.php';

// Files: argv[1] first, then any more files after the session name (argv[3...]), applied in
// that order so a later tier wins. The one-file call of the older launcher still works.
$target = $argv[2] ?? '';
if (!preg_match('/^[A-Za-z0-9_-]{1,160}$/D', $target)) {
    exit(0);
}
$jsonfiles = array_merge([$argv[1] ?? ''], array_slice($argv, 3));

$allowed = \AICliAgents\Services\TmuxService::ALLOWED_KEYS;
$append  = \AICliAgents\Services\TmuxService::APPEND_KEYS;

foreach ($jsonfiles as $jsonfile) {
if ($jsonfile === '' || !is_file($jsonfile)) {
    continue; // nothing to apply — mirrors the shell helper's [ -f ] guard
}
$s = json_decode((string)@file_get_contents($jsonfile), true);
if (!is_array($s)) {
    continue;
}

foreach ($s as $k => $v) {
    if (!is_string($k)) continue;
    if ($v === '' || $v === null) continue;
    $isAppend = in_array($k, $append, true);
    if (!in_array($k, $allowed, true) && !$isAppend) continue;
    if ($isAppend) {
        // #371: APPEND_KEYS are SERVER array options, and this pass runs on every
        // terminal attach. Append each entry only when the server does not have it
        // yet; a plain `set-option -a` added one more copy per attach.
        foreach (explode(',', (string)$v) as $entry) {
            if ($entry === '') continue;
            echo 'tmux show-options -sv ' . escapeshellarg($k) . ' 2>/dev/null | grep -qxF -- ' . escapeshellarg($entry)
                . ' || tmux set-option -a -t ' . escapeshellarg($target) . ' '
                . escapeshellarg($k) . ' ' . escapeshellarg(',' . $entry) . "\n";
        }
        continue;
    }
    echo 'tmux set-option -t ' . escapeshellarg($target) . ' '
        . escapeshellarg($k) . ' ' . escapeshellarg((string)$v) . "\n";
}
}
