#!/bin/bash
# AICliAgents: Shrink a Btrfs loop-back image file
# Reduces the Btrfs filesystem inside the image, then truncates the file to match.
#
# Usage: ./shrink-btrfs-image.sh <image_file> [target_mb]
#   image_file  Path to the .img file (e.g., home_root.img.migrated)
#   target_mb   Optional target size in MB (default: auto = used + 50MB headroom)
#
# Examples:
#   ./shrink-btrfs-image.sh /boot/config/plugins/unraid-aicliagents/home_root.img.migrated
#   ./shrink-btrfs-image.sh /boot/config/plugins/unraid-aicliagents/aicli-agents.img.migrated 500

set -euo pipefail

AUTO_YES=false
while [[ "${1:-}" == -* ]]; do
    case "$1" in
        -y|--yes) AUTO_YES=true; shift ;;
        *) shift ;;
    esac
done
IMG="${1:-}"
TARGET_MB="${2:-}"
MNT="/tmp/aicli_shrink_mnt"

log()   { echo -e "\033[1;34m[SHRINK]\033[0m $1"; }
ok()    { echo -e "\033[1;32m[ OK  ]\033[0m $1"; }
error() { echo -e "\033[1;31m[ERR! ]\033[0m $1"; exit 1; }

if [ -z "$IMG" ]; then
    echo "Usage: $0 [-y] <image_file> [target_mb]"
    echo ""
    echo "Shrinks a Btrfs loop-back .img file to minimize wasted space."
    echo "The Btrfs filesystem inside is resized first, then the file is truncated."
    echo ""
    echo "  -y          Non-interactive mode (skip confirmation prompt)"
    echo "  image_file  Path to the .img file"
    echo "  target_mb   Optional target size in MB (default: used + 50MB)"
    exit 1
fi

[ ! -f "$IMG" ] && error "Image file not found: $IMG"

# Ensure not already mounted
if mount | grep -q "$IMG"; then
    error "Image is already mounted. Unmount it first."
fi

mkdir -p "$MNT"

# --- Step 1: Inspect current state ---
log "Mounting image read-only to inspect..."
mount -o loop,ro "$IMG" "$MNT" || error "Failed to mount image. Is it a valid Btrfs image?"

USED_BYTES=$(btrfs filesystem usage -b "$MNT" 2>/dev/null | grep "Used:" | head -1 | awk '{print $NF}')
DEVICE_BYTES=$(btrfs filesystem usage -b "$MNT" 2>/dev/null | grep "Device size:" | awk '{print $NF}')
USED_MB=$(( ${USED_BYTES:-0} / 1024 / 1024 ))
DEVICE_MB=$(( ${DEVICE_BYTES:-0} / 1024 / 1024 ))

umount "$MNT"

log "Current image: $(ls -lh "$IMG" | awk '{print $5}') (file size)"
log "Btrfs device:  ${DEVICE_MB} MB"
log "Btrfs used:    ${USED_MB} MB"

if [ "$USED_MB" -eq 0 ]; then
    error "Could not determine used space. Is this a Btrfs image?"
fi

# --- Step 2: Calculate target size ---
if [ -z "$TARGET_MB" ]; then
    # Auto: used + 50MB headroom (minimum 64MB for Btrfs metadata)
    TARGET_MB=$(( USED_MB + 50 ))
    [ "$TARGET_MB" -lt 64 ] && TARGET_MB=64
fi

if [ "$TARGET_MB" -ge "$DEVICE_MB" ]; then
    ok "Image is already ${DEVICE_MB} MB, target ${TARGET_MB} MB — no shrink needed."
    rmdir "$MNT" 2>/dev/null || true
    exit 0
fi

log "Target size: ${TARGET_MB} MB (used ${USED_MB} MB + headroom)"
if [ "$AUTO_YES" != true ]; then
    echo ""
    read -p "Proceed with shrink? [y/N] " -r
    [[ ! "$REPLY" =~ ^[Yy]$ ]] && { log "Aborted."; exit 0; }
fi

# --- Step 3: Shrink the Btrfs filesystem ---
log "Mounting image read-write..."
mount -o loop "$IMG" "$MNT" || error "Failed to mount image read-write."

log "Resizing Btrfs filesystem to ${TARGET_MB}M..."
if ! btrfs filesystem resize "${TARGET_MB}M" "$MNT"; then
    umount "$MNT"
    error "Btrfs resize failed. Try a larger target (current used: ${USED_MB} MB)."
fi

# Read back the actual device size after resize
NEW_DEVICE_BYTES=$(btrfs filesystem usage -b "$MNT" | grep "Device size:" | awk '{print $NF}')
NEW_DEVICE_MB=$(( NEW_DEVICE_BYTES / 1024 / 1024 ))
ok "Btrfs filesystem resized to ${NEW_DEVICE_MB} MB"

umount "$MNT"

# --- Step 4: Truncate the image file ---
# Add 1MB safety margin to the filesystem size
TRUNCATE_BYTES=$(( NEW_DEVICE_BYTES + 1048576 ))
TRUNCATE_MB=$(( TRUNCATE_BYTES / 1024 / 1024 ))

log "Truncating image file to ${TRUNCATE_MB} MB..."
truncate -s "$TRUNCATE_BYTES" "$IMG"

# --- Step 5: Verify ---
log "Verifying shrunk image..."
mount -o loop,ro "$IMG" "$MNT" || error "VERIFICATION FAILED: Shrunk image won't mount!"
VERIFY_USED=$(df -h "$MNT" | tail -1 | awk '{print $3}')
VERIFY_SIZE=$(df -h "$MNT" | tail -1 | awk '{print $2}')
umount "$MNT"
rmdir "$MNT" 2>/dev/null || true

echo ""
ok "Image shrunk successfully!"
log "  File:       $(ls -lh "$IMG" | awk '{print $5}')  $(basename "$IMG")"
log "  Filesystem: ${VERIFY_SIZE} total, ${VERIFY_USED} used"
log "  Saved:      $(( DEVICE_MB - NEW_DEVICE_MB )) MB"
