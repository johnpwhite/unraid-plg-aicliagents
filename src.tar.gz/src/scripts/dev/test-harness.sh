#!/bin/bash
# AICliAgents: Storage Architecture Test Harness (v3)
# Non-destructive: backs up live SquashFS state before testing, restores afterward.

set -uo pipefail

STATE=${1:-}
NAME="unraid-aicliagents"
CONFIG_DIR="/boot/config/plugins/$NAME"
PERSIST_DIR="$CONFIG_DIR/persistence"
FIXTURE_DIR="$CONFIG_DIR/test-fixtures"
BACKUP_DIR="$CONFIG_DIR/migration_testing"
EMHTTP_DEST="/usr/local/emhttp/plugins/$NAME"
STORAGE_SCRIPTS="$EMHTTP_DEST/src/scripts/storage"

log()   { echo -e "\033[1;34m[TEST]\033[0m $1"; }
warn()  { echo -e "\033[1;33m[WARN]\033[0m $1"; }
error() { echo -e "\033[1;31m[ERR!]\033[0m $1"; exit 1; }
ok()    { echo -e "\033[1;32m[ OK ]\033[0m $1"; }

# ────────────────────────────────────────────
# Safety: Persist + Consolidate live layers
# ────────────────────────────────────────────
persist_and_consolidate() {
    log "Persisting and consolidating all live SquashFS layers..."
    local found=0

    # Discover active agents
    for sqsh in "$PERSIST_DIR"/agent_*.sqsh "$CONFIG_DIR"/agent_*.sqsh; do
        [ ! -f "$sqsh" ] && continue
        local base=$(basename "$sqsh")
        local id=""
        if [[ "$base" =~ ^agent_([a-zA-Z][a-zA-Z0-9_-]*)_(v[0-9]+_vol[0-9]+|vol[0-9]+|delta_[0-9]+)\.sqsh$ ]]; then
            id="${BASH_REMATCH[1]}"
        fi
        [ -z "$id" ] && continue

        # Deduplicate (we may see multiple layers for same id)
        if [ -f "/tmp/unraid-aicliagents/.harness_seen_agent_$id" ]; then continue; fi
        touch "/tmp/unraid-aicliagents/.harness_seen_agent_$id"
        found=1

        local persist_path=$(dirname "$sqsh")
        log "  Persisting agent: $id ..."
        bash "$STORAGE_SCRIPTS/commit_stack.sh" agent "$id" "$persist_path" 2>&1 | sed 's/^/    /'
        log "  Consolidating agent: $id ..."
        bash "$STORAGE_SCRIPTS/consolidate_layers.sh" agent "$id" "$persist_path" 2>&1 | sed 's/^/    /'
    done

    # Discover active homes
    for sqsh in "$PERSIST_DIR"/home_*.sqsh "$CONFIG_DIR"/home_*.sqsh; do
        [ ! -f "$sqsh" ] && continue
        local base=$(basename "$sqsh")
        local id=""
        if [[ "$base" =~ ^home_([a-zA-Z][a-zA-Z0-9_-]*)_(v[0-9]+_vol[0-9]+|vol[0-9]+|delta_[0-9]+)\.sqsh$ ]]; then
            id="${BASH_REMATCH[1]}"
        fi
        [ -z "$id" ] && continue

        if [ -f "/tmp/unraid-aicliagents/.harness_seen_home_$id" ]; then continue; fi
        touch "/tmp/unraid-aicliagents/.harness_seen_home_$id"
        found=1

        local persist_path=$(dirname "$sqsh")
        log "  Persisting home: $id ..."
        bash "$STORAGE_SCRIPTS/commit_stack.sh" home "$id" "$persist_path" 2>&1 | sed 's/^/    /'
        log "  Consolidating home: $id ..."
        bash "$STORAGE_SCRIPTS/consolidate_layers.sh" home "$id" "$persist_path" 2>&1 | sed 's/^/    /'
    done

    # Clean dedup markers
    rm -f /tmp/unraid-aicliagents/.harness_seen_*

    if [ "$found" -eq 0 ]; then
        log "  No live SquashFS layers found — nothing to persist."
    fi
}

# ────────────────────────────────────────────
# Backup: Move live .sqsh + .img to backup dir
# ────────────────────────────────────────────
backup_live_state() {
    if [ -d "$BACKUP_DIR" ]; then
        error "Backup directory already exists: $BACKUP_DIR\nA previous test may still be active. Run '$0 restore' first."
    fi

    mkdir -p "$BACKUP_DIR/config_dir" "$BACKUP_DIR/persist_dir"

    # Move .sqsh and .img files from config dir
    local moved=0
    shopt -s nullglob
    for f in "$CONFIG_DIR"/*.sqsh "$CONFIG_DIR"/*.img "$CONFIG_DIR"/*.img.migrated; do
        mv "$f" "$BACKUP_DIR/config_dir/"
        log "  Backed up: $(basename "$f") → migration_testing/config_dir/"
        moved=$((moved + 1))
    done

    # Move .sqsh and .img files from persistence dir
    for f in "$PERSIST_DIR"/*.sqsh "$PERSIST_DIR"/*.img "$PERSIST_DIR"/*.img.migrated; do
        mv "$f" "$BACKUP_DIR/persist_dir/"
        log "  Backed up: $(basename "$f") → migration_testing/persist_dir/"
        moved=$((moved + 1))
    done
    shopt -u nullglob

    if [ "$moved" -eq 0 ]; then
        log "  No storage files to back up (clean install)."
    else
        ok "Backed up $moved file(s) to $BACKUP_DIR"
    fi
}

# ────────────────────────────────────────────
# Teardown: Unmount overlays + ZRAM (not files)
# ────────────────────────────────────────────
teardown_mounts() {
    log "Unmounting active overlays and ZRAM..."
    mount | grep -E "aicli|zram" | cut -d' ' -f3 | sort -r | xargs -r umount -l 2>/dev/null
    if [ -b /dev/zram0 ]; then
        zramctl --reset /dev/zram0 2>/dev/null
    fi
    rm -rf /tmp/unraid-aicliagents/work /tmp/unraid-aicliagents/mnt
    rm -f /tmp/unraid-aicliagents/migration.lock
}

# ────────────────────────────────────────────
# Cleanup: Remove only test-created artifacts
# ────────────────────────────────────────────
cleanup_test_artifacts() {
    log "Removing test-created storage artifacts..."
    shopt -s nullglob

    # Remove any .sqsh/.img files that are NOT in our backup (i.e., created by the test)
    for f in "$CONFIG_DIR"/*.sqsh "$CONFIG_DIR"/*.img "$CONFIG_DIR"/*.img.migrated; do
        log "  Removing test artifact: $(basename "$f")"
        rm -f "$f"
    done
    for f in "$PERSIST_DIR"/*.sqsh "$PERSIST_DIR"/*.img "$PERSIST_DIR"/*.img.migrated; do
        log "  Removing test artifact: $(basename "$f")"
        rm -f "$f"
    done

    # Remove migrated_legacy_data if migration created it
    if [ -d "$PERSIST_DIR/migrated_legacy_data" ]; then
        log "  Removing migrated_legacy_data/"
        rm -rf "$PERSIST_DIR/migrated_legacy_data"
    fi
    if [ -d "$CONFIG_DIR/migrated_legacy_data" ]; then
        log "  Removing migrated_legacy_data/"
        rm -rf "$CONFIG_DIR/migrated_legacy_data"
    fi

    shopt -u nullglob
}

# ────────────────────────────────────────────
# Restore: Bring back backed-up live state
# ────────────────────────────────────────────
restore_live_state() {
    if [ ! -d "$BACKUP_DIR" ]; then
        error "No backup found at $BACKUP_DIR. Nothing to restore."
    fi

    local restored=0
    shopt -s nullglob

    for f in "$BACKUP_DIR/config_dir"/*; do
        mv "$f" "$CONFIG_DIR/"
        log "  Restored: $(basename "$f") → config dir"
        restored=$((restored + 1))
    done

    for f in "$BACKUP_DIR/persist_dir"/*; do
        mv "$f" "$PERSIST_DIR/"
        log "  Restored: $(basename "$f") → persistence dir"
        restored=$((restored + 1))
    done

    shopt -u nullglob

    # Remove backup directory
    rm -rf "$BACKUP_DIR"

    if [ "$restored" -eq 0 ]; then
        log "  No files to restore (was a clean install)."
    else
        ok "Restored $restored file(s) from backup."
    fi
}

# ────────────────────────────────────────────
# Display results after migration
# ────────────────────────────────────────────
show_results() {
    echo ""
    log "═══════════════════════════════════════════"
    log "  Migration Test Results"
    log "═══════════════════════════════════════════"
    echo ""

    # Show new .sqsh files
    local sqsh_count=0
    shopt -s nullglob
    for f in "$CONFIG_DIR"/*.sqsh "$PERSIST_DIR"/*.sqsh; do
        if [ "$sqsh_count" -eq 0 ]; then
            ok "New SquashFS volumes created:"
        fi
        local size=$(du -h "$f" | cut -f1)
        echo "    $size  $(basename "$f")"
        sqsh_count=$((sqsh_count + 1))
    done
    shopt -u nullglob

    if [ "$sqsh_count" -eq 0 ]; then
        warn "No SquashFS volumes were created by migration."
    fi

    # Show migrated legacy files
    local legacy_count=0
    shopt -s nullglob
    for f in "$CONFIG_DIR"/*.img.migrated "$PERSIST_DIR"/*.img.migrated \
             "$CONFIG_DIR"/migrated_legacy_data "$PERSIST_DIR"/migrated_legacy_data; do
        [ ! -e "$f" ] && continue
        if [ "$legacy_count" -eq 0 ]; then
            echo ""
            ok "Legacy artifacts (renamed/moved by migration):"
        fi
        if [ -d "$f" ]; then
            local size=$(du -sh "$f" | cut -f1)
            echo "    $size  $(basename "$f")/"
        else
            local size=$(du -h "$f" | cut -f1)
            echo "    $size  $(basename "$f")"
        fi
        legacy_count=$((legacy_count + 1))
    done
    shopt -u nullglob

    echo ""
    log "───────────────────────────────────────────"
    log "  Verify in browser: Manager → Storage tab"
    log "  When done, run:  $0 restore"
    log "───────────────────────────────────────────"
    echo ""
}

# ════════════════════════════════════════════
# Main command dispatcher
# ════════════════════════════════════════════
case "$STATE" in
    "prepare-raw")
        [ ! -d "$FIXTURE_DIR" ] && error "Fixture directory $FIXTURE_DIR not found. Populate it first!"
        echo ""
        log "╔═══════════════════════════════════════════╗"
        log "║  Prepare: Era 1 — Legacy Raw Folders      ║"
        log "╚═══════════════════════════════════════════╝"
        echo ""

        # Step 1: Persist + consolidate live state
        persist_and_consolidate

        # Step 2: Teardown mounts
        teardown_mounts

        # Step 3: Backup live files
        backup_live_state

        # Step 4: Restore fixture data as raw folders
        log "Restoring fixtures as raw folder contents..."
        MNT="/tmp/unraid-aicliagents/fixture_mnt"
        mkdir -p "$MNT"

        if [ -f "$FIXTURE_DIR/aicli-agents.img.migrated" ]; then
            mount -o loop,ro "$FIXTURE_DIR/aicli-agents.img.migrated" "$MNT"
            if [ $? -eq 0 ]; then
                mkdir -p "$EMHTTP_DEST/agents"
                # Use rsync to include dotfiles (cp -r * skips hidden files)
                rsync -a "$MNT/" "$EMHTTP_DEST/agents/" 2>/dev/null
                umount -l "$MNT"
                ok "Copied raw agent folders to agents/"
            fi
        fi

        shopt -s nullglob
        for img in "$FIXTURE_DIR"/home_*.img.migrated; do
            [ ! -f "$img" ] && continue
            USER_NAME=$(basename "$img" | sed 's/home_//' | sed 's/\.img.*//')
            mount -o loop,ro "$img" "$MNT"
            if [ $? -eq 0 ]; then
                mkdir -p "$PERSIST_DIR/$USER_NAME"
                # Use rsync to include dotfiles (cp -r * skips hidden files)
                rsync -a "$MNT/" "$PERSIST_DIR/$USER_NAME/" 2>/dev/null
                umount -l "$MNT"
                ok "Copied raw home folder for user: $USER_NAME"
            fi
        done
        shopt -u nullglob

        rmdir "$MNT" 2>/dev/null
        echo ""
        ok "State set to Era 1 (raw folders). Run '$0 migrate' to test migration."
        echo ""
        ;;

    "prepare-img")
        [ ! -d "$FIXTURE_DIR" ] && error "Fixture directory $FIXTURE_DIR not found. Populate it first!"
        echo ""
        log "╔═══════════════════════════════════════════╗"
        log "║  Prepare: Era 2 — Monolithic Btrfs Images ║"
        log "╚═══════════════════════════════════════════╝"
        echo ""

        # Step 1: Persist + consolidate live state
        persist_and_consolidate

        # Step 2: Teardown mounts
        teardown_mounts

        # Step 3: Backup live files
        backup_live_state

        # Step 4: Restore fixture .img files
        log "Restoring fixtures as live .img files..."
        mkdir -p "$PERSIST_DIR"

        if [ -f "$FIXTURE_DIR/aicli-agents.img.migrated" ]; then
            cp "$FIXTURE_DIR/aicli-agents.img.migrated" "$CONFIG_DIR/aicli-agents.img"
            ok "Restored aicli-agents.img ($(du -h "$CONFIG_DIR/aicli-agents.img" | cut -f1))"
        fi

        shopt -s nullglob
        for img in "$FIXTURE_DIR"/home_*.img.migrated; do
            USER_NAME=$(basename "$img" | sed 's/home_//' | sed 's/\.img.*//')
            cp "$img" "$PERSIST_DIR/home_$USER_NAME.img"
            ok "Restored home_$USER_NAME.img ($(du -h "$PERSIST_DIR/home_$USER_NAME.img" | cut -f1))"
        done
        shopt -u nullglob

        echo ""
        ok "State set to Era 2 (Btrfs images). Run '$0 migrate' to test migration."
        echo ""
        ;;

    "migrate")
        echo ""
        log "╔═══════════════════════════════════════════╗"
        log "║  Running Migration Engine                  ║"
        log "╚═══════════════════════════════════════════╝"
        echo ""

        MIGRATE_SCRIPT="$EMHTTP_DEST/src/scripts/installer/migrate-btrfs-to-squashfs.sh"
        [ ! -f "$MIGRATE_SCRIPT" ] && error "Migration script not found: $MIGRATE_SCRIPT"

        mkdir -p /tmp/unraid-aicliagents
        log "Running migration (logs to /tmp/unraid-aicliagents/migration.log)..."
        echo ""
        bash "$MIGRATE_SCRIPT" 2>&1 | tee /tmp/unraid-aicliagents/migration.log
        echo ""

        show_results
        ;;

    "restore")
        echo ""
        log "╔═══════════════════════════════════════════╗"
        log "║  Restore: Returning to Live State          ║"
        log "╚═══════════════════════════════════════════╝"
        echo ""

        # Step 1: Teardown any mounts from the test
        teardown_mounts

        # Step 2: Remove test-created artifacts
        cleanup_test_artifacts

        # Step 3: Restore backed-up files
        restore_live_state

        # Step 4: Reinitialize mounts
        log "Reinitializing storage mounts..."
        INIT_SCRIPT="$STORAGE_SCRIPTS/initialize_zram.sh"
        if [ -f "$INIT_SCRIPT" ]; then
            bash "$INIT_SCRIPT" 2>&1 | sed 's/^/    /'
        fi

        # Remount all entities by triggering the plugin init
        MOUNT_SCRIPT="$STORAGE_SCRIPTS/mount_stack.sh"
        if [ -f "$MOUNT_SCRIPT" ]; then
            # Remount agents
            shopt -s nullglob
            for sqsh in "$PERSIST_DIR"/agent_*.sqsh "$CONFIG_DIR"/agent_*.sqsh; do
                [ ! -f "$sqsh" ] && continue
                local_base=$(basename "$sqsh")
                if [[ "$local_base" =~ ^agent_(.+?)_(v[0-9]+_vol[0-9]+|vol[0-9]+|delta_[0-9]+)\.sqsh$ ]]; then
                    aid="${BASH_REMATCH[1]}"
                    if [ ! -f "/tmp/unraid-aicliagents/.harness_remount_agent_$aid" ]; then
                        touch "/tmp/unraid-aicliagents/.harness_remount_agent_$aid"
                        log "  Remounting agent: $aid"
                        bash "$MOUNT_SCRIPT" agent "$aid" "$(dirname "$sqsh")" 2>&1 | sed 's/^/    /'
                    fi
                fi
            done

            # Remount homes
            for sqsh in "$PERSIST_DIR"/home_*.sqsh "$CONFIG_DIR"/home_*.sqsh; do
                [ ! -f "$sqsh" ] && continue
                local_base=$(basename "$sqsh")
                if [[ "$local_base" =~ ^home_([a-zA-Z][a-zA-Z0-9_-]*)_(v[0-9]+_vol[0-9]+|vol[0-9]+|delta_[0-9]+)\.sqsh$ ]]; then
                    hid="${BASH_REMATCH[1]}"
                    if [ ! -f "/tmp/unraid-aicliagents/.harness_remount_home_$hid" ]; then
                        touch "/tmp/unraid-aicliagents/.harness_remount_home_$hid"
                        log "  Remounting home: $hid"
                        bash "$MOUNT_SCRIPT" home "$hid" "$(dirname "$sqsh")" 2>&1 | sed 's/^/    /'
                    fi
                fi
            done
            shopt -u nullglob

            rm -f /tmp/unraid-aicliagents/.harness_remount_*
        fi

        echo ""
        ok "Live state restored. Storage mounts reinitialized."
        log "You may need to restart agent sessions from the Terminal page."
        echo ""
        ;;

    "status")
        echo ""
        log "Current test harness state:"
        if [ -d "$BACKUP_DIR" ]; then
            warn "Test in progress — backup exists at $BACKUP_DIR"
            echo "  Backed-up files:"
            shopt -s nullglob
            for f in "$BACKUP_DIR/config_dir"/* "$BACKUP_DIR/persist_dir"/*; do
                [ ! -e "$f" ] && continue
                echo "    $(du -h "$f" | cut -f1)  $(basename "$f")"
            done
            shopt -u nullglob
            echo ""
            log "Run '$0 restore' to return to live state."
        else
            ok "No test in progress. Live state is active."
        fi

        echo ""
        log "Live storage files:"
        shopt -s nullglob
        for f in "$CONFIG_DIR"/*.sqsh "$PERSIST_DIR"/*.sqsh \
                 "$CONFIG_DIR"/*.img "$PERSIST_DIR"/*.img; do
            [ ! -e "$f" ] && continue
            echo "  $(du -h "$f" | cut -f1)  $(basename "$f")"
        done
        shopt -u nullglob

        if [ -d "$FIXTURE_DIR" ]; then
            echo ""
            log "Fixture files:"
            shopt -s nullglob
            for f in "$FIXTURE_DIR"/*; do
                echo "  $(du -h "$f" | cut -f1)  $(basename "$f")"
            done
            shopt -u nullglob
        else
            warn "No fixture directory found at $FIXTURE_DIR"
        fi
        echo ""
        ;;

    *)
        echo ""
        echo "AICliAgents Storage Test Harness v3"
        echo "==================================="
        echo ""
        echo "Usage: $0 {prepare-raw|prepare-img|migrate|restore|status}"
        echo ""
        echo "  prepare-raw   Set up Era 1 state (raw folders on Flash)"
        echo "  prepare-img   Set up Era 2 state (monolithic Btrfs .img files)"
        echo "  migrate       Run the migration engine"
        echo "  restore       Clean up test artifacts, restore live state"
        echo "  status        Show current state and file inventory"
        echo ""
        echo "Non-destructive workflow:"
        echo "  1. prepare-img (or prepare-raw)  — persists live state, sets up legacy fixtures"
        echo "  2. migrate                        — runs the migration engine, shows results"
        echo "  3. (verify in browser)            — check Manager → Storage tab"
        echo "  4. restore                        — cleans test data, restores live state"
        echo ""
        exit 1
        ;;
esac
