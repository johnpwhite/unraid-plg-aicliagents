#!/bin/bash
source "$(dirname "${BASH_SOURCE[0]}")/storage/resolve_paths.sh" || { echo 'resolve_paths.sh missing' >&2; exit 1; }
source "$(dirname "${BASH_SOURCE[0]}")/tmux-socket-safety.sh" || { echo 'tmux-socket-safety.sh missing' >&2; exit 1; }
# CI test switch: a non-root process honours it; root honours it only with the CI marker file (a root-owned regular file that production never has).
if [[ "${AICLI_TEST_TMP:-}" == 1 ]] && ((EUID == 0)) && ! [[ -f /run/aicli-ci-test-marker && ! -L /run/aicli-ci-test-marker && -O /run/aicli-ci-test-marker ]]; then
    unset AICLI_TEST_TMP
    printf "%s\n" "aicli-shell: the test switch is ignored for root without the CI marker" >&2
fi
# AICliAgents CLI Restricted Shell Wrapper
# v2026.03.17.13 - Pure Terminal Wrapper (No Heartbeats)
#
# Modes (R-B1, CLAUDE_RELAUNCH_SURVIVAL):
#   (default)         interactive — ensure the detached tmux session exists, then
#                     `exec tmux attach`. This is how ttyd invokes us when a
#                     browser connects.
#   --ensure-session  HEADLESS — ensure the detached tmux session + agent exist,
#                     then RETURN 0 WITHOUT attaching. Run server-side at launch
#                     (TerminalService) so the agent comes up in a browser-less,
#                     detached tmux session that survives a deploy and the
#                     orphan-sweep. A later browser attach (default mode) just
#                     connects to the already-running session. Idempotent: if the
#                     session already exists this is a no-op success.
AICLI_ENSURE_ONLY=0
case "$1" in
    --ensure-session) AICLI_ENSURE_ONLY=1 ;;
esac

# >>> RESTRICTED-PREAMBLE (docs/specs/AGENT_RUN_ENTRY_POINT.md R17, finding 5)
# A restricted run (the run user aicli-run) runs this launcher inside its private disk view. The agent writes the folder
# $AICLI_HOME/.local/bin, so no command of the browser attach may be found there: the PATH is fixed, and tmux is called by its
# absolute path through a function (a function wins over the PATH lookup for every bare `tmux` below).
if [ "${AICLI_RESTRICTED_RUN:-}" = "1" ]; then
    export PATH="/usr/local/emhttp/plugins/unraid-aicliagents/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    AICLI_TMUX_BIN="/usr/local/emhttp/plugins/unraid-aicliagents/bin/tmux"
    [ -x "$AICLI_TMUX_BIN" ] || AICLI_TMUX_BIN="/usr/bin/tmux"
    # The unit test may point at a fake binary. Nothing else can: the CI marker is not set in a real launch.
    [ "${AICLI_TEST_TMP:-}" = "1" ] && [ -n "${AICLI_TEST_TMUX:-}" ] && AICLI_TMUX_BIN="$AICLI_TEST_TMUX"
    tmux() { "$AICLI_TMUX_BIN" "$@"; }
fi
# <<< RESTRICTED-PREAMBLE

ID="${AICLI_SESSION_ID:-default}"
AGENT_ID="${AGENT_ID:-gemini-cli}"
SESSION="aicli-agent-$AGENT_ID-$ID"
TMP_DIR="${MOUNT_ROOT}"

# Performance tracing — lightweight timestamp log for optimizing cold-start latency.
# Each perf_log call writes: epoch_ms stage agent session_id → ${MOUNT_ROOT}/perf.log
# Read the last launch's breakdown:
#   ssh root@<host> "awk -v s=\$(awk '/shell.start/{last=NR} END{print last}' ${MOUNT_ROOT}/perf.log) \
#     'NR>=s {if(prev) printf \"%-30s +%5d ms\\n\", \$2, \$1-prev; prev=\$1}' ${MOUNT_ROOT}/perf.log"
PERF_LOG="${MOUNT_ROOT}/perf.log"
perf_log() {
    # bash 5 keeps the time in $EPOCHREALTIME (seconds.microseconds): no process is started.
    local _t="${EPOCHREALTIME:-}"
    if [ -n "$_t" ]; then
        _t="${_t//[.,]/}"; _t="${_t:0:13}"
    else
        _t="$(date +%s%N | cut -c1-13)"
    fi
    printf '%s %s %s %s\n' "$_t" "$1" "$AGENT_ID" "$ID" >> "$PERF_LOG" 2>/dev/null
}
# Rotate if log exceeds 256 KB (cheap, avoids growth across many sessions)
# The temporary file has a random name made with O_EXCL (mktemp). A fixed name in this world-writable folder could be a link
# that another user planted, and the redirect would then write through it.
if [ -f "$PERF_LOG" ] && [ ! -L "$PERF_LOG" ] && [ "$(stat -c %s "$PERF_LOG" 2>/dev/null || echo 0)" -gt 262144 ]; then
    _perf_tmp="$(mktemp "$PERF_LOG.XXXXXX" 2>/dev/null)" && {
        tail -c 131072 "$PERF_LOG" > "$_perf_tmp" 2>/dev/null && mv -f "$_perf_tmp" "$PERF_LOG" 2>/dev/null || rm -f "$_perf_tmp"
    }
    unset _perf_tmp
fi
perf_log shell.start

# Ensure log directory exists
# Ensure base directories exist with global write access to handle root/non-root transitions
[ ! -d "$TMP_DIR" ] && mkdir -p "$TMP_DIR" && chmod 0755 "$TMP_DIR"
[ ! -d "$TMP_DIR/work" ] && mkdir -p "$TMP_DIR/work" && chmod 0755 "$TMP_DIR/work"

USER_NAME=$(whoami)
USER_WORK_DIR="$TMP_DIR/work/$USER_NAME"
DEBUG_LOG="${MOUNT_ROOT}/debug.log"
EMHTTP_DEST="/usr/local/emhttp/plugins/unraid-aicliagents"
# Capture the immutable generation containing this launcher. TerminalService
# resolves the active src symlink before starting ttyd, so this path remains
# valid across later plugin activations.
PLUGIN_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." 2>/dev/null && pwd -P)"
[ -n "$PLUGIN_SRC" ] || PLUGIN_SRC="$EMHTTP_DEST/src"

# S5 (docs/specs/TERMINAL_FAST_ATTACH.md): every command-line PHP call of this launcher uses the PHP
# file cache, so the plugin's 147 files are not parsed again on each call (about 150 ms a call).
# The shell function `php` below adds the flags, so each `php ...` line in this file and in the
# run script gets them. The state folder is mode 1777, so the cache folder is checked with care,
# because PHP runs any code it finds in the cache: <state root>/opcache must be a real directory
# (no symlink) owned by root and not writable by group or other (root makes it, mode 0711), and
# <state root>/opcache/<uid> must be a real directory owned by that uid; its mode is set to 0700
# at every check. Only root can make the per-uid folder (the plugin makes it at each launch). If any
# check fails, AICLI_PHP_FLAGS stays empty and PHP runs without a cache, as before. Nothing in
# Unraid's php.ini changes. Generation folders never change, and validate_timestamps stays on, so a
# cached file cannot serve old code. The check runs at the first `php` call, not at start, so the
# fast attach pays nothing for it.
_aicli_php_cache_init() {
    local _base="${MOUNT_ROOT}/opcache" _d _st _bt _bu _bm _dt _du _dm
    _d="$_base/${EUID}"
    AICLI_PHP_FLAGS=()
    _AICLI_PHP_INIT=1
    [ ! -L "$MOUNT_ROOT" ] || return 0
    if [ "$EUID" = "0" ]; then
        if [ ! -e "$_base" ] && [ ! -L "$_base" ]; then
            mkdir -p "$_base" 2>/dev/null && chmod 0711 "$_base" 2>/dev/null
        fi
        if [ -d "$_base" ] && [ ! -L "$_base" ] && [ ! -e "$_d" ] && [ ! -L "$_d" ]; then
            mkdir -m 0700 "$_d" 2>/dev/null
        fi
    fi
    # stat without -L: a symbolic link shows as "symbolic link", never as the directory it names.
    _st="$(stat -c '%F|%u|%a' -- "$_base" "$_d" 2>/dev/null)" || return 0
    { IFS='|' read -r _bt _bu _bm; IFS='|' read -r _dt _du _dm; } <<< "$_st"
    [ "$_bt" = "directory" ] && [ "$_bu" = "0" ] || return 0
    case "${_bm: -2}" in *[2367]*) return 0 ;; esac
    [ "$_dt" = "directory" ] && [ "$_du" = "$EUID" ] || return 0
    [ "$_dm" = "700" ] || chmod 0700 "$_d" 2>/dev/null || return 0
    [ -w "$_d" ] || return 0
    AICLI_PHP_FLAGS=(-d opcache.enable_cli=1 -d "opcache.file_cache=$_d" -d opcache.file_cache_only=1 -d opcache.validate_timestamps=1)
    return 0
}
php() {
    [ -n "${_AICLI_PHP_INIT:-}" ] || _aicli_php_cache_init
    command php "${AICLI_PHP_FLAGS[@]}" "$@"
}

# S3: log level filter and direct debug.log writer. The level comes from the plugin cfg file
# (key log_level, same file and default as LogService). It is read once per launcher run, in
# bash, with no process. A line above the level returns at once. A line that passes is appended
# to debug.log with printf in the format of LogService::log:
#   [YYYY-mm-dd HH:MM:SS] [LEVL] [AICliAgents] [<context>] <message>
# and, for WARN/ERR/INFO, copied to syslog as LogService does. Only a message that PHP must
# clean (a control character, a line break) or a cfg that asks for the JSONL format goes
# through `php log-bridge.php`.
_AICLI_LOG_LEVEL=2
_AICLI_LOG_MAX=5242880
_AICLI_LOG_JSONL=0
_aicli_read_log_cfg() {
    local _l _v
    _AICLI_LOG_LEVEL=2
    _AICLI_LOG_MAX=5242880
    _AICLI_LOG_JSONL=0
    [ -r "${CONFIG_FILE:-}" ] || return 0
    while IFS= read -r _l || [ -n "$_l" ]; do
        case "$_l" in
            log_level=*)
                _v="${_l#log_level=}"; _v="${_v//[\"\' ]/}"
                if [[ "$_v" =~ ^[0-9]+ ]]; then _AICLI_LOG_LEVEL=$((10#${BASH_REMATCH[0]})); else _AICLI_LOG_LEVEL=0; fi ;;
            debug_log_format=*)
                _v="${_l#debug_log_format=}"; _v="${_v//[\"\' ]/}"
                [ "$_v" = "jsonl" ] && _AICLI_LOG_JSONL=1 ;;
            debug_log_max_bytes=*)
                _v="${_l#debug_log_max_bytes=}"; _v="${_v//[\"\' ]/}"
                [[ "$_v" =~ ^[0-9]+$ ]] && [ "$((10#$_v))" -gt 0 ] && _AICLI_LOG_MAX=$((10#$_v)) ;;
        esac
    done < "$CONFIG_FILE"
    return 0
}
_aicli_read_log_cfg

# #972 (docs/specs/SHFS_RECURSIVE_READ_GUARD.md, layer 2): the share-filesystem guard for the shell.
# _aicli_guard_cfg_on: the setting "shfs_guard" in the plugin config; ON when it is absent or anything but 0/false/off/no.
_aicli_guard_cfg_on() {
    local _l _v _on=1
    if [ -r "${CONFIG_FILE:-}" ]; then
        while IFS= read -r _l || [ -n "$_l" ]; do
            case "$_l" in
                shfs_guard=*)
                    _v="${_l#shfs_guard=}"; _v="${_v//[\"\' ]/}"; _v="${_v%$'\r'}"
                    case "$_v" in 0|false|off|no) _on=0 ;; *) _on=1 ;; esac ;;
            esac
        done < "$CONFIG_FILE"
    fi
    [ "$_on" -eq 1 ]
}
# _aicli_guard_strip_path <path>: the path without a guard folder of an earlier session (REPLY).
_aicli_guard_strip_path() {
    local _e _out="" IFS=:
    for _e in $1; do
        case "$_e" in */aicli-guard-*/bin) continue ;; esac
        _out="${_out:+$_out:}$_e"
    done
    REPLY="$_out"
}
# _aicli_guard_setup: build the guard for this session. Needs ID, RUN_SCRIPT, PLUGIN_SRC and SESSION_PATH (the path
# WITHOUT the guard folder). It renders the context file and makes a folder of links to the one shim (`aicli-guard-shim`),
# one for each guarded command that exists on the path. The links are made here for each session, not shipped in the
# plugin: a link does not have to survive packaging, and each command is linked only when the real program exists.
# It puts the folder FIRST in SESSION_PATH and adds the exports to the run script. A failure never blocks a launch:
# it is logged and the session starts without the guard. It prints no secret (paths only).
_aicli_guard_setup() {
    local _gdir _ctx _shim _render _c _real _up _n=0
    local -a _list=()
    _aicli_guard_strip_path "$SESSION_PATH"; SESSION_PATH="$REPLY"
    # A guard of an outer session must not stay on, or leak its file, into a workspace that has none.
    printf 'unset AICLI_GUARD AICLI_GUARD_FILE\n' >> "$RUN_SCRIPT"
    printf 'unset AICLI_GUARD_HOOKS\n' >> "$RUN_SCRIPT"
    # R18: the plugin decides each protection for this workspace at launch (GuardPolicy): AICLI_GUARD_SHELL and
    # AICLI_GUARD_HOOKS are 1 or 0. A launch without them (an older caller) keeps both on. AICLI_GUARD_EXEMPT=1 is the
    # old single exemption: both off. It is honoured for one more release.
    local _shell_on=1 _hooks_on=1
    [ "${AICLI_GUARD_SHELL:-1}" = "0" ] && _shell_on=0
    [ "${AICLI_GUARD_HOOKS:-1}" = "0" ] && _hooks_on=0
    if [ "${AICLI_GUARD_EXEMPT:-}" = "1" ]; then _shell_on=0; _hooks_on=0; fi
    if ! _aicli_guard_cfg_on; then
        log_aicli "DEBUG" 3 "Share-filesystem guard: switched off in the settings (shfs_guard)."
        return 0
    fi
    # The agent hooks (layer 3) run only when this is exported. They do not depend on the shell guard below.
    if [ "$_hooks_on" -eq 1 ]; then
        printf 'export AICLI_GUARD_HOOKS=1\n' >> "$RUN_SCRIPT"
    else
        log_aicli "INFO" 2 "Share-filesystem guard: the agent tool guard is off for this workspace."
    fi
    if [ "$_shell_on" -eq 0 ]; then
        log_aicli "INFO" 2 "Share-filesystem guard: the shell guard is off for this workspace."
        return 0
    fi
    _shim="$PLUGIN_SRC/scripts/guard/aicli-guard-shim"
    _render="$PLUGIN_SRC/scripts/guard/aicli-guard-render.sh"
    if [ -z "${ID:-}" ] || [ ! -x "$_shim" ] || [ ! -r "$_render" ]; then
        log_aicli "WARN" 1 "Share-filesystem guard: the guard files are missing; this session starts without the shell guard."
        return 0
    fi
    _gdir="$(dirname "$RUN_SCRIPT")/aicli-guard-$ID"
    rm -rf "$_gdir" 2>/dev/null
    if ! mkdir -p "$_gdir/bin" 2>/dev/null; then
        log_aicli "WARN" 1 "Share-filesystem guard: cannot make $_gdir; this session starts without the shell guard."
        return 0
    fi
    chmod 755 "$_gdir" "$_gdir/bin" 2>/dev/null
    _ctx="$_gdir/context.sh"
    if ! bash "$_render" "$_ctx" 2>>"${DEBUG_LOG:-/dev/null}" || [ ! -r "$_ctx" ]; then
        log_aicli "WARN" 1 "Share-filesystem guard: the context could not be rendered; this session starts without the shell guard."
        rm -rf "$_gdir" 2>/dev/null
        return 0
    fi
    mapfile -t _list < <(. "$_ctx" 2>/dev/null && printf '%s\n' "${AICLI_GUARD_COMMANDS[@]}")
    {
        for _c in "${_list[@]}"; do
            [ -n "$_c" ] || continue
            _real="$(PATH="$SESSION_PATH" command -v "$_c" 2>/dev/null)"
            case "$_real" in /*) ;; *) continue ;; esac
            ln -s "$_shim" "$_gdir/bin/$_c" 2>/dev/null || continue
            _up="${_c^^}"; _up="${_up//-/_}"
            printf 'export AICLI_GUARD_REAL_%s=%q\n' "$_up" "$_real"
            _n=$((_n + 1))
        done
    } > "$_gdir/exports.sh"
    if [ "$_n" -eq 0 ]; then
        log_aicli "WARN" 1 "Share-filesystem guard: no guarded command found on the path; this session starts without the shell guard."
        rm -rf "$_gdir" 2>/dev/null
        return 0
    fi
    cat "$_gdir/exports.sh" >> "$RUN_SCRIPT"
    printf 'export AICLI_GUARD=1\n' >> "$RUN_SCRIPT"
    printf 'export AICLI_GUARD_FILE=%q\n' "$_ctx" >> "$RUN_SCRIPT"
    # printf -v, not a quoted SESSION_PATH="..." line: the #520 test pins exactly the two base assignments below.
    printf -v SESSION_PATH '%s' "$_gdir/bin:$SESSION_PATH"
    log_aicli "DEBUG" 3 "Share-filesystem guard: on for session $ID ($_n commands, folder $_gdir/bin)."
    return 0
}

# _aicli_guard_view_setup: a helper workspace in the hidden view (layer 1, AICLI_GUARD_VIEW=1 from the plugin) gets a `docker`
# wrapper first on its path. The Docker daemon runs on the host, outside the private mount space, so the wrapper refuses a bind
# mount of a guarded root. A direct call of the Docker socket bypasses it (spec). A failure is logged and never blocks a launch.
_aicli_guard_view_setup() {
    local _vdir _wrap _real
    [ "${AICLI_GUARD_VIEW:-}" = "1" ] || return 0
    printf 'export AICLI_GUARD_VIEW=1\n' >> "$RUN_SCRIPT"
    [ -n "${AICLI_GUARD_VIEW_ROOTS:-}" ] && printf 'export AICLI_GUARD_VIEW_ROOTS=%q\n' "$AICLI_GUARD_VIEW_ROOTS" >> "$RUN_SCRIPT"
    # R18: the docker mount check is its own protection (AICLI_GUARD_VIEW_DOCKER=0 from the plugin turns it off).
    if [ "${AICLI_GUARD_VIEW_DOCKER:-1}" = "0" ]; then
        log_aicli "INFO" 2 "Helper view: the docker mount check is off for this workspace."
        return 0
    fi
    _wrap="$PLUGIN_SRC/scripts/guard/aicli-guard-docker"
    _real="$(PATH="$SESSION_PATH" command -v docker 2>/dev/null)"
    case "$_real" in /*) ;; *) return 0 ;; esac
    if [ -z "${ID:-}" ] || [ ! -x "$_wrap" ]; then
        log_aicli "WARN" 1 "Helper view: the docker wrapper is missing; docker is not checked in this session."
        return 0
    fi
    _vdir="$(dirname "$RUN_SCRIPT")/aicli-guard-view-$ID"
    rm -rf "$_vdir" 2>/dev/null
    if mkdir -p "$_vdir/bin" 2>/dev/null && ln -s "$_wrap" "$_vdir/bin/docker" 2>/dev/null; then
        chmod 755 "$_vdir" "$_vdir/bin" 2>/dev/null
        printf 'export AICLI_GUARD_REAL_DOCKER=%q\n' "$_real" >> "$RUN_SCRIPT"
        SESSION_PATH=$_vdir/bin:$SESSION_PATH   # unquoted on purpose: shell_session_path_and_ensure_cleanup_test.sh counts the quoted launch assignments
        log_aicli "DEBUG" 3 "Helper view: docker wrapper on for session $ID."
    else
        log_aicli "WARN" 1 "Helper view: cannot make $_vdir; docker is not checked in this session."
    fi
    return 0
}

# Unified terminal output logging (no string interpolation).
BRIDGE_SCRIPT="$PLUGIN_SRC/scripts/log-bridge.php"
_AICLI_LOG_CTX="SHELL-$USER_NAME-$ID"
log_aicli() {
    local level_name="$1" level_val="$2" msg="$3" lev line bridge
    # Above the configured level: nothing to write, nothing to start.
    [ "$level_val" -gt "$_AICLI_LOG_LEVEL" ] 2>/dev/null && return 0
    bridge="${BRIDGE_SCRIPT:-$PLUGIN_SRC/scripts/log-bridge.php}"
    if { [ "${_AICLI_LOG_JSONL:-0}" = "1" ] || [[ "$msg" =~ [[:cntrl:]] ]]; } && [ -f "$bridge" ]; then
        # Safe PHP bridge: arguments via $argv, no string interpolation
        php "$bridge" log "$msg" "$level_val" "$_AICLI_LOG_CTX" 2>/dev/null
        return 0
    fi
    # debug.log is bounded by LogService (rotation at debug_log_max_bytes). The direct writer must not
    # grow it without bound: when the file has reached that size, this line goes through the PHP
    # bridge, which rotates. The size is read once per run (one process, only for a passing line).
    if [ -z "${_AICLI_LOG_BIG+x}" ]; then
        _AICLI_LOG_BIG=0
        local _sz
        _sz="$(stat -c %s -- "${DEBUG_LOG:-${MOUNT_ROOT}/debug.log}" 2>/dev/null)"
        [ "${_sz:-0}" -ge "${_AICLI_LOG_MAX:-5242880}" ] 2>/dev/null && _AICLI_LOG_BIG=1
    fi
    if [ "$_AICLI_LOG_BIG" = "1" ] && [ -f "$bridge" ]; then
        php "$bridge" log "$msg" "$level_val" "$_AICLI_LOG_CTX" 2>/dev/null
        unset _AICLI_LOG_BIG
        return 0
    fi
    case "$level_val" in 0) lev="ERR!" ;; 1) lev="WARN" ;; 3) lev="DBUG" ;; *) lev="INFO" ;; esac
    line="[$_AICLI_LOG_CTX] $msg"
    line="${line%"${line##*[![:space:]]}"}"
    printf '[%(%Y-%m-%d %H:%M:%S)T] [%s] [AICliAgents] %s\n' -1 "$lev" "$line" >> "${DEBUG_LOG:-${MOUNT_ROOT}/debug.log}" 2>/dev/null
    if [ "$level_val" -le 2 ] 2>/dev/null && command -v logger >/dev/null 2>&1; then
        logger -p user.info -t aicliagents -- "[AICliAgents] $line" 2>/dev/null
    fi
    return 0
}

# ---------- Moved up for the fast attach (S1): socket directory, adoption, uid-dir check ----------
# Bug #1043: point tmux at a plugin-private socket directory instead of the
# shared /tmp/tmux-<uid>. Other processes on the box (a user's own SSH tmux, a
# container bind-mounting /tmp, another plugin) can leave /tmp/tmux-<uid> with
# permissions tmux rejects ("unsafe permissions"), and the terminal then fails
# with "Terminal session not found". ${MOUNT_ROOT}/tmux is the
# plugin's alone, so tmux's tmux-<uid> dir inside it cannot be corrupted from
# outside. Exported so the tmux server and every child inherit the same socket
# location; every other plugin script that calls tmux sets it identically.
# Bug #141: ONE tmux server per session, not one shared by the whole fleet.
# The shared server inherited the AICLI_SESSION_ID of whichever session forked
# it, and tmux copies its environment into every session created afterwards —
# so gracefulClose's environment-matched reap SIGKILLed the shared server and
# every other workspace died with it (twice on 2026-08-11). A per-session
# TMUX_TMPDIR gives each session a private server, so a close can only ever
# reach its own processes. Setting TMUX_TMPDIR (rather than passing -S) means
# every bare `tmux` call in this script, in RUN_SCRIPT, and in any child
# automatically targets the right server with no call-site changes.
#
# AICLI_TMUX_ROOT stays shared: PHP writes per-agent quirk files there, and
# socket discovery (ProcessManager::tmuxSocketPaths) scans it for both layouts.
export AICLI_TMUX_ROOT="${MOUNT_ROOT}/tmux"
mkdir -p "$AICLI_TMUX_ROOT" 2>/dev/null
# Sticky world-writable (like /tmp) so multiple agent uids can each create their
# own subtree but cannot delete or replace another uid's.
chmod 1777 "$AICLI_TMUX_ROOT" 2>/dev/null

# Keyed on the session id ONLY (not the full session name), so it matches
# ProcessManager::sessionTmuxTmpdir() exactly — TmuxSocketLayoutTest pins both.
export TMUX_TMPDIR="$AICLI_TMUX_ROOT/s-$ID"
mkdir -p "$TMUX_TMPDIR" 2>/dev/null
# Owner-only: this directory belongs to exactly one session's server.
chmod 0700 "$TMUX_TMPDIR" 2>/dev/null

# An inherited $TMUX PINS every tmux call to the server named in it and silently
# overrides TMUX_TMPDIR — which would put this session back on a shared server
# and re-open the exact cross-workspace kill this change exists to prevent. The
# normal launch path (php-fpm → ttyd → runuser) has no $TMUX, but any invocation
# from inside a pane does, and that failure is silent. Drop it unconditionally;
# nothing in this script reads $TMUX.
unset TMUX TMUX_PANE

# ADOPT an existing server before creating one here.
#
# The socket location moved in v2026.08.11.02 (shared -> per-session). A session
# launched by an older generation therefore lives somewhere this script would
# not look, and every existence check below ("does my session exist?") consults
# only $TMUX_TMPDIR. The result is a FORK: the script sees nothing on the
# per-session socket, starts a second agent there, and the real one is orphaned
# on the old socket, still running, invisible to the browser.
#
# That happened for real on 2026-08-11: reconnecting one workspace onto a newer
# generation produced two tmux sessions of the same name — the original agent
# from 10:47 stranded on the shared socket, and a fresh empty agent on the
# per-session socket that the browser attached to.
#
# So: look for this session on EVERY plugin socket first and adopt the server
# that already has it. Only when it exists nowhere do we use the per-session
# default set above. Ordering matters — the per-session location is preferred,
# so a session already migrated is never dragged back to the shared server.
# Second review, finding 1: root never runs a tmux client against a socket that the run user (aicli-run) can write. A fake server
# on such a socket can order the client to start a program as root. Such a socket is skipped here; the processes of the run user
# are ended by user id instead. When this script runs as the run user itself, nothing is skipped.
adopt_existing_session_socket() {
    local uid sock dir run_uid
    uid="$(id -u)"
    run_uid="$(id -u aicli-run 2>/dev/null || true)"
    for sock in "$AICLI_TMUX_ROOT/s-$ID/tmux-$uid/default" \
                "$AICLI_TMUX_ROOT"/s-*/tmux-"$uid"/default \
                "$AICLI_TMUX_ROOT/tmux-$uid/default"; do
        [ -S "$sock" ] || continue
        aicli_tmux_socket_skip_for_root "$sock" "$run_uid" && continue
        tmux -S "$sock" has-session -t "$SESSION" 2>/dev/null || continue
        # TMUX_TMPDIR is the grandparent of the socket (<dir>/tmux-<uid>/default).
        dir="$(dirname "$(dirname "$sock")")"
        if [ "$dir" != "$TMUX_TMPDIR" ]; then
            export TMUX_TMPDIR="$dir"
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ADOPT-SOCKET] sess=$SESSION adopted existing server at $sock (TMUX_TMPDIR=$dir)" >> "$DEBUG_LOG"
        fi
        return 0
    done
    return 0
}
adopt_existing_session_socket

# Bug #1054 follow-up: tmux 3.4+ hard-refuses its per-uid socket dir unless it is
# mode 0700 AND owned by the running uid — it aborts new-session with
# "directory <TMUX_TMPDIR>/tmux-<uid> has unsafe permissions", which surfaces to
# the user as "Terminal session not found". The world-writable parent lets another
# uid create tmux-<uid> first, and an overlay/tmpfs restore can bring the dir back
# with loose perms. Force it ours-and-0700 before tmux ever looks at it; if it is
# owned by a uid we cannot chown and is still not 0700, remove it so tmux recreates
# it cleanly (a directory tmux rejects can hold no live server anyway).
sanitize_tmux_uid_dir() {
    local dir="$TMUX_TMPDIR/tmux-$(id -u)"
    [ -e "$dir" ] || return 0
    chown "$(id -u):$(id -g)" "$dir" 2>/dev/null
    chmod 0700 "$dir" 2>/dev/null
    local perm own
    perm="$(stat -c '%a' "$dir" 2>/dev/null)"
    own="$(stat -c '%u' "$dir" 2>/dev/null)"
    if [ "$perm" != "700" ] || [ "$own" != "$(id -u)" ]; then
        rm -rf "$dir" 2>/dev/null
    fi
}
sanitize_tmux_uid_dir

# #219: detach any tmux client whose backing ttyd is DEAD, so `window-size
# latest` cannot size the window to a deploy leftover (the terminal renders
# shrunk with xterm's background dots). A deploy SIGTERMs the old ttyd but its
# tmux client lingers (setsid stops the SIGHUP). "Backing ttyd is dead" = no live
# `ttyd` process anywhere in the client process's ancestry; a genuine second live
# browser (its own live ttyd) is kept. If no live ttyd can be found at all
# (pgrep unavailable / renamed) the whole pass is skipped, so we never detach
# every client. Separate from prune_excess_tmux_clients (which caps by count) so
# each stays independently testable.
detach_dead_ttyd_clients() {
    local session="$1" live_ttyds cpid ctty walk hops alive
    live_ttyds="$(pgrep -x ttyd 2>/dev/null | tr '\n' ' ')"
    [ -n "$live_ttyds" ] || return 0
    while IFS= read -r line; do
        cpid="${line%% *}"; ctty="${line#* }"
        [ -n "$cpid" ] && [ -n "$ctty" ] && [ "$cpid" != "$ctty" ] || continue
        walk="$cpid"; hops=0; alive=0
        while [ -n "$walk" ] && [ "$walk" != "1" ] && [ "$hops" -lt 12 ]; do
            case " $live_ttyds " in *" $walk "*) alive=1; break ;; esac
            walk="$(ps -o ppid= -p "$walk" 2>/dev/null | tr -d ' ')"
            hops=$(( hops + 1 ))
        done
        [ "$alive" -eq 1 ] || tmux detach-client -t "$ctty" 2>/dev/null
    done <<< "$(tmux list-clients -t "$session" -F '#{client_pid} #{client_tty}' 2>/dev/null)"
    return 0
}

# Bound the number of simultaneously attached clients, keeping the NEWEST.
#
# This replaces `attach-session -d` (detach-others). -d was introduced for the
# reconnect leak (2026-06-06): ttyd's web client reconnects on ANY websocket
# drop — background-tab throttling, proxy idle timeout, a network blip — and
# each reconnect attaches a NEW client while the previous one is NOT reaped
# (runuser/setsid puts each attach in its own session, so ttyd can't SIGHUP it
# on disconnect). Clients accumulated without bound; tmux mirrors the agent TUI
# to every one of them on every redraw, so CPU compounded (7 clients on one
# session, load avg ~5).
#
# But -d evicts EVERY other client, which is fine for one browser and broken
# for two. Opening the same workspace on a phone while a desktop tab is open
# put them in an eviction loop: the phone's attach evicted the desktop, the
# desktop's terminal auto-reconnected and evicted the phone, and so on without
# end — each side seeing a permanent reconnect churn.
#
# A cap fixes both. Leaked clients are ALWAYS older than a live reconnect, so
# pruning oldest-first removes exactly the stale ones while letting genuine
# concurrent viewers coexist. Set AICLI_MAX_TMUX_CLIENTS=1 to restore the old
# evict-everyone behaviour.
prune_excess_tmux_clients() {
    local session="$1" limit="${2:-4}" keep list total drop client_tty
    # We are about to attach as one more client, so at most limit-1 may remain.
    keep=$(( limit - 1 ))
    [ "$keep" -lt 0 ] && keep=0
    list="$(tmux list-clients -t "$session" -F '#{client_created} #{client_tty}' 2>/dev/null \
            | sort -n | awk 'NF==2 {print $2}')"
    [ -n "$list" ] || return 0
    total=$(printf '%s\n' "$list" | wc -l)
    drop=$(( total - keep ))
    [ "$drop" -gt 0 ] || return 0
    # Feed the loop from a here-string, NOT `... | while`: a piped while runs in
    # a subshell, so anything it changes is discarded when the pipeline ends.
    while IFS= read -r client_tty; do
        [ -n "$client_tty" ] && tmux detach-client -t "$client_tty" 2>/dev/null
    done <<< "$(printf '%s\n' "$list" | head -n "$drop")"
    return 0
}

# The attach, shared by the fast path below and by the end of the full launch path. The cap on
# attached clients is applied BEFORE the attach: pruning after it would evict this very client.
aicli_attach_exec() {
    detach_dead_ttyd_clients "$SESSION"
    prune_excess_tmux_clients "$SESSION" "${AICLI_MAX_TMUX_CLIENTS:-4}"

    perf_log tmux.attach.exec
    exec tmux -u attach-session -t "$SESSION" 2>>"$DEBUG_LOG"
}

# S2: the tier inputs. The full launch pass stores two session options: @aicli_tiers_files (the
# four files that the options block reads: the agent quirk file, the agent JSON, the workspace JSON
# and the workspace .conf, joined with "|"; a file that does not exist yet is in the list) and
# @aicli_tiers_stamp (the plugin source folder of this launcher, then name, mtime, ctime, inode and size of each file that exists). The fast path computes the stamp again.
# A change, a new file, a removed file, an atomic rewrite (new inode) or a plugin update (another source folder) gives another stamp, and the next connect runs the
# options block once.
_aicli_tiers_stamp() {
    local -a _cand=() _present=()
    local _f _out
    IFS='|' read -r -a _cand <<< "$1"
    for _f in "${_cand[@]}"; do
        [ -n "$_f" ] && [ -f "$_f" ] && _present+=("$_f")
    done
    if [ "${#_present[@]}" -eq 0 ]; then printf '%s#none' "$PLUGIN_SRC"; return 0; fi
    _out="$(stat -c '%n:%Y:%Z:%i:%s' "${_present[@]}" 2>/dev/null)" || _out="stat-failed"
    printf '%s#%s' "$PLUGIN_SRC" "${_out//$'\n'/|}"
}

# S1: fast attach. ttyd runs this whole script for every browser connection. When the tmux
# session already exists (the launch pass made it and applied the options), the connect goes
# straight to the attach: no env setup, no args load, no terminfo compile, no log call, no PHP,
# no options block. The ensure-session mode never takes this path. When the session does not
# exist, or the stamp is missing or has changed, this returns and the full path below runs.
_aicli_fast_attach() {
    local _files _stamp
    # A restricted run keeps its fixed PATH: the folder .local/bin is written by the agent (finding 5).
    [ "${AICLI_RESTRICTED_RUN:-}" = "1" ] || export PATH="${AICLI_HOME:-$USER_WORK_DIR/home}/.local/bin:/usr/local/emhttp/plugins/unraid-aicliagents/bin:$PATH"
    command -v tmux >/dev/null 2>&1 || return 0
    tmux has-session -t "$SESSION" 2>/dev/null || return 0
    _files="$(tmux show-options -t "$SESSION" -qv @aicli_tiers_files 2>/dev/null)"
    _stamp="$(tmux show-options -t "$SESSION" -qv @aicli_tiers_stamp 2>/dev/null)"
    if [ -z "$_files" ] || [ -z "$_stamp" ] || [ "$(_aicli_tiers_stamp "$_files")" != "$_stamp" ]; then
        perf_log fast.attach.skipped
        return 0
    fi
    export HOME="${AICLI_HOME:-$USER_WORK_DIR/home}"
    export TERM=xterm-256color COLORTERM=truecolor LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
    [ -d "${MOUNT_ROOT}/terminfo" ] && export TERMINFO_DIRS="${MOUNT_ROOT}/terminfo:${TERMINFO_DIRS:-}"
    perf_log fast.attach
    aicli_attach_exec
}
if [ "$AICLI_ENSURE_ONLY" -eq 0 ]; then
    _aicli_fast_attach
fi

log_aicli "DEBUG" 3 "Shell wrapper started for session $ID (Agent: $AGENT_ID). Running as $USER_NAME."

# Environment Setup
HOME_DIR="${AICLI_HOME:-$USER_WORK_DIR/home}"
TARGET_USER="${AICLI_USER:-$USER_NAME}"
ROOT_DIR="${AICLI_ROOT:-/mnt}"
HISTORY_LIMIT="${AICLI_HISTORY:-4096}"

# Issue #56: fail closed if this wrapper is invoked directly or by an older
# PHP caller while an Unraid user-share path is only a rootfs stub. Nothing
# below this point may read workspace state, cd there, or pass it to tmux -c
# until the exact backing mount exists. Exit 75 means temporary failure; the
# normal auto-launch/retry reconciliation can try again after array start.
case "$ROOT_DIR" in
    /mnt/user|/mnt/user/*)   _AICLI_REQUIRED_MOUNT="/mnt/user" ;;
    /mnt/user0|/mnt/user0/*) _AICLI_REQUIRED_MOUNT="/mnt/user0" ;;
    *)                       _AICLI_REQUIRED_MOUNT="" ;;
esac
if [ -n "$_AICLI_REQUIRED_MOUNT" ] && ! mountpoint -q "$_AICLI_REQUIRED_MOUNT" 2>/dev/null; then
    log_aicli "WARN" 1 "Workspace deferred: $_AICLI_REQUIRED_MOUNT is not mounted ($ROOT_DIR)."
    exit 75
fi

# Node.js V8 bytecode cache (Node 22+). All nine agents are Node-based, so enabling
# this shaves roughly 20% off startup by skipping require()-time re-parsing.
# Cache is pinned to a pure-tmpfs path (NOT under HOME_DIR, which is ZRAM+SquashFS
# backed and consolidates to Flash). Losing the cache on reboot is fine — same
# cost as today's cold start. Matches the existing npm_cache pruning policy in
# consolidate_layers.sh: caches never reach Flash.
export NODE_COMPILE_CACHE="${MOUNT_ROOT}/cache/node-compile"
mkdir -p "$NODE_COMPILE_CACHE" 2>/dev/null
# Hash identifies per-workspace+agent config files (envs, tmux settings). Used by both the
# new-session init block and the launch-time tmux apply step below.
ENV_HASH=$(echo -n "${ROOT_DIR}${AGENT_ID}" | md5sum | cut -d' ' -f1)

log_aicli "DEBUG" 3 "Env Setup: HOME=$HOME_DIR USER=$TARGET_USER ROOT=$ROOT_DIR"
perf_log env.setup.done

# SIDE_BY_SIDE_AGENT_INSTALLS.md Phase 3 (2026-09-09): resolve the agent's
# STABLE directory (agents/<id> — a plain directory today, a symlink to
# agents/.versions/<id>/<gen> once Phase 2 migrates it) to its REAL target
# exactly once, here, at session launch. BINARY_PRIMARY / BINARY_FALLBACK
# arrive from TerminalService built on the stable name (AgentRegistry::
# agentPath()), so freezing them verbatim — as the two lines below used to —
# freezes a path whose LAST COMPONENT can still move if the stable symlink is
# flipped later. Substituting the resolved directory in NOW turns that path
# pin into a version pin (R2): every later relaunch iteration re-checks these
# same frozen strings for existence (never re-reads BINARY_PRIMARY/FALLBACK),
# so once they name a concrete generation directory, nothing that happens to
# the stable symlink afterward can move this session.
#
# Both layouts behave identically: pre-migration, agents/<id> is a real
# directory and agent_mount_real() (readlink -f) resolves it to itself, so
# _AICLI_AGENT_REAL_DIR == _AICLI_AGENT_STABLE_DIR and the substitution below
# is a byte-for-byte no-op — the expected, unchanged state on this box today.
_AICLI_RESOLVE_PATHS_SH="$PLUGIN_SRC/scripts/storage/resolve_paths.sh"
# shellcheck source=./storage/resolve_paths.sh
[ -f "$_AICLI_RESOLVE_PATHS_SH" ] && source "$_AICLI_RESOLVE_PATHS_SH" 2>/dev/null
_AICLI_AGENT_STABLE_DIR=""
_AICLI_AGENT_REAL_DIR=""
if command -v agent_mount_real >/dev/null 2>&1 && [ -n "$AGENT_ID" ] && [ "$AGENT_ID" != "terminal" ]; then
    _AICLI_AGENT_STABLE_DIR="$(agent_mount "$AGENT_ID" 2>/dev/null)"
    _AICLI_AGENT_REAL_DIR="$(agent_mount_real "$AGENT_ID" 2>/dev/null)"
fi

# _aicli_pin_to_real_generation <raw-path>
# Rewrites <raw-path> to route through the resolved generation directory when
# it is rooted under the stable agent directory; echoes it unchanged otherwise
# (empty, a bare proxy command with no '/', or already outside the agent
# tree). Pure string substitution — no filesystem access beyond what already
# happened above, so it is cheap to call for all three frozen binaries.
_aicli_pin_to_real_generation() {
    local raw="$1"
    if [ -n "$raw" ] && [ -n "$_AICLI_AGENT_STABLE_DIR" ] && [ -n "$_AICLI_AGENT_REAL_DIR" ] \
       && [ "$_AICLI_AGENT_STABLE_DIR" != "$_AICLI_AGENT_REAL_DIR" ] \
       && [[ "$raw" == "$_AICLI_AGENT_STABLE_DIR"/* ]]; then
        printf '%s' "${_AICLI_AGENT_REAL_DIR}${raw#"$_AICLI_AGENT_STABLE_DIR"}"
    else
        printf '%s' "$raw"
    fi
}

# Freeze variables for tmux
# Fix A: freeze the two RAW binary paths (primary + fallback) so the run-loop
# can re-resolve on every relaunch. BINARY is the *already-resolved* effective
# path (primary if it existed at session-open, else fallback). An in-place
# upgrade that drops cli.js and adds bin/claude.exe would leave frozen_binary
# pointing at the deleted file; re-resolving from BINARY_PRIMARY / BINARY_FALLBACK
# picks up the new layout without closing the workspace. This survival
# mechanism is preserved UNCHANGED and stays scoped to the one generation
# pinned above — it re-resolves the binary LAYOUT inside that generation, it
# never re-resolves the generation itself.
#
frozen_binary_primary="${BINARY_PRIMARY:-$BINARY}"
frozen_binary_fallback="${BINARY_FALLBACK:-}"
# _stable variants keep the ORIGINAL (un-pinned) paths, still expressed
# through the stable name, captured BEFORE the pin substitution below
# overwrites frozen_binary_primary/frozen_binary_fallback in place. They are
# exported below too, and used ONLY as a degrade path in the run-loop if the
# pinned generation directory itself is ever reaped out from under a
# still-open session (R4's "missing pinned version" case) — never for
# ordinary layout re-resolution.
frozen_binary_primary_stable="$frozen_binary_primary"
frozen_binary_fallback_stable="$frozen_binary_fallback"
frozen_binary_primary="$(_aicli_pin_to_real_generation "$frozen_binary_primary")"
frozen_binary_fallback="$(_aicli_pin_to_real_generation "$frozen_binary_fallback")"
frozen_binary="$(_aicli_pin_to_real_generation "$BINARY")"
# The pinned generation directory itself (empty when this agent has no
# resolvable stable/real split, e.g. "terminal" or an uninstalled agent) —
# the run-loop's degrade check below tests this directory's continued
# existence, not the individual binary files, so a mid-generation shape
# change (cli.js -> bin/claude.exe) is never mistaken for the whole
# generation vanishing.
frozen_agent_generation_dir="$_AICLI_AGENT_REAL_DIR"
# The stable dir too, so the run-loop's degrade check can tell "this agent was
# never installed / has no versioned split" (generation dir == stable dir,
# always the case pre-migration) apart from "the pinned generation was reaped
# out from under a live session" (generation dir != stable dir, and the
# generation dir is gone) — only the latter should log R4's degrade WARN.
frozen_agent_stable_dir="$_AICLI_AGENT_STABLE_DIR"
frozen_resume_cmd="$RESUME_CMD"
frozen_resume_latest="$RESUME_LATEST"
frozen_agent_name="${AGENT_NAME:-$AGENT_ID}"
frozen_chat_id="$AICLI_CHAT_SESSION_ID"
frozen_env_prefix="$ENV_PREFIX"
# Plugin-level default flags for this agent (e.g. codex sandbox overrides).
# These are NOT user-editable workspace args — they are always prepended to the
# launch command and survive fresh + resume + resume-latest paths.
frozen_plugin_args="${PLUGIN_ARGS:-}"

# Load effective CLI args (workspace → agent-level → "").
# Mirrors ArgsService::getEffectiveArgs() without namespaced PHP classes.
# Bug #536: when the JSON file exists but is corrupt (truncated, invalid UTF-8,
# concurrent write torn open before AtomicWriteService landed in v04+), php's
# json_decode silently returns null and frozen_effective_args becomes empty.
# The user has no idea their args file is bad. Tee a WARN to debug.log.
frozen_effective_args=""
_ARGS_WS_HASH=$(echo -n "$ROOT_DIR" | md5sum | cut -d' ' -f1)
_ARGS_WS_FILE="$HOME_DIR/.aicli/args/args_ws_${_ARGS_WS_HASH}_${AGENT_ID}.json"
_ARGS_AGENT_FILE="$HOME_DIR/.aicli/args/args_agent_${AGENT_ID}.json"
# docs/specs/AGENT_SPAWN_WORKSPACE.md R5: a helper workspace has its own flags file, named by the
# workspace id. It wins over the folder file, so two workspaces of one agent in one folder keep
# their own flags. Same name rule as ArgsService::getIdArgsPath().
_ARGS_ID_SAFE=$(printf '%s' "$ID" | tr -cd 'A-Za-z0-9_-')
_ARGS_ID_FILE=""
[ -n "$_ARGS_ID_SAFE" ] && _ARGS_ID_FILE="$HOME_DIR/.aicli/args/args_id_${_ARGS_ID_SAFE}.json"
# Finding 7: a restricted run does not read flags from its own home (it can write there, and root's flags file is in a home
# it cannot see). Root writes the flags in a root-only folder that the view shows read-only, and names the file here.
if [ "${AICLI_RESTRICTED_RUN:-}" = "1" ]; then
    _ARGS_ID_FILE="${AICLI_ARGS_ID_FILE:-}"
fi
_load_args_with_warn() {
    local _path="$1" _errfile
    # A random name made with O_EXCL: the folder is world-writable, and a fixed name with the process id could be a planted link.
    _errfile="$(mktemp "${MOUNT_ROOT}/.args-load-err.XXXXXX" 2>/dev/null)" || _errfile=/dev/null
    php -r "
        \$raw = @file_get_contents('$_path');
        if (\$raw === false) { fwrite(STDERR, 'unreadable'); exit; }
        \$d = json_decode(\$raw, true);
        if (\$d === null && trim(\$raw) !== '') { fwrite(STDERR, 'parse_error: ' . json_last_error_msg()); exit; }
        if (!is_array(\$d)) { fwrite(STDERR, 'not_array'); exit; }
        echo \$d['args'] ?? '';
    " 2>"$_errfile"
    local _err
    _err="$(cat "$_errfile" 2>/dev/null)"
    # Finding 8 of the second review: when mktemp fails the fallback is /dev/null, and it must never be removed.
    [ "$_errfile" = /dev/null ] || rm -f "$_errfile"
    [ -n "$_err" ] && log_aicli "WARN" 1 "Failed to load args from $_path: $_err — proceeding with empty args"
}
if [ -n "$_ARGS_ID_FILE" ] && [ -f "$_ARGS_ID_FILE" ]; then
    frozen_effective_args=$(_load_args_with_warn "$_ARGS_ID_FILE")
elif [ "${AICLI_RESTRICTED_RUN:-}" = "1" ]; then
    log_aicli "WARN" 1 "Restricted run $ID has no flags file; it starts without flags only if the profile has none."
elif [ -f "$_ARGS_WS_FILE" ]; then
    frozen_effective_args=$(_load_args_with_warn "$_ARGS_WS_FILE")
elif [ -f "$_ARGS_AGENT_FILE" ]; then
    frozen_effective_args=$(_load_args_with_warn "$_ARGS_AGENT_FILE")
fi

# D-154: Lazy-Mount Recovery Pre-flight
# Ensure ~/home is valid and writable for this user context before starting terminal. 
# Only attempt PHP-based repairs IF we are still root; otherwise, just warn and proceed
# as we can no longer perform administrative mounts.
if ! mountpoint -q "$HOME_DIR" || [ ! -w "$HOME_DIR" ]; then
    if [ "$USER_NAME" = "root" ]; then
        log_aicli "WARN" 1 "Mount invalid or read-only. Triggering self-healing for $USER_NAME..."
        php "$BRIDGE_SCRIPT" init "$USER_NAME" true > /dev/null 2>&1
    else
        log_aicli "WARN" 1 "Mount invalid for $USER_NAME. Cannot repair from non-root context. Proceeding with caution."
    fi
fi

export HOME="$HOME_DIR"

# Kimi Code defaults to replacing its own executable during update checks.
# The plugin owns agent versions, so enforce that one vendor setting while
# preserving every unrelated user setting in tui.toml.
_aicli_set_toml_bool() {
    local file="$1" section="$2" key="$3" value="$4"
    local dir tmp
    dir=$(dirname "$file")
    mkdir -p "$dir" 2>/dev/null || return 1
    tmp="${file}.aicli.$$"
    if [ ! -f "$file" ] || ! grep -Eq "^[[:space:]]*\\[${section}\\][[:space:]]*$" "$file"; then
        [ -s "$file" ] && printf '\n' >> "$file"
        printf '[%s]\n%s = %s\n' "$section" "$key" "$value" >> "$file"
        return 0
    fi
    awk -v section="$section" -v key="$key" -v value="$value" '
        BEGIN { inside=0; written=0 }
        /^\[[^]]+\][[:space:]]*$/ {
            if (inside && !written) { print key " = " value; written=1 }
            inside=($0 == "[" section "]")
        }
        inside && $0 ~ "^[[:space:]]*" key "[[:space:]]*=" {
            if (!written) print key " = " value
            written=1
            next
        }
        { print }
        END { if (inside && !written) print key " = " value }
    ' "$file" > "$tmp" && mv -f "$tmp" "$file"
}

if [ "$AGENT_ID" = "kimi-code" ]; then
    _aicli_set_toml_bool "$HOME_DIR/.kimi-code/tui.toml" upgrade auto_install false || \
        log_aicli "WARN" 1 "Could not disable Kimi Code self-update; plugin-managed version may drift"
fi
mkdir -p "$HOME" 2>/dev/null
# #110: WORK_CWD is where the agent RUNS (the pool path when the operator opted in
# for a cache-only share); ROOT_DIR stays the workspace identity for hashes/resume.
WORK_CWD="${AICLI_CWD:-$ROOT_DIR}"
[ -d "$WORK_CWD" ] || WORK_CWD="$ROOT_DIR"
cd "$WORK_CWD" || cd "$ROOT_DIR" || cd /mnt || echo "Warning: Could not enter $WORK_CWD"
export PATH="$HOME/.local/bin:/usr/local/emhttp/plugins/unraid-aicliagents/bin:$PATH"
export TERM=xterm-256color
export COLORTERM=truecolor
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8

# Bundled terminfo: Unraid ships a minimal terminfo db (xterm* only) with no
# tmux/tmux-256color entry, so default-terminal=tmux-256color would fail with
# "missing or unsuitable terminal". Compile our bundled source once into a tmpfs
# dir and expose it via TERMINFO_DIRS (trailing ':' keeps the system db, where
# xterm-256color lives). Guarded: only if tic exists and it isn't already built.
_AICLI_TI_DIR="${MOUNT_ROOT}/terminfo"
_AICLI_TI_SRC="$PLUGIN_SRC/terminfo/tmux.terminfo"
if [ ! -e "$_AICLI_TI_DIR/t/tmux-256color" ] && command -v tic >/dev/null 2>&1 && [ -f "$_AICLI_TI_SRC" ]; then
    mkdir -p "$_AICLI_TI_DIR" 2>/dev/null
    if tic -x -o "$_AICLI_TI_DIR" "$_AICLI_TI_SRC" >/dev/null 2>&1; then
        log_aicli "DEBUG" 3 "compiled bundled tmux terminfo -> $_AICLI_TI_DIR"
    else
        log_aicli "WARN" 1 "tic failed to compile bundled tmux terminfo (tmux-256color unavailable)"
    fi
fi
[ -d "$_AICLI_TI_DIR" ] && export TERMINFO_DIRS="${_AICLI_TI_DIR}:${TERMINFO_DIRS:-}"

# Default tmux TERM type: prefer tmux-256color (bundled terminfo — enables
# italics) when it actually resolves; fall back to the always-present
# xterm-256color if the terminfo couldn't be compiled (e.g. tic missing). This
# is the built-in default for new/uncustomised agents; a user override via
# apply-tmux-json still wins. Mirrors TmuxService::BUILTIN['default-terminal']
# (the parity test treats this key's value as runtime-variable, like history-limit).
_AICLI_DEFTERM="xterm-256color"
infocmp tmux-256color >/dev/null 2>&1 && _AICLI_DEFTERM="tmux-256color"

# Cleanup on exit
cleanup() {
    log_aicli "DEBUG" 3 "Cleaning up tmux session $SESSION"
    tmux kill-session -t "$SESSION" 2>/dev/null
}

# Trap exit to ensure sync happens on last session close (Managed by PHP counting)
trap_exit() {
    log_aicli "DEBUG" 3 "Terminal session $ID closing."
    # Safe PHP bridge: handle reference decrement and potential final sync
    php "$BRIDGE_SCRIPT" stop "$ID" true 2>/dev/null
    cleanup
}
# R-B1: in --ensure-session (headless) mode this wrapper process exits the moment
# the DETACHED tmux session is created. We must NOT run trap_exit then — cleanup()
# kills the very session we just spawned (the agent would die headless and the
# orphan-sweep would later reap the ttyd). The trap is only meaningful for the
# interactive attach path, where the wrapper lives for the duration of the client.
if [ "$AICLI_ENSURE_ONLY" -eq 0 ]; then
    trap trap_exit EXIT
fi

# (The tmux socket directory, the socket adoption and the uid-dir check run near the top of this script, before the fast attach.)

# Bug #1054 root cause: tmux uses the user's login SHELL (from /etc/passwd, or
# $SHELL env if set) to run the session's command. System users created with
# `useradd -r` (typical for sandboxed agent accounts like `aicliagent`) have
# /bin/false or /sbin/nologin as their login shell -- tmux then invokes
# RUN_SCRIPT via /bin/false, which exits immediately, the session terminates,
# and the tmux server exits with "no server running" before aicli-shell.sh's
# has-session check fires. The fix: force $SHELL to /bin/bash before any tmux
# call so the session command runs under bash regardless of /etc/passwd shell.
# This is the in-flight fix that works for any sandbox user the admin picks.
export SHELL=/bin/bash

# TMUX EXECUTION
if ! command -v tmux >/dev/null 2>&1; then
    echo -e "\n\n\033[1;31m[FATAL ERROR]\033[0m Required dependency 'tmux' is missing or not executable."
    echo -e "\033[0;33mThis usually happens if the Agent Storage image failed to mount,\033[0m"
    echo -e "\033[0;33mor if the plugin needs to be repaired.\033[0m\n"
    echo -e "Please check the settings page and click 'Repair Plugin'.\n"
    read -t 8 -p "Press ENTER to exit..."
    exit 1
fi

if ! tmux has-session -t "$SESSION" 2>/dev/null; then
    # AGENT_RUN_ENTRY_POINT.md R17: a run as the run user lives in a private disk view that only the plugin's
    # ensure-session step builds. The browser attach runs OUTSIDE that view, so it must never start a session. It
    # refuses here, and the workspace is started again from the plugin, which builds the view first.
    if [ "${AICLI_RESTRICTED_RUN:-}" = "1" ] && [ "$AICLI_ENSURE_ONLY" -eq 0 ]; then
        log_aicli "ERROR" 1 "Restricted run $ID has no live session. The attach does not start one outside the private disk view."
        echo "This script run has no live session. Restart the workspace from the plugin."
        sleep 5
        exit 1
    fi
    # Forgejo #433 (docs/specs/WORKSPACE_SESSION_END_TRACE.md): the session is gone. If the tmux server that held it
    # is gone too, with no "session closed" line in the debug log, it was killed from outside (a signal, the
    # out-of-memory killer) or the box restarted. Say so, so a vanished session can be explained.
    _OLD_SRV_PID_FILE="${TMUX_TMPDIR:-${MOUNT_ROOT}/tmux/s-$ID}/server.pid"
    if [ -r "$_OLD_SRV_PID_FILE" ]; then
        _OLD_SRV_PID="$(cat "$_OLD_SRV_PID_FILE" 2>/dev/null)"
        if [ -n "$_OLD_SRV_PID" ] && ! kill -0 "$_OLD_SRV_PID" 2>/dev/null; then
            log_aicli "WARN" 2 "The tmux server (pid $_OLD_SRV_PID) that held session $SESSION ended with no 'session closed' record. It was killed from outside or the box restarted. Last kernel kill lines: $(dmesg 2>/dev/null | grep -i -E 'killed process|out of memory' | tail -n 2 | tr '\n' ';')"
        fi
    fi
    if [ "${AICLI_RESTRICTED_RUN:-}" = "1" ]; then
        # The run user's home is the only writable state path bound into its view.
        RUN_SCRIPT="$AICLI_HOME/aicli-run-$ID.sh"
    else
        RUN_SCRIPT="$USER_WORK_DIR/aicli-run-$ID.sh"
    fi

    # 1. Minimal Header (Safe injections only)
    # #638: this file will hold every secret. Create it private (umask 077, mode
    # 0600) BEFORE the first byte is written, so it is never readable by others,
    # not even for a moment. It becomes 0700 (owner only) just before launch.
    rm -f "$RUN_SCRIPT" 2>/dev/null
    ( umask 077; : > "$RUN_SCRIPT" )
    chmod 600 "$RUN_SCRIPT"
    echo "#!/bin/bash" > "$RUN_SCRIPT"
    printf 'export PLUGIN_SRC=%q\n' "$PLUGIN_SRC" >> "$RUN_SCRIPT"
    # #834: the quoted blocks below use ${MOUNT_ROOT} for the debug log, the crash records
    # and the close/closing/auto-reload sentinels. tmux does not pass this shell's
    # variables on, so set it here; without it every path became /<name> at the root.
    printf 'export MOUNT_ROOT=%q\n' "$MOUNT_ROOT" >> "$RUN_SCRIPT"

    # Inject the logging function into the child script for tmux diagnostics, with the level
    # filter and the direct debug.log writer (S3), and the PHP cache helper (S5, S7). `declare -f`
    # copies the very functions that are defined at the top of this file, so the launcher and the
    # run script share one source. The child reads the level at its start and again at each
    # relaunch of the agent (the run loop calls _aicli_read_log_cfg).
    printf 'export AICLI_FLASH_ROOT=%q\n' "$AICLI_FLASH_ROOT" >> "$RUN_SCRIPT"
    printf 'CONFIG_FILE=%q\n' "$CONFIG_FILE" >> "$RUN_SCRIPT"
    printf '_AICLI_LOG_CTX=SHELL-CHILD\n' >> "$RUN_SCRIPT"
    declare -f _aicli_php_cache_init php _aicli_read_log_cfg log_aicli >> "$RUN_SCRIPT"
    printf '_aicli_read_log_cfg\n' >> "$RUN_SCRIPT"
    cat << 'FUNCOEF' >> "$RUN_SCRIPT"
perf_log() {
    # Optional $2 is appended as a free-form extra field (issue #71 uses it for
    # `run.exit ... rc=<code>`). AICLI_PERF_LOG override exists for unit tests
    # only — production always writes the shared perf.log.
    printf '%s %s %s %s%s\n' "$(date +%s%N | cut -c1-13)" "$1" "$AGENT_ID" "$AICLI_SESSION_ID" "${2:+ $2}" >> "${AICLI_PERF_LOG:-${MOUNT_ROOT}/perf.log}" 2>/dev/null
}
FUNCOEF

    # RESPONSIVE_PRIORITY.md R4: the tmux server may run at nice -5 (setting "Keep the
    # terminal responsive"). The agent must not inherit that. Put it back to nice 0 and
    # ionice best-effort 4 before anything else runs. Harmless when the nice value is
    # already 0 or higher: the block then does nothing.
    cat << 'PRIOEOF' >> "$RUN_SCRIPT"
# RESPONSIVE_PRIORITY begin
_aicli_nice="$(nice 2>/dev/null)"
case "$_aicli_nice" in
    -*) renice -n 0 -p $$ >/dev/null 2>&1; ionice -c2 -n4 -p $$ >/dev/null 2>&1 ;;
esac
unset _aicli_nice
# RESPONSIVE_PRIORITY end
PRIOEOF

    # AGENT_TEMP_FOLDER.md R3: when the setting "Agent temporary folder" is not RAM, the agent
    # keeps its temporary files in <folder>/<user>. agent-tmp.sh prints that folder, or prints
    # nothing (and logs one warning) when the folder is not ready. A launch never waits for it.
    # AGENT_TMP begin
    _agent_tmp_dir=""
    if [ -f "$PLUGIN_SRC/scripts/agent-tmp.sh" ]; then
        _agent_tmp_dir="$(bash "$PLUGIN_SRC/scripts/agent-tmp.sh" resolve "${TARGET_USER:-root}" 2>/dev/null)"
    fi
    if [ -n "$_agent_tmp_dir" ]; then
        printf 'export TMPDIR=%q\n' "$_agent_tmp_dir" >> "$RUN_SCRIPT"
        printf 'export CLAUDE_CODE_TMPDIR=%q\n' "$_agent_tmp_dir" >> "$RUN_SCRIPT"
    fi
    # #808: Codex refuses to make its helper commands when CODEX_HOME is under the temporary
    # folder of the host (TMPDIR, or /tmp when TMPDIR is unset), and every agent home here is
    # under the plugin state folder in RAM. In RAM mode Codex gets its own RAM folder next to the homes,
    # not above them: ${MOUNT_ROOT}/agent-tmp/<user>, mode 700, owned by the user. Other agents
    # keep /tmp. A problem logs nothing and never stops the launch (Codex only warns then).
    # #822: OpenCode 2 keeps its temporary data in $TMPDIR/opencode (checked: it honours TMPDIR), so it gets the same RAM folder.
    if [ -z "$_agent_tmp_dir" ] && { [ "$AGENT_ID" = "codex-cli" ] || [ "$AGENT_ID" = "opencode2" ]; }; then
        _codex_tmp_user="${TARGET_USER:-root}"
        case "$_codex_tmp_user" in ''|*[!A-Za-z0-9._-]*) _codex_tmp_user="" ;; esac
        if [ -n "$_codex_tmp_user" ]; then
            _codex_tmp_dir="${MOUNT_ROOT}/agent-tmp/${_codex_tmp_user}"
            if mkdir -p "${MOUNT_ROOT}/agent-tmp" 2>/dev/null && chmod 711 "${MOUNT_ROOT}/agent-tmp" 2>/dev/null \
               && mkdir -p -m 700 "$_codex_tmp_dir" 2>/dev/null && chmod 700 "$_codex_tmp_dir" 2>/dev/null; then
                if [ "$(id -u)" = "0" ] && [ "$_codex_tmp_user" != "root" ]; then
                    chown "$_codex_tmp_user" "$_codex_tmp_dir" 2>/dev/null || true
                fi
                [ -w "$_codex_tmp_dir" ] && printf 'export TMPDIR=%q\n' "$_codex_tmp_dir" >> "$RUN_SCRIPT"
            fi
        fi
    fi
    # AGENT_TMP end

    # #822 OpenCode 2: v2 migrates the database of OpenCode 1 (~/.local/share/opencode) and reads
    # mcp.servers where v1 reads mcp.<name>. So v2 gets its own XDG folders and never touches v1.
    # v2 honours all four variables (checked with `opencode debug paths`, 2.2.0). Data, state and
    # config sit under .local/share so the persistent home keeps them; the cache sits in .cache
    # (not kept, as for every agent). One set for each user, shared by the v2 workspaces of that
    # user: the login (auth.json) is in the data folder. The Config Hub writes the global
    # config to the config folder below (Opencode2Projector::XDG_ROOT). Spec: OPENCODE_V2_AGENT.md.
    # OPENCODE2_XDG begin
    if [ "$AGENT_ID" = "opencode2" ]; then
        _oc2_root="$HOME_DIR/.local/share/opencode2-xdg"
        printf 'mkdir -p %q %q %q %q %q 2>/dev/null\n' \
            "$_oc2_root/data" "$_oc2_root/state" "$_oc2_root/config/opencode" \
            "$HOME_DIR/.cache/opencode2-xdg/opencode" "$HOME_DIR/.local/share/opencode2-xdg" >> "$RUN_SCRIPT"
        printf 'export XDG_DATA_HOME=%q\n' "$_oc2_root/data" >> "$RUN_SCRIPT"
        printf 'export XDG_STATE_HOME=%q\n' "$_oc2_root/state" >> "$RUN_SCRIPT"
        printf 'export XDG_CONFIG_HOME=%q\n' "$_oc2_root/config" >> "$RUN_SCRIPT"
        printf 'export XDG_CACHE_HOME=%q\n' "$HOME_DIR/.cache/opencode2-xdg" >> "$RUN_SCRIPT"
        unset _oc2_root
    fi
    # OPENCODE2_XDG end

    printf 'export AICLI_SESSION_ID=%q\n' "$ID" >> "$RUN_SCRIPT"
    # R-005 (#583): the exit recorder reads BRIDGE_SCRIPT and ID. The run script starts under a
    # fresh tmux server, so plain variables of this wrapper do not reach it. Export them.
    printf 'export BRIDGE_SCRIPT=%q\n' "$BRIDGE_SCRIPT" >> "$RUN_SCRIPT"
    printf 'export ID=%q\n' "$ID" >> "$RUN_SCRIPT"
    # Relay's MCP child is launched by the agent from this generated script,
    # not from the original ttyd command. Preserve the launch-bound command
    # here so reconnects and shell relaunches retain the complete Relay context.
    # Pin Relay to this immutable launcher generation. A later hot-swap may
    # advance the mutable src link while this workspace is still running.
    # One word, the executable script itself (it starts with "#!/usr/bin/env php"), so
    # "$AICLI_RELAY_COMMAND" inbox works quoted as well as unquoted (#735). A two-word
    # "php <path>" value fails when an agent quotes it.
    # A restricted run gets neither command (R18, finding 13): PHP removed them, and a default value must not bring them back.
    [ "${AICLI_RESTRICTED_RUN:-}" = "1" ] || printf 'export AICLI_RELAY_COMMAND=%q\n' "${AICLI_RELAY_COMMAND:-$PLUGIN_SRC/scripts/relay-agent.php}" >> "$RUN_SCRIPT"
    # Plugin management (read-only) self-service, pinned the same way and for the
    # same reason. This is the fallback for an agent with no MCP support — pi-coder
    # is HubProjector::MCP_EXEMPT (the plugin projects no MCP config for it) — and it is
    # also what a user's own script calls. Spec: docs/specs/PLUGIN_MANAGEMENT_TOOLS.md
    [ "${AICLI_RESTRICTED_RUN:-}" = "1" ] || printf 'export AICLI_ADMIN_COMMAND=%q\n' "${AICLI_ADMIN_COMMAND:-$PLUGIN_SRC/scripts/admin-agent.php}" >> "$RUN_SCRIPT"
    # (Relay 'watch' mode retired 2026-08-22: every agent now receives the
    # readiness-gated paste, so no per-session watcher command is injected here.
    # The old watcher env var + relay-watch.sh were removed — the watcher died on
    # every resume and duplicated the paste. History in git.)
    # Bind the remaining identity variables to THIS session. Without these two the
    # run script never sets them, so they arrive only by inheritance — and a tmux
    # session started later picks up whatever the tmux server was launched with,
    # i.e. the first workspace to start. A Codex workspace in saas-businessOS was
    # observed running with AICLI_ROOT=/mnt/user/DevelopmentProjects/mvp-dmoe and
    # AICLI_CHAT_SESSION_ID=DMoE. AICLI_ROOT is used as the cd fallback below, so a
    # leaked value lands the agent in another workspace's directory. Issue #124.
    printf 'export AICLI_ROOT=%q\n' "${AICLI_ROOT:-/mnt}" >> "$RUN_SCRIPT"
    printf 'export AICLI_CHAT_SESSION_ID=%q\n' "$frozen_chat_id" >> "$RUN_SCRIPT"
    printf 'export AGENT_ID=%q\n' "$AGENT_ID" >> "$RUN_SCRIPT"
    printf 'export HOME=%q\n' "$HOME_DIR" >> "$RUN_SCRIPT"

    # Bug #1042: bring up the per-user Secret Service (org.freedesktop.secrets)
    # so keyring-using agents — Antigravity CLI today — can persist their auth
    # token instead of re-prompting every session. Idempotent and reused per
    # user; best-effort — on failure the agent just falls back to interactive
    # auth. See docs/specs/SECRET_SERVICE.md.
    _SS_ADDR=$(bash "$PLUGIN_SRC/secret-service/secret-service-up.sh" "$USER_NAME" "$HOME_DIR" 2>>"$DEBUG_LOG")
    if [ -n "$_SS_ADDR" ]; then
        printf 'export DBUS_SESSION_BUS_ADDRESS=%q\n' "$_SS_ADDR" >> "$RUN_SCRIPT"
        log_aicli "DEBUG" 3 "Secret Service ready for $USER_NAME: $_SS_ADDR"
    else
        log_aicli "WARN" 1 "Secret Service unavailable — keyring-using agents may re-prompt for auth"
    fi
    
    # D-170: Ensure agent binaries are in the PATH for the child shell.
    # D-404 (#55): The "terminal" (drop-in shell) workspace has no single frozen
    # binary, so we previously shipped the shell without any agent on PATH. That
    # made `goose --help`, `gemini -p ...`, `qwen configure` etc. fail with
    # "command not found" even though the binaries were installed. For the
    # terminal case we now union every installed agent's bin/ and
    # node_modules/.bin/ into PATH so the user can run any agent ad-hoc.
    if [ -n "$frozen_binary" ]; then
        AGENT_BIN_DIR=$(dirname "$frozen_binary")
        SESSION_PATH="$HOME_DIR/.local/bin:$AGENT_BIN_DIR:$PATH"
    else
        AGENT_PATH_EXTRA=""
        for d in /usr/local/emhttp/plugins/unraid-aicliagents/agents/*/bin \
                 /usr/local/emhttp/plugins/unraid-aicliagents/agents/*/node_modules/.bin; do
            [ -d "$d" ] && AGENT_PATH_EXTRA="$AGENT_PATH_EXTRA:$d"
        done
        SESSION_PATH="$HOME_DIR/.local/bin:${AGENT_PATH_EXTRA:+${AGENT_PATH_EXTRA#:}:}$PATH"
    fi
    # #972: the share-filesystem guard folder goes FIRST on the path, in every branch above. It also reaches
    # AICLI_MANAGED_PATH below, so a login shell keeps it (the profile.d restore reads that variable).
    _aicli_guard_setup
    _aicli_guard_view_setup
    printf 'export PATH=%q\n' "$SESSION_PATH" >> "$RUN_SCRIPT"
    # GitHub #12: a Bash LOGIN shell started inside this session (an agent's own
    # shell tool running `bash -lc`, or ssh-attach.sh's `bash --login` fallback)
    # makes Unraid's /etc/profile re-run, which unconditionally resets HOME and
    # PATH back to host defaults (export HOME=/root; PATH=/usr/local/bin:...) and
    # cd's to /root. AICLI_MANAGED_PATH survives that reset (/etc/profile never
    # touches it), so the plugin's own /etc/profile.d/aicliagents.sh — which
    # /etc/profile always sources LAST, after its own reset — can restore PATH
    # from it. HOME_DIR (already exported below) and AICLI_CWD/AICLI_WORKSPACE_PATH
    # (already exported above) do the same job for HOME and the working directory;
    # see shell-integration.sh for the restore side.
    printf 'export AICLI_MANAGED_PATH=%q\n' "$SESSION_PATH" >> "$RUN_SCRIPT"
    
    printf 'export frozen_binary=%q\n' "$frozen_binary" >> "$RUN_SCRIPT"
    # Fix A: export both raw paths so the run-loop can re-resolve frozen_binary
    # on every iteration (survives cli.js → native-binary in-place upgrades).
    printf 'export frozen_binary_primary=%q\n' "$frozen_binary_primary" >> "$RUN_SCRIPT"
    printf 'export frozen_binary_fallback=%q\n' "$frozen_binary_fallback" >> "$RUN_SCRIPT"
    # SIDE_BY_SIDE_AGENT_INSTALLS.md Phase 3: export the un-pinned stable paths
    # and the pinned generation directory too, so the run-loop's degrade check
    # (R4) can fall back to the stable name if the pinned generation is ever
    # reaped out from under this session.
    printf 'export frozen_binary_primary_stable=%q\n' "$frozen_binary_primary_stable" >> "$RUN_SCRIPT"
    printf 'export frozen_binary_fallback_stable=%q\n' "$frozen_binary_fallback_stable" >> "$RUN_SCRIPT"
    printf 'export frozen_agent_generation_dir=%q\n' "$frozen_agent_generation_dir" >> "$RUN_SCRIPT"
    printf 'export frozen_agent_stable_dir=%q\n' "$frozen_agent_stable_dir" >> "$RUN_SCRIPT"
    printf 'export frozen_resume_cmd=%q\n' "$frozen_resume_cmd" >> "$RUN_SCRIPT"
    printf 'export frozen_resume_latest=%q\n' "$frozen_resume_latest" >> "$RUN_SCRIPT"
    printf 'export frozen_plugin_args=%q\n' "$frozen_plugin_args" >> "$RUN_SCRIPT"
    printf 'export frozen_chat_id=%q\n' "$frozen_chat_id" >> "$RUN_SCRIPT"
    printf 'export AICLI_ENV_HASH=%q\n'  "$ENV_HASH"       >> "$RUN_SCRIPT"
    printf 'export frozen_effective_args=%q\n' "$frozen_effective_args" >> "$RUN_SCRIPT"
    # WP #273: export the args file paths too so the run-loop can re-read
    # them on every Ctrl-C relaunch without re-computing the md5(path) hash.
    # Lets the user change workspace args from the UI and have them apply on
    # the next agent launch (no workspace destroy needed).
    printf 'export AICLI_ARGS_ID_FILE=%q\n' "$_ARGS_ID_FILE" >> "$RUN_SCRIPT"
    if [ "${AICLI_RESTRICTED_RUN:-}" = "1" ]; then
        # The run loop (inside tmux) needs these names: the first prompt is read from the private task folder.
        printf 'export AICLI_RESTRICTED_RUN=1\n' >> "$RUN_SCRIPT"
        printf 'export AICLI_TASK_DIR=%q\n' "${AICLI_TASK_DIR:-}" >> "$RUN_SCRIPT"
    fi
    printf 'export AICLI_ARGS_WS_FILE=%q\n' "$_ARGS_WS_FILE" >> "$RUN_SCRIPT"
    printf 'export AICLI_ARGS_AGENT_FILE=%q\n' "$_ARGS_AGENT_FILE" >> "$RUN_SCRIPT"
    printf 'export DEBUG_LOG=%q\n' "$DEBUG_LOG" >> "$RUN_SCRIPT"
    
    # D-204: Pass Node Memory limits to the child script.
    # Issue #71: claude-code gets an 8 GB old-space default — multi-subagent
    # sessions inside one claude process are the suspected JS-heap OOM behind
    # the 2026-07-16/17 unexplained process deaths, and the host has 62 GB.
    # Other agents keep the 4 GB default. AICLI_NODE_MEMORY still overrides
    # either default when a caller sets it; NODE_OPTIONS itself is a RESERVED
    # key in EnvService, so the 5-tier user env merge can never clobber this.
    if [ "$AGENT_ID" = "claude-code" ]; then
        MEM_LIMIT="${AICLI_NODE_MEMORY:-8192}"
    else
        MEM_LIMIT="${AICLI_NODE_MEMORY:-4096}"
    fi
    printf 'export NODE_OPTIONS=%q\n' "--max-old-space-size=$MEM_LIMIT" >> "$RUN_SCRIPT"

    # D-59: Prevent Auto-Updates on Launch (agent-specific)
    # Only set the disable variable for the agent actually being launched.
    printf 'export DISABLE_AUTOUPDATER=1\n' >> "$RUN_SCRIPT"
    printf 'export DISABLE_UPDATE_CHECK=1\n' >> "$RUN_SCRIPT"
    case "$AGENT_ID" in
        gemini-cli)  printf 'export GEMINI_CLI_DISABLE_AUTO_UPDATE=true\n' >> "$RUN_SCRIPT" ;;
        opencode|opencode2) printf 'export OPENCODE_DISABLE_AUTOUPDATE=true\n' >> "$RUN_SCRIPT" ;;
        nanocoder)   printf 'export NANOCODER_DISABLE_AUTO_UPDATE=1\n' >> "$RUN_SCRIPT" ;;
        kilocode)    printf 'export KILO_DISABLE_AUTO_UPDATE=1\n' >> "$RUN_SCRIPT" ;;
        pi-coder)    printf 'export PI_CODER_DISABLE_AUTO_UPDATE=1\n' >> "$RUN_SCRIPT" ;;
    esac

    # 2. Minimalist Logic (Atomic Environment Injection)
    # D-159: Variables are injected PRIOR to the here-doc to prevent environmental leakage
    printf 'export USER_NAME=%q\n' "$USER_NAME" >> "$RUN_SCRIPT"
    printf 'export HOME_DIR=%q\n' "$HOME_DIR" >> "$RUN_SCRIPT"

    # WP #736: Inject the full 5-tier effective env from EnvService — single
    # source of truth (TerminalService merges the same map for its $envStr).
    # effective-env-export.php invokes EnvService::buildEffectiveEnv for both
    # this initial export and the hot-reload function embedded below.
    # Tier order, later wins per key:
    #   source.env < secrets.cfg < workspace secrets < agent envs < workspace envs
    # Reserved names (PATH, HOME, AICLI_*, frozen_*, …) are filtered out so a
    # user setting can't clobber plugin-internal state. Closes the latent
    # dead-write gap where secrets.cfg was never sourced at launch.
    EXPORTED_KEYS_FILE="$HOME_DIR/.aicli/.exported_keys_${ENV_HASH}"
    mkdir -p "$(dirname "$EXPORTED_KEYS_FILE")" 2>/dev/null
    if [ "${AICLI_RESTRICTED_RUN:-}" = "1" ]; then
        # Finding 12: the run user cannot read the vault, so this process cannot build the environment. Root built the file
        # before the start and the view shows it read-only. The lines are plain `export` statements.
        if [ -n "${AICLI_ENV_FILE:-}" ] && [ -f "$AICLI_ENV_FILE" ] && [ ! -L "$AICLI_ENV_FILE" ]; then
            cat "$AICLI_ENV_FILE" >> "$RUN_SCRIPT" 2>/dev/null
        else
            log_aicli "WARN" 1 "Restricted run $ID has no environment file; the agent starts without the keys of the vault."
        fi
        : > "$EXPORTED_KEYS_FILE" 2>/dev/null
        log_aicli "INFO" 2 "Injected the environment file of the restricted run"
    else
    php "$PLUGIN_SRC/scripts/user/effective-env-export.php" \
        "$PLUGIN_SRC/includes/AICliAgentsManager.php" startup \
        "$ROOT_DIR" "$AGENT_ID" "$EXPORTED_KEYS_FILE" >> "$RUN_SCRIPT" 2>/dev/null
    log_aicli "INFO" 2 "Injected effective env (5-tier merge via EnvService)"
    fi

    # Export the tracker path + workspace path so the run-loop's
    # _aicli_load_envs can hot-apply changes without needing to recompute
    # them. Per WP #736 hot-apply.
    printf 'export AICLI_WORKSPACE_PATH=%q\n' "$ROOT_DIR" >> "$RUN_SCRIPT"
    printf 'export AICLI_CWD=%q\n' "${WORK_CWD:-$ROOT_DIR}" >> "$RUN_SCRIPT"
    printf 'export AICLI_EXPORTED_KEYS_FILE=%q\n' "$EXPORTED_KEYS_FILE" >> "$RUN_SCRIPT"

    cat << 'EOF' >> "$RUN_SCRIPT"
export TERM=xterm-256color
export LC_ALL=en_US.UTF-8
# Ensure the agent (and every child) runs in the WORKSPACE, not the tmux server's
# cwd. `new-session -c "$ROOT_DIR"` already pins the pane dir; this is a
# self-contained belt-and-braces guard so the agent process is in the workspace
# even if a Tier-4 user .conf overrides tmux options. AICLI_WORKSPACE_PATH is
# exported just above (= the resolved workspace root).
cd "${AICLI_CWD:-$AICLI_WORKSPACE_PATH}" 2>/dev/null || cd "$AICLI_WORKSPACE_PATH" 2>/dev/null || cd "${AICLI_ROOT:-/mnt}" 2>/dev/null || true
# WP #1259: non-interactive defaults for the agent shell + every child it spawns.
# A TUI agent (notably agy/antigravity) runs child commands with NO controlling
# TTY and does NOT forward keystrokes to them -- a regression from gemini-cli's
# node-pty shell, which gave children a PTY and relayed input. So any child that
# opens an editor or pager, or waits on a y/N prompt, HANGS forever: the prompt
# re-renders but can never be answered. (Verified on .4: ssh will read a piped
# password fine even with no TTY -- the block is that agy sends the child no
# input at all.) These defaults make the common offenders non-interactive so they
# COMPLETE instead of hanging. Each is a DEFAULT (:-) so an explicit value from
# the 5-tier env (applied later by _aicli_load_envs) still wins. NOTE: ssh/sudo
# *password* prompts can't be fixed here -- use key-based ssh; sudo is moot since
# the agent already runs as root. Harmless to gemini-cli (it forwards input, and
# the :- defaults respect any editor/pager it was configured with).
export GIT_PAGER="${GIT_PAGER:-cat}"
export PAGER="${PAGER:-cat}"
export SYSTEMD_PAGER="${SYSTEMD_PAGER:-}"
export LESS="${LESS:-FRX}"
export GIT_EDITOR="${GIT_EDITOR:-true}"
export GIT_SEQUENCE_EDITOR="${GIT_SEQUENCE_EDITOR:-true}"
export EDITOR="${EDITOR:-true}"
export VISUAL="${VISUAL:-true}"
export GIT_TERMINAL_PROMPT="${GIT_TERMINAL_PROMPT:-0}"
export GIT_SSH_COMMAND="${GIT_SSH_COMMAND:-ssh -o BatchMode=yes}"
export DEBIAN_FRONTEND="${DEBIAN_FRONTEND:-noninteractive}"
stty sane 2>/dev/null
perf_log run.start

# WP #1253: keep opost+onlcr asserted on this pane for the life of the session.
# A TUI agent (e.g. agy) cfmakeraw's the pane (turning opost OFF) for its own UI.
# Any INTERACTIVE child it then spawns (an ssh password prompt, sudo, etc.)
# inherits that raw pane and emits bare LF without CR; tmux emulates the bare LF
# into a diagonal "staircase" (the cursor drops a row but never returns to col 0).
# Re-asserting opost+onlcr makes the kernel translate LF->CRLF before tmux reads
# it, so the staircase can never form. This is harmless to the agent's own UI:
# its explicit \r\n just gains a redundant (no-op) CR, and cursor-positioning
# escape sequences are unaffected by opost. A low-rate keeper is required because
# the agent re-raws the pane on (re)launch and on resize; it self-terminates when
# this run-script (the session) exits. Confirmed live on .4 (WP #1253).
_AICLI_PANE_TTY="$(tty 2>/dev/null)"
case "$_AICLI_PANE_TTY" in
    /dev/*)
        ( _rs_pid=$$
          while kill -0 "$_rs_pid" 2>/dev/null; do
              stty -F "$_AICLI_PANE_TTY" opost onlcr 2>/dev/null
              sleep 0.5
          done ) >/dev/null 2>&1 &
        ;;
esac

# WP #275c: install a no-op SIGINT trap on the RUN_SCRIPT itself.
# Why: in a non-interactive bash script with no SIGINT trap, receiving SIGINT
# (Ctrl-C from the terminal) terminates the script immediately. That's the
# default behaviour and it's what was killing the wrapper when the UI's
# Apply-now-args flow sent Ctrl-C while bash was sitting at a `read -r` prompt
# (e.g. after a previous bad-args launch parked us in the fast-exit guard).
# Tmux died with bash, ttyd showed "Press ⏎ to Reconnect".
#
# Setting `trap : INT` makes bash run a no-op (`:`) on SIGINT. Bash builtins
# like `read` get interrupted (return 130) and the script CONTINUES. The next
# loop iteration then fires the auto-reload sentinel check and relaunches the
# agent with the new args — which is exactly what the user asked for.
#
# Important: bash traps DON'T propagate to children (only signal dispositions
# do, and only SIG_IGN inherits — `trap : ...` sets a function, child gets
# SIG_DFL). So the running agent still receives Ctrl-C normally and exits as
# expected. This trap only protects bash itself in the gaps between agent
# launches.
trap : INT

# #667: the launcher runs saved arguments with `bash -c`. The UI refuses an
# unsafe argument at save time (ArgsService::validateArgs), but a file saved
# before that check, restored from a backup or edited by hand is read here with
# no check. Mirror the same rules so such a file cannot run a redirect or a
# subshell: a character from ; | & ` $ or a line break anywhere, an unquoted
# > < ( ) * or a comment, or an open quote. Returns 0 when the text is UNSAFE.
_aicli_args_unsafe() {
    local _a="$1" _q="" _i _c _len=${#1}
    case "$_a" in
        *';'*|*'|'*|*'&'*|*'`'*|*'$'*|*$'\n'*|*$'\r'*) return 0 ;;
    esac
    for ((_i = 0; _i < _len; _i++)); do
        _c="${_a:_i:1}"
        if [ "$_q" = "'" ]; then [ "$_c" = "'" ] && _q=""; continue; fi
        if [ "$_c" = '\' ]; then _i=$((_i + 1)); continue; fi
        if [ "$_q" = '"' ]; then [ "$_c" = '"' ] && _q=""; continue; fi
        if [ "$_c" = "'" ] || [ "$_c" = '"' ]; then _q="$_c"; continue; fi
        case "$_c" in
            '>'|'<'|'('|')'|'*') return 0 ;;
            '#') if [ "$_i" -eq 0 ] || [[ "${_a:_i-1:1}" =~ [[:space:]] ]]; then return 0; fi ;;
        esac
    done
    [ -z "$_q" ] || return 0
    return 1
}

# Pure helper: assemble the fresh-launch command from parts.
# plugin_args is appended AFTER user effective_args so codex's last-`-c`-wins
# makes the plugin sandbox_mode override any user workspace arg.
# Arguments: binary effective_args plugin_args
# Outputs the assembled command string to stdout.
_build_fresh_cmd() {
    local _binary="$1" _eff="$2" _plugin="$3"
    local _cmd="$_binary"
    [ -n "$_eff" ]    && _cmd="$_cmd $_eff"
    [ -n "$_plugin" ] && _cmd="$_cmd $_plugin"
    printf '%s' "$_cmd"
}

# docs/specs/AGENT_SPAWN_WORKSPACE.md R6 and R22: the first prompt of a helper workspace.
# The spawn tool writes the fixed first line to AICLI_TASK_DIR/PROMPT.once for a script run, or to
# <workspace>/.aicli-task/PROMPT.once for a regular helper, and the mode ("positional", "flag:<--name>"
# or "none") into the workspace id flags file. This helper prints the
# quoted prompt as a suffix for the fresh-launch command. It renames the file to PROMPT.consumed, so
# a relaunch or a resume never sends it twice. It prints nothing when there is no prompt to send.
# The shell does this, not the saved arguments, because the argument check refuses a "$".
# #782: this function runs inside the generated run script, where only the exported names exist
# (AICLI_WORKSPACE_PATH, AICLI_ARGS_ID_FILE). It read ROOT_DIR and _ARGS_ID_FILE, which are set only
# in the outer script, so no helper and no script run ever got its first prompt.
_aicli_task_prompt_suffix() {
    local _root="${ROOT_DIR:-${AICLI_WORKSPACE_PATH:-}}" _args="${_ARGS_ID_FILE:-${AICLI_ARGS_ID_FILE:-}}"
    local _task_dir="${AICLI_TASK_DIR:-}" _file _mode _flag _text
    [ -n "$_task_dir" ] || _task_dir="$_root/.aicli-task"
    _file="$_task_dir/PROMPT.once"
    [ -n "$_root" ] && [ -n "$_args" ] && [ -f "$_args" ] && [ -f "$_file" ] || return 0
    # #865 review 3: a link is never a first prompt (a repo can commit one, and root would read its target).
    # A private task folder (restricted run) is not inside the run folder, so the link check of the run folder does not apply.
    if [ -n "${AICLI_TASK_DIR:-}" ]; then
        [ ! -L "$_file" ] || return 0
    else
        [ ! -L "$_file" ] && [ ! -L "$_root/.aicli-task" ] || return 0
    fi
    # Same rule as AgentLaunchProfile::promptModeValid(): any other text means "no prompt".
    _mode=$(php -r '$d=json_decode(@file_get_contents($argv[1]),true);$m=is_array($d)?(string)($d["prompt_mode"]??""):"";echo preg_match("/^(positional|flag:--[a-z][a-z-]{0,30})$/D",$m)?$m:"";' "$_args" 2>/dev/null)
    case "$_mode" in
        positional) _flag="" ;;
        flag:--[a-z]*) _flag="${_mode#flag:}" ;;
        *) return 0 ;;
    esac
    _text=$(cat "$_file" 2>/dev/null)
    [ -n "$_text" ] || return 0
    mv -f "$_file" "$_task_dir/PROMPT.consumed" 2>/dev/null || rm -f "$_file" 2>/dev/null
    if [ -n "$_flag" ]; then
        printf ' %s %q' "$_flag" "$_text"
    else
        printf ' %q' "$_text"
    fi
}

# Deterministic repair of agent state at every start (damaged SQLite files,
# an OpenCode resume id its store does not hold). Spec: docs/specs/AGENT_STATE_PREFLIGHT.md
[ -r "$PLUGIN_SRC/scripts/agent-state-preflight.sh" ] && . "$PLUGIN_SRC/scripts/agent-state-preflight.sh"
_aicli_preflight_notice() {
    [ -n "${AICLI_PREFLIGHT_NOTICE:-}" ] || return 0
    printf '\033[33m[AI Cli Agents] %s Your saved conversation is kept.\033[0m\n' "$AICLI_PREFLIGHT_NOTICE"
}

# Return the newest Claude conversation id for THIS workspace only. Claude's
# modern session store is partitioned by its dasherised cwd under
# ~/.claude/projects; scanning all projects can select another workspace's chat
# and turn the subsequent failed resume into a blank conversation.
_aicli_discover_claude_chat() {
    [ "$AGENT_ID" = "claude-code" ] || return 0
    [ -n "$AICLI_WORKSPACE_PATH" ] || return 0

    # Claude names the project folder by turning EVERY non-alphanumeric
    # character of the cwd into a dash ("_" and "." too). The legacy key, which
    # replaced only "/", is tried as well. Both the workspace path and the
    # launch folder are tried, as ClaudeSessionNameResolver::projectDirs does (#609).
    local _path _key _project_dir _newest_jsonl _cands=""
    for _path in "$AICLI_WORKSPACE_PATH" "${AICLI_CWD:-}"; do
        [ -n "$_path" ] || continue
        [ "$_path" = "/" ] || _path="${_path%/}"
        for _key in "$(printf '%s' "$_path" | sed 's/[^A-Za-z0-9]/-/g')" \
                    "-$(printf '%s' "${_path#/}" | tr '/' '-')"; do
            _project_dir="$HOME_DIR/.claude/projects/$_key"
            [ -d "$_project_dir" ] || continue
            case "$_cands
" in *"
$_project_dir
"*) continue ;; esac
            _cands="$_cands
$_project_dir"
        done
    done
    [ -n "$_cands" ] || return 0

    # Issue #71: exclude subagent transcripts (`agent-<id>.jsonl`). They are
    # not resumable conversations — resuming from one opens the wrong
    # transcript. Only main-session GUIDs may be discovered.
    _newest_jsonl=$(printf '%s\n' "$_cands" | while IFS= read -r _project_dir; do
        [ -n "$_project_dir" ] || continue
        find "$_project_dir" -maxdepth 1 -name '*.jsonl' ! -name 'agent-*' -type f \
            -printf '%T@ %p\n' 2>/dev/null
    done | sort -rn | head -1 | cut -d' ' -f2-)
    [ -n "$_newest_jsonl" ] && basename "$_newest_jsonl" .jsonl
}

# True when Grok Build has a saved session for the folder the agent starts in.
# Grok keeps one directory per folder, named with the URL-encoded path
# (~/.grok/sessions/%2Fmnt%2Fuser%2Fwork/<session-id>), and '--continue' finds
# only a session of the current folder. The store root also holds a shared
# search index (session_search.sqlite), so "any file in the store" is true after
# the first Grok run anywhere: a new workspace in a new folder then ran
# '--continue', Grok exited with "No session found for current directory", and
# a slow (>= 3 s) exit parked the workspace (#530, live-agents run 2026-10-15).
_aicli_grok_has_session_here() {
    local _dir="${AICLI_CWD:-$AICLI_WORKSPACE_PATH}" _store="$HOME_DIR/.grok/sessions"
    local _d _name _decoded
    [ -n "$_dir" ] && [ -d "$_store" ] || return 1
    [ "$_dir" = "/" ] || _dir="${_dir%/}"
    for _d in "$_store"/*/; do
        [ -d "$_d" ] || continue
        _name=$(basename "$_d")
        _decoded=$(printf '%b' "${_name//%/\\x}")
        [ "$_decoded" = "/" ] || _decoded="${_decoded%/}"
        [ "$_decoded" = "$_dir" ] || continue
        [ -n "$(find "$_d" -mindepth 1 -maxdepth 1 2>/dev/null | head -1)" ] && return 0
    done
    return 1
}

# Refresh the in-memory and durable resume ids after Claude has had a chance to
# write its active conversation. This must run before an automatic relaunch so
# /resume switches and a newly-created fresh chat both resume the correct
# workspace conversation.
_aicli_sync_claude_chat() {
    [ "$AGENT_ID" = "claude-code" ] || return 0
    [ -n "$AICLI_ENV_HASH" ] || return 0

    local _discovered_chat _resume_dir _resume_file
    _discovered_chat=$(_aicli_discover_claude_chat)
    if [ -n "$_discovered_chat" ] && [ "$_discovered_chat" != "$frozen_chat_id" ]; then
        log_aicli "INFO" 2 "Workspace-scoped Claude GUID sync: $frozen_chat_id -> $_discovered_chat"
        frozen_chat_id="$_discovered_chat"
        _resume_dir="$HOME_DIR/.aicli/resumes"
        _resume_file="${_resume_dir}/resume_${AICLI_ENV_HASH}.json"
        mkdir -p "$_resume_dir" 2>/dev/null
        printf '{"chat_id":"%s","saved_at":%d}\n' "$_discovered_chat" "$(date +%s)" > "${_resume_file}.tmp" \
            && mv "${_resume_file}.tmp" "$_resume_file" 2>/dev/null
    fi
}

# Preserve the actual process result before deciding whether anything should be
# relaunched. Bash encodes signal termination as 128+signal; retain both forms
# and the runtime so diagnostics can distinguish startup rejection from a crash
# or kill after a healthy, long-running session.
_aicli_record_agent_exit() {
    local _attempt="$1" _rc="$2" _started="$3"
    local _dynamic_recorder="$PLUGIN_SRC/scripts/user/agent-exit-recorder.sh"
    if [ -f "$_dynamic_recorder" ]; then
        unset -f aicli_dynamic_record_agent_exit 2>/dev/null || true
        # shellcheck source=/dev/null -- release symlink intentionally resolves at call time
        source "$_dynamic_recorder"
        if declare -F aicli_dynamic_record_agent_exit >/dev/null 2>&1; then
            aicli_dynamic_record_agent_exit "$_attempt" "$_rc" "$_started"
            return
        fi
    fi
    local _ended _termination="exit"
    _ended=$(date +%s)
    last_launch_duration=$((_ended - _started))
    last_launch_rc="$_rc"

    if [ "$_rc" -ge 129 ] && [ "$_rc" -le 192 ]; then
        local _signal=$((_rc - 128)) _signal_name
        _signal_name=$(kill -l "$_signal" 2>/dev/null || printf 'UNKNOWN')
        _termination="signal ${_signal} (${_signal_name})"
    fi
    log_aicli "INFO" 2 "Agent process ended: attempt=$_attempt rc=$_rc termination=$_termination duration=${last_launch_duration}s"
    # Issue #71: every child exit also emits a machine-readable perf event
    # (`<epoch_ms> run.exit <agent> <session> rc=<code>`) so unexplained agent
    # deaths (2026-07-17: two organic claude-code exits under heavy subagent
    # load) can be correlated without parsing debug.log prose. A non-zero exit
    # additionally snapshots crash forensics BEFORE the relaunch loop clears
    # the pane.
    perf_log run.exit "rc=$_rc"
    if [ "$_rc" -ne 0 ]; then
        _aicli_capture_crash "$_attempt" "$_rc"
    fi
}

# Issue #71: crash forensics. The agent's stderr deliberately flows to the pane
# TTY (see safe_exec / D-400 — redirecting stderr to a file breaks TUI isatty
# probes and is NOT an option), so on an unexplained exit the pane scrollback
# IS the stderr record. Snapshot the last ~80 pane lines plus launch context
# into ${MOUNT_ROOT}/crash-<agent>-<session>-<timestamp>.log before
# the relaunch loop repaints the screen. Bounded: only the 10 newest crash
# files per agent are kept. AICLI_CRASH_DIR override exists for unit tests.
_aicli_capture_crash() {
    local _attempt="$1" _rc="$2"
    local _dir="${AICLI_CRASH_DIR:-${MOUNT_ROOT}}"
    local _crash_file="$_dir/crash-${AGENT_ID}-${AICLI_SESSION_ID}-$(date +%Y%m%d-%H%M%S).log"
    {
        printf 'agent=%s session=%s attempt=%s rc=%s captured_at=%s\n' \
            "$AGENT_ID" "$AICLI_SESSION_ID" "$_attempt" "$_rc" "$(date '+%Y-%m-%d %H:%M:%S')"
        printf 'node_options=%s\n' "${NODE_OPTIONS:-<unset>}"
        printf -- '---- pane tail (last 80 lines) ----\n'
        tmux capture-pane -p -S -80 2>/dev/null || printf '(tmux pane capture unavailable)\n'
    } > "$_crash_file" 2>/dev/null
    log_aicli "WARN" 1 "Crash forensics captured: $_crash_file (attempt=$_attempt rc=$_rc)"
    # Prune: keep only the 10 newest crash files for this agent.
    ls -1t "$_dir"/crash-"${AGENT_ID}"-*.log 2>/dev/null | tail -n +11 | while IFS= read -r _old; do
        rm -f "$_old" 2>/dev/null
    done
}

# #814: the close has started, but the close sentinel is not set yet. gracefulClose
# sends the exit keys first and sets close-<id>.flag only after it has scraped the
# resume id (about 3 seconds later). In that gap the loop can come round again: the
# Ctrl-D keys end the "Press ENTER" read at once, and the flag is not there yet, so
# the agent started again and the close fell back to the hard stop. gracefulClose
# now sets closing-<id>.flag BEFORE the exit keys. While it exists, wait here (the
# pane keeps the exit screen for the scrape) until close-<id>.flag appears. Wait at
# most 30 seconds, so a close that died half way cannot park the workspace for ever.
_aicli_wait_while_closing() {
    local _closing="${MOUNT_ROOT}/closing-$AICLI_SESSION_ID.flag" _n=0
    [ -f "$_closing" ] || return 0
    log_aicli "INFO" 2 "Close in progress (closing sentinel) — not starting the agent again; waiting for the close sentinel."
    while [ -f "$_closing" ] && [ ! -f "${MOUNT_ROOT}/close-$AICLI_SESSION_ID.flag" ] && [ "$_n" -lt 300 ]; do
        sleep 0.1
        _n=$((_n + 1))
    done
    if [ -f "${MOUNT_ROOT}/close-$AICLI_SESSION_ID.flag" ]; then
        rm -f "$_closing" 2>/dev/null
    elif [ -f "$_closing" ]; then
        rm -f "$_closing" 2>/dev/null
        log_aicli "WARN" 1 "Closing sentinel gave no close sentinel within 30s — continuing the loop."
    fi
    return 0
}

# A resume process that survives the existing fast-exit window reached its TUI
# lifecycle; a later non-zero exit must not be reclassified as startup failure.
_aicli_resume_was_established() {
    [ "$1" -ge 3 ]
}

# #610: "Start New Session" sets frozen_chat_id to _fresh_ for the FIRST launch
# only. Called after every launch, it drops the mark so a later relaunch in the
# same tmux session resumes the chat the agent started (resume-latest, or the
# id Claude/OpenCode sync finds) instead of opening a blank one each time.
_aicli_clear_fresh_mark() {
    if [ "${frozen_chat_id:-}" = "_fresh_" ]; then
        frozen_chat_id=""
    fi
}

# Build a resume command from a registry template: $1 template, $2 chat id
# (empty for resume-latest), $3 binary, $4 args. The chat id is shell-escaped
# with printf %q because a renamed Claude chat prints its name, which can hold
# spaces, quotes or "&". Bash 5.2 turns on patsub_replacement, where an
# unescaped "&" in a replacement text means "the matched text" and the %q
# backslash before it is dropped, so "x&reboot" would run as a command under
# bash -c. Turn that option off before every replacement (#649).
_aicli_build_resume_cmd() {
    local _tpl="$1" _chat="$2" _bin="$3" _args="$4" _esc
    shopt -u patsub_replacement 2>/dev/null || true
    if [ -n "$_chat" ]; then
        _esc=$(printf '%q' "$_chat")
        _tpl="${_tpl//\{chatId\}/$_esc}"
    fi
    _tpl="${_tpl//\{binary\}/$_bin}"
    _tpl="${_tpl//\{args\}/$_args}"
    _tpl="${_tpl//  / }"
    printf '%s' "$_tpl"
}

# AGENT_SPAWN_WORKSPACE.md R21: make sure the commands that the agent runs keep the AICLI_* variables
# (AICLI_RELAY_COMMAND, AICLI_ADMIN_COMMAND, AICLI_SESSION_ID). An agent builds the environment of its
# command tool from its own settings; Codex does it from [shell_environment_policy] in its config file.
# When that policy is missing, the Relay command is not there and the agent falls back to the slow MCP tool.
# This runs for every agent and every launch (the shared launch path). The script reads the registry key
# `command_env` and does nothing for an agent that has none. It never stops the launch.
# `timeout` starts a program, not a shell function, so the cache flags (S7) are passed here.
_aicli_ensure_command_env() {
    local _s="$PLUGIN_SRC/scripts/ensure-command-env.php"
    [ -f "$_s" ] && [ -n "$(type -P php)" ] || return 0
    [ -n "${_AICLI_PHP_INIT:-}" ] || _aicli_php_cache_init
    timeout 20 "$(type -P php)" "${AICLI_PHP_FLAGS[@]}" -d display_errors=0 "$_s" "$AGENT_ID" "${HOME_DIR:-$HOME}" >/dev/null 2>&1 || true
    return 0
}

# WP #736 hot-apply: re-read the 5-tier effective env via EnvService on every
# loop iteration. Diffs against $AICLI_EXPORTED_KEYS_FILE: unsets any key we
# previously exported but is no longer present; re-exports the current set.
# Single source of truth shared with the startup path and TerminalService.
# Single PHP invocation per iteration (~50 ms — negligible against agent
# startup cost).
_aicli_load_envs() {
    # A restricted run keeps the environment that root wrote at the start (finding 12): this process cannot read the vault.
    [ "${AICLI_RESTRICTED_RUN:-}" = "1" ] && return 0
    # The reload file holds every secret. Make it with mktemp (mode 0600) in the
    # user's own .aicli folder, never in the shared /tmp (#638).
    local script
    script="$(mktemp "$(dirname "$AICLI_EXPORTED_KEYS_FILE")/.envreload.XXXXXX" 2>/dev/null)" || script=""
    if [ -z "$script" ]; then
        log_aicli "WARN" 1 "Env reload skipped: cannot create a private reload file. The last good environment stays."
        return 0
    fi
    # #608: a failed export (php error, vault mid-write) must not wipe the
    # environment. Keep the last good env and tracker unless the export both
    # succeeded and carries the key-set line.
    if ! php "$PLUGIN_SRC/scripts/user/effective-env-export.php" \
        "$PLUGIN_SRC/includes/AICliAgentsManager.php" reload \
        "$AICLI_WORKSPACE_PATH" "$AGENT_ID" > "$script" 2>/dev/null \
        || ! grep -q '^_AICLI_NEW_KEYS=' "$script"; then
        log_aicli "WARN" 1 "Env reload failed; the last good environment stays for this launch."
        rm -f "$script"
        return 0
    fi

    # Source it: exports the new env AND sets _AICLI_NEW_KEYS in our scope.
    # shellcheck disable=SC1090
    source "$script"
    rm -f "$script"

    # Unset previously-exported keys that aren't in the new set.
    if [ -f "$AICLI_EXPORTED_KEYS_FILE" ]; then
        while IFS= read -r _old_key; do
            [ -z "$_old_key" ] && continue
            case " $_AICLI_NEW_KEYS " in
                *" $_old_key "*) : ;;            # still set — keep
                *) unset "$_old_key" ;;          # removed — drop
            esac
        done < "$AICLI_EXPORTED_KEYS_FILE"
    fi

    # Rewrite the tracker for the next iteration.
    : > "$AICLI_EXPORTED_KEYS_FILE"
    for _k in $_AICLI_NEW_KEYS; do
        echo "$_k" >> "$AICLI_EXPORTED_KEYS_FILE"
    done
    unset _AICLI_NEW_KEYS _old_key _k
}

# #37: consecutive immediate-crash counter. A broken/incompatible agent binary
# exits in <3s every launch (opencode rc=1 on Tower). After a few in a row we
# escalate the message from "missing configuration" to "binary is broken, upgrade
# it" so the operator gets an actionable diagnosis instead of a confusing loop of
# retry prompts. Reset on any launch that survived >=3s.
consecutive_fast_crashes=0

# #888: count of short failures in a row (3 s to under 60 s, rc not 0/130/143). See user/agent-restart-policy.sh.
consecutive_short_failures=0

# #814: a closing sentinel left by an earlier close that died must not hold this start.
rm -f "${MOUNT_ROOT}/closing-$AICLI_SESSION_ID.flag" 2>/dev/null

while true; do
    # Graceful-close sentinel — TOP-of-loop re-check (close-race fix 2026-06-07).
    # gracefulClose keeps this session alive (so it can scrape the exit screen for a
    # resume id, ~4s) and only THEN touches the flag + sends Enter to wake the
    # post-exit "Press ENTER to reload" read below. A fast-exiting agent (a fresh
    # claude exits instantly on Ctrl-C) has already passed the post-exit flag check
    # and is parked on that read; waking it returns HERE. Without this check we would
    # re-exec the agent — relaunching a workspace the user just closed and forcing
    # gracefulClose into its 3s hard-stop fallback. Checking the flag before the
    # (re)launch breaks cleanly while still preserving the scrape window.
    # #814: a close that has started but not set the sentinel yet holds the loop here.
    _aicli_wait_while_closing
    if [ -f "${MOUNT_ROOT}/close-$AICLI_SESSION_ID.flag" ]; then
        rm -f "${MOUNT_ROOT}/close-$AICLI_SESSION_ID.flag" 2>/dev/null
        log_aicli "INFO" 2 "Graceful close sentinel observed at loop top — exiting before relaunch."
        break
    fi
    # S3/S7: pick up a changed log level at each relaunch (a bash read, no process).
    _aicli_read_log_cfg
    perf_log agent.exec.begin
    clear

    # WP #273: refresh effective args from disk on every iteration. The user
    # may have changed workspace-level args from the UI while the agent was
    # running; on the next Ctrl-C the relaunch should pick them up. We re-read
    # the same files the OUTER script seeded at startup (paths exported above
    # as AICLI_ARGS_WS_FILE / AICLI_ARGS_AGENT_FILE — md5 hash already baked
    # in, so this is one cheap PHP -r call, not a re-hash). Falls back to
    # empty when the workspace override is removed (correct: args cleared).
    _refresh_args=""
    if [ -n "${AICLI_ARGS_ID_FILE:-}" ] && [ -f "$AICLI_ARGS_ID_FILE" ]; then
        # Per-workspace-id flags of a helper workspace win over the folder file.
        _refresh_args=$(php -r "\$d=json_decode(file_get_contents('$AICLI_ARGS_ID_FILE'),true);echo is_array(\$d)?(\$d['args']??''):'';" 2>/dev/null)
    elif [ -n "$AICLI_ARGS_WS_FILE" ] && [ -f "$AICLI_ARGS_WS_FILE" ]; then
        _refresh_args=$(php -r "\$d=json_decode(file_get_contents('$AICLI_ARGS_WS_FILE'),true);echo is_array(\$d)?(\$d['args']??''):'';" 2>/dev/null)
    elif [ -n "$AICLI_ARGS_AGENT_FILE" ] && [ -f "$AICLI_ARGS_AGENT_FILE" ]; then
        _refresh_args=$(php -r "\$d=json_decode(file_get_contents('$AICLI_ARGS_AGENT_FILE'),true);echo is_array(\$d)?(\$d['args']??''):'';" 2>/dev/null)
    fi
    # #667: refuse a saved argument that holds a shell operator (see
    # _aicli_args_unsafe). Check the seeded value too: it came from a file
    # that the UI check may never have seen.
    if [ -n "$frozen_effective_args" ] && _aicli_args_unsafe "$frozen_effective_args"; then
        log_aicli "WARN" 1 "Saved agent arguments hold a shell operator; launching with no arguments"
        frozen_effective_args=""
    fi
    if [ -n "$_refresh_args" ] && _aicli_args_unsafe "$_refresh_args"; then
        log_aicli "WARN" 1 "Saved agent arguments hold a shell operator; launching with no arguments"
        _refresh_args=""
    fi
    if [ "$_refresh_args" != "$frozen_effective_args" ]; then
        log_aicli "INFO" 2 "Args changed since last launch: '$frozen_effective_args' -> '$_refresh_args' (applying on this relaunch)"
        frozen_effective_args="$_refresh_args"
    fi

    # WP #736 hot-apply: refresh env from disk on every iteration. After a
    # Ctrl-C-driven reload (UI's agent_signal_reload + Apply now), the new
    # env values are picked up here before the agent execs below.
    _aicli_load_envs
    _aicli_ensure_command_env

    # #144: OpenCode single-instance DB safety + per-workspace isolation.
    # OpenCode keeps ONE sqlite DB per data dir; two server processes writing it at
    # once (Reconnect / generation-drift double-spawn, or two OpenCode workspaces)
    # corrupt it ("database disk image is malformed"). Three defences below:
    #   C) isolate the DB per workspace so distinct workspaces never share a store;
    #   A) before launching, gracefully stop any OTHER process still holding THIS
    #      workspace's DB (so it flushes its working copy back to disk first);
    #   B) only then run the D-52 WAL/SHM cleanup — provably single-instance, so it
    #      can never delete a live WAL out from under a running server.
    # See docs/specs/OPENCODE_DB_SINGLE_INSTANCE.md.
    if [[ "$AGENT_ID" == "opencode" ]]; then
       # --- C: per-workspace DB isolation (XDG_DATA_HOME relocates opencode.db;
       #        config/plugins/relay stay in ~/.config/opencode, untouched). ---
       # The store is keyed by the WORKSPACE PATH (per user), not the session id:
       # a workspace that is closed and re-added gets a NEW session id, so the
       # session-keyed dir of #144 started from the stale shared seed and the
       # `-s <chatId>` resume failed with "Session not found" (2026-09-07). The
       # first launch under the path key ADOPTS the session-keyed store that holds
       # the resume id (or, without one, this workspace's most recent store).
       _oc_ws_path="${_oc_ws_path:-$PWD}"
       _oc_ws_key="ws-$(printf '%s:%s' "${USER_NAME:-${AICLI_USER:-$(id -un)}}" "$_oc_ws_path" | sha1sum | cut -c1-16)"
       _oc_root="$HOME_DIR/.local/share/aicli-opencode"
       export XDG_DATA_HOME="$_oc_root/$_oc_ws_key"
       _oc_data="$XDG_DATA_HOME/opencode"
       _oc_legacy="$HOME_DIR/.local/share/opencode"
       db_file="$_oc_data/opencode.db"
       mkdir -p "$_oc_data" 2>/dev/null

       # Adopt a legacy session-keyed store for THIS workspace (exactly once: only
       # while the path-keyed DB does not exist). Preference: the newest store whose
       # DB holds the session we are about to resume; else the newest store whose DB
       # names this workspace directory. Moved when idle, copied when a live process
       # still holds it (never yank a DB out from under a running server).
       if [ ! -f "$db_file" ] && [ -d "$_oc_root" ]; then
           _oc_pick=""; _oc_pick_why=""; _oc_pick_mtime=0
           for _cand in "$_oc_root"/*/opencode/opencode.db; do
               [ -f "$_cand" ] || continue
               case "$_cand" in "$_oc_root/ws-"*) continue ;; esac
               _why=""
               if [ -n "${frozen_chat_id:-}" ] && grep -q -a -F -- "$frozen_chat_id" "$_cand" 2>/dev/null; then
                   _why="resume-id"
               elif [ -z "${frozen_chat_id:-}" ] && grep -q -a -F -- "$_oc_ws_path" "$_cand" 2>/dev/null; then
                   _why="workspace-path"
               fi
               [ -n "$_why" ] || continue
               _m=$(stat -c %Y "$_cand" 2>/dev/null || echo 0)
               if [ "$_m" -gt "$_oc_pick_mtime" ]; then _oc_pick="$_cand"; _oc_pick_why="$_why"; _oc_pick_mtime="$_m"; fi
           done
           if [ -n "$_oc_pick" ]; then
               _oc_src_dir="$(dirname "$(dirname "$_oc_pick")")"
               _oc_src_sid="$(basename "$_oc_src_dir")"
               _held=""
               for _p in $(pgrep -f 'opencode-ai/bin/opencode.exe' 2>/dev/null); do
                   [ "$_p" = "$$" ] && continue
                   for _l in /proc/"$_p"/fd/*; do
                       _t=$(readlink "$_l" 2>/dev/null) || continue
                       case "${_t% (deleted)}" in "$_oc_pick"|"$_oc_pick-wal") _held="$_p"; break 2 ;; esac
                   done
               done
               rmdir "$_oc_data" 2>/dev/null; rmdir "$XDG_DATA_HOME" 2>/dev/null
               if [ -z "$_held" ] && mv "$_oc_src_dir" "$XDG_DATA_HOME" 2>/dev/null; then
                   log_aicli "INFO" 1 "OpenCode #144: adopted store $_oc_src_sid -> $_oc_ws_key for $_oc_ws_path (moved; reason=$_oc_pick_why)"
               else
                   mkdir -p "$XDG_DATA_HOME" 2>/dev/null
                   cp -a "$_oc_src_dir/." "$XDG_DATA_HOME/" 2>/dev/null
                   rm -f "$db_file-wal" "$db_file-shm" 2>/dev/null
                   log_aicli "INFO" 1 "OpenCode #144: adopted store $_oc_src_sid -> $_oc_ws_key for $_oc_ws_path (copied; held by pid ${_held:-?}; reason=$_oc_pick_why)"
               fi
               mkdir -p "$_oc_data" 2>/dev/null
               touch "$_oc_data/.aicli-migrated" 2>/dev/null
           fi
       fi

       # One-time migration: seed this workspace's store from the legacy shared DB
       # so existing history carries over. Sentinel + non-blocking flock => exactly
       # once, never mid-write. OpenCode namespaces sessions by project internally,
       # so carrying the whole DB is safe (unrelated rows are inert).
       if [ ! -f "$_oc_data/.aicli-migrated" ] && [ ! -f "$db_file" ] && [ -f "$_oc_legacy/opencode.db" ]; then
           (
               if flock -n 9; then
                   log_aicli "INFO" 2 "OpenCode #144: migrating shared DB -> per-workspace store ($AICLI_SESSION_ID)"
                   cp -a "$_oc_legacy/opencode.db" "$db_file" 2>/dev/null
                   [ -d "$_oc_legacy/snapshot" ] && cp -a "$_oc_legacy/snapshot" "$_oc_data/" 2>/dev/null
                   [ -d "$_oc_legacy/repos" ]    && cp -a "$_oc_legacy/repos"    "$_oc_data/" 2>/dev/null
                   [ -f "$_oc_legacy/auth.json" ] && ln -sf "$_oc_legacy/auth.json" "$_oc_data/auth.json" 2>/dev/null
                   rm -f "$db_file-wal" "$db_file-shm" 2>/dev/null
                   touch "$_oc_data/.aicli-migrated"
               fi
           ) 9>"$_oc_data/.aicli-migrate.lock"
       fi

       # Print PIDs of OTHER opencode processes holding THIS workspace's DB (or its
       # WAL) open — matching a deleted inode too (a mid-session working copy shows
       # "<path> (deleted)"). Excludes our own launcher pid.
       _oc_db_holders() {
           local _p _l _t
           for _p in $(pgrep -f 'opencode-ai/bin/opencode.exe' 2>/dev/null); do
               [ "$_p" = "$$" ] && continue
               for _l in /proc/"$_p"/fd/*; do
                   _t=$(readlink "$_l" 2>/dev/null) || continue
                   _t=${_t% (deleted)}
                   if [ "$_t" = "$db_file" ] || [ "$_t" = "$db_file-wal" ]; then
                       echo "$_p"; break
                   fi
               done
           done | sort -u
       }

       # --- A: single-instance guard — stop any competing holder gracefully. ---
       _oc_grace="${AICLI_OPENCODE_STOP_GRACE:-8}"
       _oc_hold=$(_oc_db_holders)
       if [ -n "$_oc_hold" ]; then
           log_aicli "WARN" 1 "OpenCode #144: DB held by other pid(s) [$(echo $_oc_hold)] — stopping gracefully before launch"
           for _p in $_oc_hold; do kill -TERM "$_p" 2>/dev/null; done
           _oc_deadline=$(( $(date +%s) + _oc_grace ))
           while [ "$(date +%s)" -lt "$_oc_deadline" ]; do
               [ -z "$(_oc_db_holders)" ] && break
               sleep 0.3
           done
           _oc_hold=$(_oc_db_holders)
           if [ -n "$_oc_hold" ]; then
               log_aicli "WARN" 1 "OpenCode #144: pid(s) [$(echo $_oc_hold)] survived ${_oc_grace}s SIGTERM — SIGKILL"
               for _p in $_oc_hold; do kill -KILL "$_p" 2>/dev/null; done
               sleep 0.5
           fi
       fi

       # --- B: guarded D-52 WAL/SHM cleanup — only when the DB is unheld. ---
       if [ -z "$(_oc_db_holders)" ]; then
           rm -f "$db_file-wal" "$db_file-shm" 2>/dev/null
       else
           log_aicli "WARN" 1 "OpenCode #144: DB still held after guard — SKIPPING WAL cleanup to avoid corruption"
       fi

       # --- Preflight: repair a damaged store, then make sure the resume id is in
       #     THE store this launch uses (the id may have been found in another one).
       if declare -f aicli_sqlite_preflight >/dev/null 2>&1; then
           if [ -z "$(_oc_db_holders)" ]; then
               aicli_sqlite_preflight opencode OpenCode "$db_file"
               _aicli_preflight_notice
           fi
           _oc_chat_checked="$(aicli_opencode_resume_guard "$db_file" "$frozen_chat_id" "$_oc_ws_path" "${AICLI_ROOT:-}" "${AICLI_CWD:-}" "$PWD")"
           if [ -n "$_oc_chat_checked" ] && [ "$_oc_chat_checked" != "$frozen_chat_id" ]; then
               log_aicli "WARN" 1 "OpenCode preflight: resume id changed $frozen_chat_id -> $_oc_chat_checked"
               frozen_chat_id="$_oc_chat_checked"
           fi
       fi
    fi

    # Codex keeps several SQLite files in ~/.codex (thread history, logs, state).
    # A hard stop can leave one malformed, and Codex then exits on resume.
    if [ "$AGENT_ID" = "codex-cli" ] && declare -f aicli_sqlite_preflight >/dev/null 2>&1; then
        aicli_sqlite_preflight codex Codex "$HOME_DIR"/.codex/*.sqlite
        _aicli_preflight_notice
    fi

    # Every other agent that keeps SQLite files in the home (Goose, Kilo, Copilot,
    # Grok, Antigravity) gets the same check. Spec: AGENT_STATE_PREFLIGHT.md R6.
    if [ "$AGENT_ID" != "codex-cli" ] && [ "$AGENT_ID" != "opencode" ] && declare -f aicli_agent_preflight >/dev/null 2>&1; then
        aicli_agent_preflight "$AGENT_ID" "$HOME_DIR" "${AGENT_NAME:-$AGENT_ID}"
        _aicli_preflight_notice
    fi

    # D-159: Metadata Alignment - Ensure agent config directories are accessible.
    #
    # Do not recursively chmod a persisted agent home here.  On an overlay home,
    # chmod -R copy-ups every lower-layer file into the writable layer.  Claude's
    # history/plugins can contain tens of thousands of files, so that operation
    # can block startup indefinitely while ZFS commits the copy-ups.  The agent
    # runs as the workspace user and needs its config-root directory traversable;
    # content permissions are owned by the agent that created them.
    case "$AGENT_ID" in
        gemini-cli)  [ -d "$HOME_DIR/.gemini" ] && chmod 775 "$HOME_DIR/.gemini" > /dev/null 2>&1 ;;
        claude-code) [ -d "$HOME_DIR/.claude" ] && chmod 775 "$HOME_DIR/.claude" > /dev/null 2>&1 ;;
        opencode)    [ -d "${XDG_DATA_HOME:-$HOME_DIR/.local/share}/opencode" ] && chmod 775 "${XDG_DATA_HOME:-$HOME_DIR/.local/share}/opencode" > /dev/null 2>&1 ;;
    esac

    # D-170: Ensure HOME is present and writable for this user
    mkdir -p "$HOME_DIR" 2>/dev/null
    chmod 0755 "$HOME_DIR" 2>/dev/null

    # Pre-create the per-agent PARENT dirs only — not their leaf subdirs.
    # Opencode's bun init does a non-recursive mkdir '.cache/opencode/bin'
    # which ENOENTs when '.cache/opencode' doesn't exist (happens on first
    # run after install, OR after a persistence bake because storage/
    # commit_stack.sh wipes .cache/* on every sync to keep Flash deltas
    # small). Creating just the agent's parent dir lets that mkdir succeed
    # AND lets opencode's init own its own leaf creation — pre-creating
    # .cache/opencode/bin ourselves short-circuited opencode's init which
    # then blew up on the NEXT step (open '.cache/opencode/version') because
    # opencode assumed that if bin exists, version must too. Parent-only is
    # the right depth.
    mkdir -p "$HOME_DIR/.cache/${AGENT_ID}" \
             "$HOME_DIR/.config/${AGENT_ID}" \
             "$HOME_DIR/.local/share/${AGENT_ID}" \
             "$HOME_DIR/.local/share/aicli-keyring" \
             2>/dev/null

    # WP #1227: Antigravity CLI (agy) unconditionally tries to open a log file
    # in $HOME_DIR/.gemini/antigravity-cli/log/ at startup. When the directory
    # is absent, agy's log-redirect fails and Go's glog library falls back to
    # writing verbose info messages directly to stderr — which is the same TTY
    # as the terminal, so log lines interleave with TUI rendering and corrupt
    # the display. Pre-creating the directory here (on every loop iteration,
    # same as the .cache/.config/.local dirs above) ensures the redirect
    # succeeds on first launch and after any bake/snapshot cycle that wipes the
    # delta layer.
    if [[ "$AGENT_ID" == "antigravity-cli" ]]; then
        mkdir -p "$HOME_DIR/.gemini/antigravity-cli/log" 2>/dev/null
    fi

    # SIDE_BY_SIDE_AGENT_INSTALLS.md Phase 3, R4: degrade sanely if the pinned
    # generation DIRECTORY itself has vanished (reaped by GC once a later phase
    # ships concurrent generations, or the agent was uninstalled). This is
    # keyed on the generation ROOT, not on frozen_binary_primary/fallback
    # individually — a single missing file inside a still-present generation
    # is the ordinary cli.js -> bin/claude.exe shape change the block below
    # already handles; only a missing generation root means this session's
    # pinned version is gone, not just reshaped. Guarded on
    # frozen_agent_generation_dir != frozen_agent_stable_dir so a not-yet-
    # migrated or never-installed agent (the two are always equal there) never
    # takes this path — that case already falls through to the ordinary
    # "binary not found" handling below, unchanged. Falls back to the STABLE
    # (un-pinned) paths, which resolve through whatever the stable name
    # currently names — the session keeps running on a different version
    # rather than failing to relaunch. Logged once, not every loop iteration,
    # to avoid spamming a crash-loop.
    if [ -n "$frozen_agent_generation_dir" ] && [ "$frozen_agent_generation_dir" != "$frozen_agent_stable_dir" ] \
       && [ ! -d "$frozen_agent_generation_dir" ] && [ "${_aicli_degraded_to_stable:-0}" != "1" ]; then
        log_aicli "WARN" 1 "Pinned agent generation vanished (${frozen_agent_generation_dir}); falling back to the current stable agent path"
        frozen_binary_primary="$frozen_binary_primary_stable"
        frozen_binary_fallback="$frozen_binary_fallback_stable"
        _aicli_degraded_to_stable=1
    fi

    # Fix A: Re-resolve the effective binary on every relaunch iteration.
    # An in-place agent upgrade (e.g. claude-code 2.1.x dropping cli.js and
    # adding bin/claude.exe) leaves frozen_binary pointing at the deleted file.
    # Re-checking primary → fallback each loop picks up the new layout without
    # closing the workspace. Only re-resolves path-style binaries (contains /).
    # Proxy commands (no /) are stable by name and need no re-resolution.
    if [ -n "$frozen_binary_primary" ] && [[ "$frozen_binary_primary" == *"/"* ]]; then
        if [ -f "$frozen_binary_primary" ] && [ -x "$frozen_binary_primary" ]; then
            frozen_binary="$frozen_binary_primary"
        elif [ -n "$frozen_binary_fallback" ] && [ -f "$frozen_binary_fallback" ]; then
            frozen_binary="$frozen_binary_fallback"
            log_aicli "WARN" 1 "Primary binary missing (${frozen_binary_primary}); using fallback (${frozen_binary_fallback})"
        elif [ ! -f "$frozen_binary_primary" ]; then
            log_aicli "ERROR" 1 "Agent binary not found at '${frozen_binary_primary}' or '${frozen_binary_fallback}' — the agent may need reinstalling via the Store card"
            echo -e "\n\033[1;31m[Agent Binary Missing]\033[0m The agent binary was not found."
            echo -e "Expected: ${frozen_binary_primary}"
            [ -n "$frozen_binary_fallback" ] && echo -e "Fallback:  ${frozen_binary_fallback}"
            echo -e "The agent may need reinstalling via the Store card."
            echo -e "Press ENTER to retry..."
            read -r
        fi
    fi

    # D-348: Modern Launch Logic (Proxy-Aware)
    # 1. We prefer the proxy command (e.g. 'gemini') stored in frozen_binary.
    # 2. If it's not a path (no /), it's a proxy. If it is a path, we check health.
    if [ -n "$frozen_binary" ]; then
        if [[ "$frozen_binary" == *"/"* ]]; then
            link_target=$(readlink -f "$frozen_binary" 2>&1)
            target_info=$(ls -la "$link_target" 2>&1)
            # Native binaries (e.g. Claude Code 2.1.x bin/claude.exe) contain NUL
            # bytes; bash warns when command substitution strips them. Detect ELF
            # up front and skip the shebang read for native binaries.
            if [ "$(head -c 4 "$link_target" 2>/dev/null | tr -d '\0' | od -An -c | tr -d ' \n')" = "177ELF" ]; then
                shebang="(ELF native binary)"
            else
                shebang=$(head -n 1 "$link_target" 2>/dev/null | tr -d '\0')
            fi
            log_aicli "INFO" 2 "Link Health: ${frozen_binary} -> ${link_target} | Shebang: ${shebang}"
            log_aicli "INFO" 2 "Target Info: ${target_info}"
        else
            log_aicli "INFO" 2 "Proxy Launch: ${frozen_binary} (System PATH)"
        fi
    else
        # D-318: Terminals don't have binaries, only log at DEBUG
        if [ "$AGENT_ID" == "terminal" ]; then
            log_aicli "DEBUG" 3 "terminal agent has no frozen_binary (standard behavior)"
        else
            log_aicli "ERROR" 1 "CRITICAL: frozen_binary is EMPTY for $AGENT_ID"
        fi
    fi
    
    # Resume decision:
    # 1. '_fresh_' sentinel = user clicked "Start New Session" — skip all fallbacks.
    # 2. If the UI handed us an explicit chat id (from graceful-close capture),
    #    that is ALWAYS the strongest signal — trust it regardless of agent.
    # 3. Otherwise, use agent-specific history discovery. Claude is special:
    #    resolve its modern ~/.claude/projects/<workspace> store to an explicit
    #    id rather than using a global-newest or obsolete ~/.claude/sessions scan.
    can_resume=0
    if [ "$frozen_chat_id" = "_fresh_" ]; then
        can_resume=0
        log_aicli "INFO" 2 "Fresh-start sentinel: skipping all history fallbacks"
    elif [ -n "$frozen_chat_id" ] && [ "$frozen_chat_id" != "none" ]; then
        can_resume=1
        log_aicli "INFO" 2 "Resume requested with explicit chat id: $frozen_chat_id"
    elif [ "$AGENT_ID" == "claude-code" ]; then
        _workspace_claude_chat=$(_aicli_discover_claude_chat)
        if [ -n "$_workspace_claude_chat" ]; then
            frozen_chat_id="$_workspace_claude_chat"
            can_resume=1
            log_aicli "INFO" 2 "Workspace-scoped Claude resume discovered: $frozen_chat_id"
        fi
    elif [ "$AGENT_ID" == "gemini-cli" ]; then
        if [ -d "$HOME_DIR/.gemini/history" ] && [ -n "$(find "$HOME_DIR/.gemini/history" -type f 2>/dev/null)" ]; then
            can_resume=1
        fi
    elif [ "$AGENT_ID" == "pi-coder" ]; then
        if [ -d "$HOME_DIR/.pi/agent/sessions" ] && [ -n "$(find "$HOME_DIR/.pi/agent/sessions" -type f 2>/dev/null)" ]; then
            can_resume=1
        fi
    elif [ "$AGENT_ID" == "antigravity-cli" ]; then
        # No explicit chat id was handed in, but if agy has any stored conversation
        # for this home, resume-latest (--continue) so a reopened/relaunched
        # workspace returns to the last chat instead of a blank session. (The
        # workspace-correct id normally arrives via getResumeId/findSession ->
        # frozen_chat_id; this is the safety net when it doesn't.)
        if [ -d "$HOME_DIR/.gemini/antigravity-cli/conversations" ] && [ -n "$(find "$HOME_DIR/.gemini/antigravity-cli/conversations" -name '*.pb' -type f 2>/dev/null)" ]; then
            can_resume=1
        fi
    elif [ "$AGENT_ID" == "grok-build" ]; then
        # #530: '--continue' resumes only a session of the CURRENT folder, so
        # look in this folder's own session directory, not the whole store.
        if _aicli_grok_has_session_here; then
            can_resume=1
        fi
    elif [ "$AGENT_ID" == "kimi-code" ]; then
        if [ -s "$HOME_DIR/.kimi-code/session_index.jsonl" ]; then
            can_resume=1
        fi
    elif [ "$AGENT_ID" == "codex-cli" ]; then
        # #610: 'codex resume --last' picks the most recent session of the
        # CURRENT folder. A store-wide rollout file offers the resume; if this
        # folder has none, the speculative latest-resume falls through to a
        # fresh launch (frozen_chat_id is empty here, see below).
        if [ -d "$HOME_DIR/.codex/sessions" ] && [ -n "$(find "$HOME_DIR/.codex/sessions" -name 'rollout-*.jsonl' -type f 2>/dev/null)" ]; then
            can_resume=1
        fi
    elif [ "$AGENT_ID" == "kilocode" ]; then
        # #610: Kilo Code keeps every session in one SQLite file (kilo.db).
        # 'kilo --continue' resumes the last session; same fall-through as codex.
        if [ -s "$HOME_DIR/.local/share/kilo/kilo.db" ]; then
            can_resume=1
        fi
    elif [ "$AGENT_ID" == "goose" ]; then
        # #610: Goose keeps every session in sessions.db. 'session --resume'
        # without a name is the registry's resume-latest form. The official docs do
        # not state its default, and the goose binary is not installed on this
        # host, so that default is unverified.
        if [ -s "$HOME_DIR/.local/share/goose/sessions/sessions.db" ]; then
            can_resume=1
        fi
    fi

    # D-400: Safe command execution (no eval). Uses bash -c with validated commands.
    # Critical: stderr is NOT redirected. TUI libraries used by several agents
    # (Goose uses Rust's inquire / dialoguer; those probe isatty(stderr) to decide
    # whether to draw the full-screen prompt). Sending stderr to a log file makes
    # the probe fail, the prompt is skipped, and the agent exits immediately — which
    # then trips the fast-exit guard with "Press ENTER to reload" before the user
    # ever sees the Y/N card. Letting stderr flow to the pane's TTY keeps TUIs
    # alive and also makes genuine errors visible directly to the user.
    # #276: the home bake/remount path can run between the early cache-parent
    # guard above and this command. Re-assert only the parent immediately before
    # every OpenCode exec so two workspaces starting together cannot hand Bun a
    # missing `.cache/opencode` directory. Never create `bin`: OpenCode owns that
    # leaf and treats it as its own initialization marker.
    # AICLI_OPENCODE_CACHE_PARENT_BEGIN
    _ensure_opencode_cache_parent() {
        [ "$AGENT_ID" = "opencode" ] || return 0
        mkdir -p "$HOME_DIR/.cache/opencode" 2>/dev/null || return 1
        [ -d "$HOME_DIR/.cache/opencode" ]
    }
    # AICLI_OPENCODE_CACHE_PARENT_END
    safe_exec() {
        local cmd="$1"
        if ! _ensure_opencode_cache_parent; then
            log_aicli "ERROR" 1 "OpenCode #276: could not restore the cache parent before launch"
            return 1
        fi
        # Issue #71: log the effective NODE_OPTIONS alongside every launch so
        # heap-limit forensics never depend on reconstructing the environment.
        log_aicli "INFO" 2 "Executing: $cmd (NODE_OPTIONS=${NODE_OPTIONS:-<unset>})"
        bash -c "$cmd"
    }

    # D-402 (#54): Detect whether the resolved binary is a native ELF executable.
    # If it is, the "fall back to node" branches below are meaningless (node cannot
    # run ELF) and actively harmful — a legitimate non-zero exit from the native
    # binary (e.g. Goose exiting because no provider is configured) was being
    # masked as "binary corrupted" when node then failed to parse the ELF bytes.
    is_elf_binary() {
        local target="$1"
        local resolved
        resolved=$(readlink -f "$target" 2>/dev/null || echo "$target")
        [ -f "$resolved" ] || return 1
        [ "$(head -c 4 "$resolved" 2>/dev/null | tr -d '\0' | od -An -c | tr -d ' \n')" = "177ELF" ]
    }

    status="fail"
    last_launch_duration=0
    last_launch_rc=1
    if [ "$AGENT_ID" == "terminal" ]; then
        /bin/bash
        status="ok"
    elif [ "$can_resume" == "1" ] && [ -n "$frozen_chat_id" ] && [ "$frozen_chat_id" != "none" ]; then
        # Substitute both {chatId} and {binary}. Short command names (claude,
        # copilot, etc) don't resolve when agents ship their binary under a
        # different filename (e.g. Claude Code 2.1 ships bin/claude.exe, not
        # claude) — so registry templates use {binary} for an absolute path.
        #
        # Shell-escape the chat id before interpolation. Claude Code supports
        # renaming a session (/rename) and prints the name on exit instead of
        # a UUID — if the name contains spaces or apostrophes, a raw substitute
        # produces a broken command line. printf %q yields a safely-quoted
        # token that bash re-parses back to the literal. Bare-UUID ids round-
        # trip unchanged, so existing agents are unaffected.
        FINAL_CMD=$(_aicli_build_resume_cmd "$frozen_resume_cmd" "$frozen_chat_id" "$frozen_binary" "$frozen_effective_args")
        log_aicli "INFO" 2 "Attempting Resume: $FINAL_CMD"

        # 1. Command-based Execution (Uses PATH or absolute path)
        _attempt_started=$(date +%s)
        safe_exec "$FINAL_CMD"
        _attempt_rc=$?
        _aicli_record_agent_exit "explicit-resume" "$_attempt_rc" "$_attempt_started"
        if [ "$_attempt_rc" -eq 0 ]; then
            status="ok"
        elif _aicli_resume_was_established "$last_launch_duration"; then
            # The resume DID start and owned the terminal for a meaningful
            # period. Its later non-zero exit is a process failure/termination,
            # not evidence that the resume command was invalid. Never replace
            # that conversation with a silent fresh launch.
            status="ok"
            log_aicli "WARN" 1 "Resumed agent exited non-zero after ${last_launch_duration}s (rc=$_attempt_rc); preserving conversation for resume-first relaunch"
        else
            log_aicli "WARN" 1 "Resume command failed during startup after ${last_launch_duration}s (rc=$_attempt_rc); preserving continuity and refusing fresh fallback"
            status="resume_failed"
        fi
    elif [ "$can_resume" == "1" ]; then
        LATEST_CMD=$(_aicli_build_resume_cmd "$frozen_resume_latest" "" "$frozen_binary" "$frozen_effective_args")
        log_aicli "INFO" 2 "Attempting Latest Resume: $LATEST_CMD"
        _attempt_started=$(date +%s)
        safe_exec "$LATEST_CMD"
        _attempt_rc=$?
        _aicli_record_agent_exit "latest-resume" "$_attempt_rc" "$_attempt_started"
        if [ "$_attempt_rc" -eq 0 ]; then
            status="ok"
        elif [ -z "$frozen_chat_id" ] && ! _aicli_resume_was_established "$last_launch_duration"; then
            # 2026-09-10: a SPECULATIVE latest-resume that never started must fall through
            # to a fresh launch, not park.
            #
            # can_resume is decided per agent from a HOME-WIDE store (grok-build looks at
            # ~/.grok/sessions, and so on), but '--continue' resolves a session for the
            # CURRENT DIRECTORY. So a brand-new workspace in a new folder sets can_resume=1
            # off another workspace's sessions, runs '--continue', and the agent exits with
            # "No session found for current directory" — the workspace then parked on the
            # [Agent Exited Immediately] banner and could never be used. Observed on .4 for
            # grok-build and kilocode by creating a fresh workspace for each.
            #
            # Parking exists to protect a KNOWN conversation. frozen_chat_id is empty here,
            # so there is nothing to lose: no id was handed in and getResumeId/findSession
            # found nothing for this workspace. The explicit-chatId branch above is
            # untouched and still parks.
            log_aicli "WARN" 1 "Speculative latest-resume failed at startup (rc=$_attempt_rc) and this workspace has no known conversation; starting fresh instead of parking"
            status="fail"
        elif _aicli_resume_was_established "$last_launch_duration"; then
            status="ok"
            log_aicli "WARN" 1 "Resumed agent exited non-zero after ${last_launch_duration}s (rc=$_attempt_rc); preserving conversation for resume-first relaunch"
        else
            log_aicli "WARN" 1 "Resume command failed during startup after ${last_launch_duration}s (rc=$_attempt_rc); preserving continuity and refusing fresh fallback"
            status="resume_failed"
        fi
    fi

    # Fresh launch is allowed only when no resumable conversation was selected.
    # A failed explicit/latest resume must park visibly and retry resume after
    # confirmation; silently replacing it with a blank conversation loses the
    # very context this wrapper exists to preserve.
    if [ "$status" == "fail" ]; then
        # Append plugin_args (e.g. codex sandbox overrides) AFTER user workspace
        # args so codex's last-`-c`-wins makes the plugin value override any
        # user workspace arg. These are plugin-injected and not user-editable.
        FRESH_CMD=$(_build_fresh_cmd "$frozen_binary" "$frozen_effective_args" "$frozen_plugin_args")
        # Helper workspace: the first prompt goes in once, on the first fresh launch only.
        FRESH_CMD="$FRESH_CMD$(_aicli_task_prompt_suffix)"
        log_aicli "INFO" 2 "Attempting Fresh Launch: $FRESH_CMD"

        # 1. Command-based Execution
        _attempt_started=$(date +%s)
        safe_exec "$FRESH_CMD"
        _attempt_rc=$?
        _aicli_record_agent_exit "fresh" "$_attempt_rc" "$_attempt_started"
        if [ "$_attempt_rc" -eq 0 ]; then
            status="ok"
        elif _aicli_resume_was_established "$last_launch_duration"; then
            # The fresh command also genuinely started. A later Ctrl-C/signal
            # must return to the sentinel/session-sync logic, not invoke the JS
            # binary again as a second blank process.
            status="ok"
            log_aicli "WARN" 1 "Fresh agent exited non-zero after ${last_launch_duration}s (rc=$_attempt_rc); treating it as an established process exit"
        else
            # 2. Deep Fallback — only meaningful for a JS file that failed
            # during startup, before it established an interactive lifecycle.
            if [[ "$frozen_binary" == *"/"* ]] && ! is_elf_binary "$frozen_binary"; then
                log_aicli "INFO" 2 "Native launch failed. Trying explicit node launch on $frozen_binary..."
                _attempt_started=$(date +%s)
                node "$frozen_binary"
                _attempt_rc=$?
                _aicli_record_agent_exit "fresh-node-fallback" "$_attempt_rc" "$_attempt_started"
                if [ "$_attempt_rc" -eq 0 ]; then
                    status="ok"
                fi
            fi
        fi
    fi
    
    if [ "$status" = "resume_failed" ]; then
        log_aicli "ERROR" 1 "Resume failed for $AGENT_ID (rc=$last_launch_rc); refusing silent fresh fallback"
    elif [ "$status" != "ok" ]; then
        log_aicli "ERROR" 1 "Agent launch attempts ended before an interactive session was established (agent=$AGENT_ID rc=$last_launch_rc). Check $DEBUG_LOG and the captured crash record."
    fi

    # #610: the "Start New Session" mark covers the FIRST launch only. Clear it
    # now, so every later relaunch in this tmux session resumes the chat the
    # agent just started instead of opening a blank one each time.
    _aicli_clear_fresh_mark

    # Restore PTY line discipline after every agent exit. TUI agents (agy,
    # gemini-cli, claude-code) call cfmakeraw() which disables ONLCR; on exit
    # they should restore it via tcsetattr but often don't, leaving the PTY in
    # raw mode — the next prompt or clear then renders as a diagonal staircase.
    # Also re-assert TERM in case a dumb parent environment leaked through.
    stty sane 2>/dev/null
    { [ "$TERM" = "dumb" ] || [ -z "$TERM" ]; } && export TERM=xterm-256color

    if [ "$AGENT_ID" == "terminal" ]; then exit 0; fi

    # Graceful-close sentinel: if the UI requested a clean shutdown (Ctrl-C x2
    # then touch of close-<id>.flag), the agent has already flushed its state
    # and emitted its resume id. Break out of the relaunch loop so the user
    # isn't greeted by "Press ENTER to reload" on a closed workspace.
    # #814: wait for the sentinel while a close is under way (see _aicli_wait_while_closing).
    _aicli_wait_while_closing
    if [ -f "${MOUNT_ROOT}/close-$AICLI_SESSION_ID.flag" ]; then
        rm -f "${MOUNT_ROOT}/close-$AICLI_SESSION_ID.flag" 2>/dev/null
        log_aicli "INFO" 2 "Graceful close sentinel observed — exiting relaunch loop."
        break
    fi

    # Refresh Claude's active workspace conversation BEFORE any automatic
    # relaunch path. In particular, Apply-now's auto-reload used to skip the
    # post-exit GUID sync and could relaunch a stale or blank conversation.
    _aicli_sync_claude_chat

    # WP #275: Auto-reload sentinel. When the UI's "Apply now" button (workspace
    # args modal) sends Ctrl-C to apply args changes, it also touches this flag
    # BEFORE the Ctrl-C. The user shouldn't see a "Press ENTER to reload" prompt
    # in that case — they explicitly asked for an immediate restart. Skip the
    # prompt and relaunch immediately. The args refresh at the top of the next
    # iteration picks up the new value.
    if [ -f "${MOUNT_ROOT}/auto-reload-$AICLI_SESSION_ID.flag" ]; then
        rm -f "${MOUNT_ROOT}/auto-reload-$AICLI_SESSION_ID.flag" 2>/dev/null
        log_aicli "INFO" 2 "Auto-reload sentinel observed — skipping reload prompt, relaunching immediately."
        continue
    fi

    # Post-exit GUID sync: when the user /resume's inside the TUI and selects a
    # different chat, the agent's on-disk session file changes but the shell's
    # frozen_chat_id (baked at session start) doesn't. Scan the agent's session
    # store after every exit and update both frozen_chat_id (for the next relaunch)
    # and the durable resume file (for the next workspace open). Only runs when
    # neither sentinel fired — graceful-close is handled by PHP, auto-reload does
    # not need a GUID update.
    if [ -n "$AICLI_ENV_HASH" ]; then
        _discovered_chat=""
        if [ "$AGENT_ID" == "antigravity-cli" ]; then
            # After an in-TUI conversation switch, agy writes the active chat's
            # <uuid>.pb. Newest .pb by mtime = the just-active conversation; sync it
            # so the next Ctrl-C relaunch resumes THAT chat, not the baked-in one.
            _acd="$HOME_DIR/.gemini/antigravity-cli/conversations"
            if [ -d "$_acd" ]; then
                _newest_pb=$(find "$_acd" -name "*.pb" -type f -printf '%T@ %p\n' 2>/dev/null | sort -rn | head -1 | cut -d' ' -f2-)
                if [ -n "$_newest_pb" ]; then
                    _discovered_chat=$(basename "$_newest_pb" .pb)
                fi
            fi
        fi
        if [ -n "$_discovered_chat" ] && [ "$_discovered_chat" != "$frozen_chat_id" ]; then
            log_aicli "INFO" 2 "Post-exit GUID sync: $frozen_chat_id -> $_discovered_chat"
            frozen_chat_id="$_discovered_chat"
            _resume_dir="$HOME_DIR/.aicli/resumes"
            _resume_file="${_resume_dir}/resume_${AICLI_ENV_HASH}.json"
            mkdir -p "$_resume_dir" 2>/dev/null
            printf '{"chat_id":"%s","saved_at":%d}\n' "$_discovered_chat" "$(date +%s)" > "${_resume_file}.tmp" \
                && mv "${_resume_file}.tmp" "$_resume_file" 2>/dev/null
        fi
    fi

    # D-403 (#55): Fast-exit guard. Agents that exit in under 3 seconds are almost
    # always bailing on first-launch setup (e.g. Goose with no GOOSE_PROVIDER set
    # prints "Error: not connected" and exits immediately). Auto-relaunching in
    # that state produces an infinite loop of the same first-run prompt. When a
    # fast exit is detected, require an explicit ENTER instead of timing out after
    # 10s so the user has a chance to read the message and close the workspace.
    launch_duration="$last_launch_duration"
    # #888: the restart decision lives in user/agent-restart-policy.sh (sourced at call time).
    # A missing file (older release on disk) falls back to the old behaviour: "auto".
    _restart_mode="auto"
    _restart_policy_file="$PLUGIN_SRC/scripts/user/agent-restart-policy.sh"
    if [ -f "$_restart_policy_file" ]; then
        unset -f aicli_restart_policy 2>/dev/null || true
        # shellcheck source=/dev/null -- release symlink intentionally resolves at call time
        source "$_restart_policy_file"
        if declare -F aicli_restart_policy >/dev/null 2>&1; then
            _restart_out=$(aicli_restart_policy "$launch_duration" "$last_launch_rc" "$consecutive_short_failures")
            _restart_mode="${_restart_out%% *}"
            consecutive_short_failures="${_restart_out##* }"
        fi
    fi
    if [ "$launch_duration" -lt 3 ]; then
        consecutive_fast_crashes=$((consecutive_fast_crashes + 1))
        # #37: after repeated immediate crashes, stop blaming "configuration" — the
        # binary itself is almost certainly broken/incompatible. Give the operator the
        # real remedy (upgrade/reinstall) instead of a bare retry that just crashes again.
        if [ "$consecutive_fast_crashes" -ge 3 ]; then
            log_aicli "WARN" 1 "Agent $AGENT_ID exited immediately $consecutive_fast_crashes times in a row — binary likely broken; not auto-retrying"
            echo -e "\n\033[1;31m[Agent Keeps Crashing]\033[0m $AGENT_ID has exited immediately ${consecutive_fast_crashes} times in a row — its binary is likely broken or incompatible (not a config problem)."
            echo -e "Upgrade or reinstall $AGENT_ID from Settings, then reopen this workspace. Press ENTER to try again, or close this workspace from the UI."
        else
            echo -e "\n\033[1;31m[Agent Exited Immediately]\033[0m The agent exited after ${launch_duration}s — likely missing configuration."
            echo -e "Press ENTER to retry, or close this workspace from the UI."
        fi
        read -r
    elif [ "$_restart_mode" = "enter-repeat" ]; then
        consecutive_fast_crashes=0
        # #888: 3 short failures in a row. Wait for ENTER with no timeout. ENTER keeps the count.
        log_aicli "WARN" 1 "Agent $AGENT_ID stopped with an error $consecutive_short_failures times in a row (last rc=$last_launch_rc, last duration=${launch_duration}s); not auto-retrying"
        echo -e "\n\033[1;31m[Agent Keeps Failing]\033[0m $AGENT_ID stopped with an error ${consecutive_short_failures} times in a row, each within a minute. Check its log or settings. Press ENTER to try again, or close this workspace from the UI."
        read -r
    else
        consecutive_fast_crashes=0
        echo -e "\n\033[1;33m[Agent Exited]\033[0m Press ENTER to reload..."
        read -t 10 -r
    fi
done
EOF




    chmod 700 "$RUN_SCRIPT"
    log_aicli "DEBUG" 3 "Launching tmux session $SESSION for script $RUN_SCRIPT"
    perf_log tmux.new.begin
    # Bug #1054 follow-up: re-sanitize the per-uid socket dir immediately before
    # new-session, in case anything since the early setup left it with perms tmux
    # rejects. Cheap and idempotent.
    sanitize_tmux_uid_dir
    # Pin the new session's start dir to the workspace. Without -c, new-session
    # takes the invoking client / tmux-server cwd, so a headless --ensure-session
    # relaunch landed the agent in the server's /mnt instead of $ROOT_DIR (agy
    # exposed this; cwd-sensitive agents masked it on browser starts). $ROOT_DIR
    # is ${AICLI_ROOT:-/mnt} so it's never empty.
    tmux -u new-session -d -s "$SESSION" -c "${WORK_CWD:-$ROOT_DIR}" "$RUN_SCRIPT" 2>>"$DEBUG_LOG"
    _tmux_rc=$?
    if [ "$_tmux_rc" -ne 0 ]; then
        log_aicli "ERROR" 1 "Failed to create tmux session $SESSION. Check $DEBUG_LOG"
    fi
    perf_log tmux.new.done
    # Forgejo #433: log the end of this session, and remember the server pid so a later start can tell a killed server
    # from an agent that simply exited.
    tmux set-hook -g session-closed "run-shell -b '$PLUGIN_SRC/scripts/tmux-session-closed.sh #{hook_session_name} $DEBUG_LOG'" 2>/dev/null
    tmux display-message -p '#{pid}' > "${TMUX_TMPDIR:-${MOUNT_ROOT}/tmux/s-$ID}/server.pid" 2>/dev/null
    # RESPONSIVE_PRIORITY.md R5: a new tmux server starts at nice 0. When the setting is on,
    # raise it now. The script reads the setting itself and does nothing when it is off.
    if [ -f "$PLUGIN_SRC/scripts/priority.sh" ]; then
        bash "$PLUGIN_SRC/scripts/priority.sh" auto >/dev/null 2>&1 </dev/null &
    fi
fi

log_aicli "DEBUG" 3 "Attaching to tmux session $SESSION..."
perf_log tmux.options.begin

# #371 (docs/specs/PASTE_ENTER_CONFIRM.md): idempotent helpers for the SERVER array
# options terminal-overrides / terminal-features. This block runs on every attach,
# and `set-option -a` alone grows the list by one copy each time.
# tmux_append_once <option> <",entry[,entry…]">: append each entry that is missing.
tmux_append_once() {
    local opt="$1" val="${2#,}" have entry
    local -a entries
    have=$(tmux show-options -sv "$opt" 2>/dev/null)
    IFS=',' read -r -a entries <<< "$val"
    for entry in "${entries[@]}"; do
        [ -n "$entry" ] || continue
        printf '%s\n' "$have" | grep -qxF -- "$entry" && continue
        tmux set-option -a -t "$SESSION" "$opt" ",$entry" 2>/dev/null
        have="$have"$'\n'"$entry"
    done
}
# tmux_dedupe_array <option>: unset every later copy of an entry (by index), so a
# server polluted by the old append keeps one copy of each, in the first order.
tmux_dedupe_array() {
    local opt="$1" line idx val
    local -A seen=()
    local -a drop=()
    while IFS= read -r line; do
        [[ "$line" =~ ^${opt}\[([0-9]+)\]\ (.*)$ ]] || continue
        idx="${BASH_REMATCH[1]}"; val="${BASH_REMATCH[2]}"
        val="${val#\"}"; val="${val%\"}"
        if [ -n "${seen[$val]+x}" ]; then drop+=("$idx"); else seen[$val]=1; fi
    done < <(tmux show-options -s "$opt" 2>/dev/null)
    for idx in "${drop[@]}"; do
        tmux set-option -s -u "${opt}[${idx}]" 2>/dev/null
    done
}

# ---------- Four-tier tmux configuration ----------
# Tier 1 — Built-in defaults (safety net; also mirrored in TmuxService::BUILTIN).
# T-01: every key in TmuxService::BUILTIN must have a matching line here — the
#        parity is enforced by TmuxBaselineParityTest.php in CI.
tmux set-option -t "$SESSION" history-limit "$HISTORY_LIMIT" 2>/dev/null
tmux set-option -t "$SESSION" status off 2>/dev/null
tmux set-option -t "$SESSION" mouse off 2>/dev/null
tmux set-option -t "$SESSION" prefix C-b 2>/dev/null
tmux set-option -t "$SESSION" base-index 0 2>/dev/null
tmux set-option -t "$SESSION" bell-action any 2>/dev/null
tmux set-option -t "$SESSION" allow-passthrough on 2>/dev/null
tmux set-option -t "$SESSION" focus-events on 2>/dev/null
# WP #1253: escape-time 0 — tmux's 500ms default makes a lone ESC ambiguous (key
# vs. start-of-sequence). When a fast TUI streamer (e.g. antigravity) emits an
# escape sequence whose bytes arrive SPLIT across reads over the ttyd/websocket
# pipe, tmux waits then mis-parses the ESC, emitting literal bytes / dropping the
# sequence -> intermittent blank/garble of streamed output. 0 is the canonical
# TUI-app setting and is harmless on a fast local-socket terminal.
tmux set-option -t "$SESSION" escape-time 0 2>/dev/null
# Two clients may now be attached at once (desktop + phone). tmux's default
# sizes the window to the SMALLEST attached client, so a phone would squash a
# desktop tab down to its width for as long as it stayed connected. 'latest'
# sizes to the most recently used client, so whichever device you are actually
# typing on gets the correct geometry.
tmux set-option -t "$SESSION" window-size latest 2>/dev/null
# xterm-256color: tells apps inside tmux the correct terminal type (not screen),
# avoiding line-translation issues when TUI agents (agy, gemini-cli) set raw PTY mode.
# The terminal-overrides appends enable 24-bit colour pass-through from ttyd/the browser.
# T-02: set-clipboard on is required for OSC 52 clipboard pass-through (WP#964/T-05).
# T-02: extended-keys off globally; per-agent quirk profiles (T-07) enable it for Claude Code.
# T-02: RGB is the modern synonym for Tc; xterm.js 5.x recognises both. Both can coexist
#        as accumulated -ga entries; the existing Tc entry stays for older clients.
tmux set-option -t "$SESSION" default-terminal "$_AICLI_DEFTERM" 2>/dev/null
tmux set-option -t "$SESSION" set-clipboard on 2>/dev/null
tmux set-option -t "$SESSION" extended-keys off 2>/dev/null
# #371: terminal-overrides and terminal-features are SERVER array options, and
# this block runs on every terminal attach. A plain `set-option -a` added the
# same entries again each time (233 copies of each on one server). Remove old
# copies once, then append an entry only when it is not there yet.
tmux_dedupe_array terminal-overrides
tmux_dedupe_array terminal-features
tmux_append_once terminal-overrides ",xterm-256color:Tc"
tmux_append_once terminal-overrides ",xterm-256color:RGB"
# tmux-256color (bundled terminfo, opt-in via default-terminal): same truecolor
# pass-through, and propagate TERMINFO_DIRS into the server env so panes find it.
tmux_append_once terminal-overrides ",tmux-256color:Tc"
tmux_append_once terminal-overrides ",tmux-256color:RGB"
[ -n "${TERMINFO_DIRS:-}" ] && tmux set-environment -g TERMINFO_DIRS "$TERMINFO_DIRS" 2>/dev/null

# Helper: apply the JSON files of the tiers (allow-listed tmux options) in ONE PHP pass (S4).
# The files that exist go to one apply-tmux-json.php call, in the order given; a file that does
# not exist is skipped, and there is no log call per file.
# T-03: allowed/append key lists are single-sourced from TmuxService::ALLOWED_KEYS and
#        TmuxService::APPEND_KEYS rather than duplicated here as string literals, so any
#        future extension to the PHP const is automatically reflected in the shell tier.
# Lives in a script file (apply-tmux-json.php), NOT `php -r`: backslash namespaces in a
# double-quoted -r body are eaten by bash (publish anti-pattern rule, exit 3). The
# script also accepts APPEND_KEYS entries (quirk files carry terminal-features) which
# the old inline filter accidentally dropped.
apply_tmux_json() {
    local _f
    local -a _present=()
    for _f in "$@"; do
        [ -n "$_f" ] && [ -f "$_f" ] && _present+=("$_f")
    done
    [ "${#_present[@]}" -gt 0 ] || return 0
    php "$PLUGIN_SRC/scripts/user/apply-tmux-json.php" \
        "${_present[0]}" "$SESSION" "${_present[@]:1}" 2>>"$DEBUG_LOG" | bash 2>>"$DEBUG_LOG"
}

# Legacy migration: rename pre-4-tier per-(ws,agent) hash files to .legacy so the old
# layout doesn't silently override the new tiers. Idempotent. Runs cheap after the
# first launch because there's nothing left to match.
for _legacy in "$HOME_DIR/.aicli/tmux/"tmux_*.json; do
    [ -e "$_legacy" ] || continue
    _legacy_base="${_legacy##*/}"
    case "$_legacy_base" in
        tmux_agent_*.json|tmux_ws_*.json) continue ;;
    esac
    if [[ "$_legacy_base" =~ ^tmux_[a-f0-9]{32}\.json$ ]]; then
        mv "$_legacy" "$_legacy.legacy" 2>/dev/null && \
            log_aicli "WARN" 2 "Renamed legacy tmux config: $_legacy_base -> $_legacy_base.legacy (reconfigure via Store card / workspace drawer)"
    fi
done
unset _legacy _legacy_base

# Tier 1.5 — Agent quirk profile (not user-editable; written by TerminalService
# before launch). Sits between BUILTIN and user-editable tiers so structural
# requirements like Claude Code's extended-keys + terminal-features are applied
# after the safety-net defaults but can still be overridden by the user.
# apply_tmux_json supports APPEND_KEYS (-ga semantics) so terminal-features
# accumulates rather than clobbers the BUILTIN terminal-overrides entries.
# Bug #141: quirk files are written by PHP (TmuxService::quirkPath) into the
# SHARED tmux root, not the per-session TMUX_TMPDIR — read them from there.
# Tier 2 (agent JSON) and Tier 3 (workspace JSON) go in the same pass, in that order, so the
# later tier wins. Tier 2 is tmux_agent_<agent>.json (edited via the Store card's Terminal
# panel). Tier 3 is tmux_ws_<md5(ROOT_DIR)>_<agent>.json (edited via the drawer tmux tab); the
# md5 keeps the deltas of one agent isolated per workspace.
# S2: before the pass, note the name, mtime and size of every tier input. A file that changes
# while the pass runs then shows at the next connect. The note is stored after Tier 4.
_AICLI_TIER_AGENT="$HOME_DIR/.aicli/tmux/tmux_agent_${AGENT_ID}.json"
_AICLI_TIER_WS=""
if [ -n "$ROOT_DIR" ]; then
    WS_HASH=$(printf %s "$ROOT_DIR" | md5sum | cut -d' ' -f1)
    _AICLI_TIER_WS="$HOME_DIR/.aicli/tmux/tmux_ws_${WS_HASH}_${AGENT_ID}.json"
fi
WS_TMUX_CONF="$ROOT_DIR/.aicli/tmux/${AGENT_ID}.conf"
_AICLI_TIER_FILES="$AICLI_TMUX_ROOT/quirks_${AGENT_ID}.json|$_AICLI_TIER_AGENT|$_AICLI_TIER_WS|$WS_TMUX_CONF"
_AICLI_TIER_STAMP="$(_aicli_tiers_stamp "$_AICLI_TIER_FILES")"
apply_tmux_json "$AICLI_TMUX_ROOT/quirks_${AGENT_ID}.json" "$_AICLI_TIER_AGENT" "$_AICLI_TIER_WS"
# Tier 2 — Agent-level defaults and Tier 3 — Workspace-level overrides: applied by the call above.

# Tier 4 — Power-user workspace .conf (raw tmux syntax, escape hatch — wins all).
if [ -n "$ROOT_DIR" ] && [ -f "$WS_TMUX_CONF" ] && [ -r "$WS_TMUX_CONF" ]; then
    log_aicli "DEBUG" 3 "Sourcing workspace tmux conf: $WS_TMUX_CONF"
    if ! tmux source-file -t "$SESSION" "$WS_TMUX_CONF" 2>>"$DEBUG_LOG"; then
        log_aicli "WARN" 2 "Workspace tmux conf had errors (see $DEBUG_LOG) - prior tiers remain active"
    fi
fi
# S2: the options are applied; store the input note. The fast attach at the top compares it with
# the files at each later connect, and runs this block again only when it differs.
tmux set-option -t "$SESSION" @aicli_tiers_files "$_AICLI_TIER_FILES" 2>/dev/null
tmux set-option -t "$SESSION" @aicli_tiers_stamp "$_AICLI_TIER_STAMP" 2>/dev/null
perf_log tmux.options.done
# D-400: exec replaces this process - error handling must happen before exec
if ! tmux has-session -t "$SESSION" 2>/dev/null; then
    log_aicli "ERROR" 1 "tmux session $SESSION not found before attach. Check $DEBUG_LOG"
    echo "Terminal session not found. Check debug log."
    sleep 5
    exit 1
fi

# R-B1: headless ensure-session mode — the detached session now exists (verified
# by the has-session check above) with the agent running inside it, and all four
# tmux config tiers have been applied. Return success WITHOUT attaching; the
# session lives on independent of any browser. A later interactive invocation
# (ttyd on browser-connect) re-enters this script, finds the session already
# present (the new-session block is skipped), re-applies options idempotently,
# and falls through to the attach below.
if [ "$AICLI_ENSURE_ONLY" -eq 1 ]; then
    log_aicli "INFO" 2 "ensure-session: detached session $SESSION is live — returning without attach."
    # Forgejo #521: clean clients of dead ttyd processes on this path too.
    # Safe: it detaches only clients with no live ttyd in their ancestry.
    detach_dead_ttyd_clients "$SESSION"
    perf_log ensure.session.done
    exit 0
fi

aicli_attach_exec
