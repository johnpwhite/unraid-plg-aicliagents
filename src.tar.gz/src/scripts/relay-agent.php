#!/usr/bin/env php
<?php
/**
 * Relay self-service control for an already-running agent workspace.
 * Identity is the launch-injected AICLI_SESSION_ID; callers never supply one.
 * Usage: relay-agent.php <topics|subscriptions|inbox|contacts|direct|reply|create|update|archive|delete|join|leave|publish|request|request-status|cancel-request|ack|resolve|fail|drain-all|peer-sync> ...
 *
 * A contact on a linked box has an id like peer_<12 hex>__<session id> and the
 * name "<workspace> @ <box>". direct and reply take it like any other id.
 *
 * Two of these take positional arguments that are easy to get wrong:
 *   direct <recipient_session_id> <message>
 *   reply  <thread_id> <message> <recipient_session_id>      <- recipient is LAST
 * reply keeps the exchange in ONE thread; direct always opens a new one. mvp-dmoe
 * reported reply as broken (2026-09-08) after calling it with two arguments and
 * reading the direct usage from the error, so both shapes are spelled out here,
 * in --help, and in the error itself.
 * Event summaries, request summaries, and response notes are limited to 2048 bytes.
 * request <topic> <summary> [ack_seconds] [resolve_seconds] [client_request_id]
 * cancel-request <request_id> [note]   (the original sender only, before it is closed)
 */

/**
 * Always run the LIVE generation's code (Forgejo #333). A workspace can hold a
 * command path that names the generation it launched with
 * (`.generations/<id>/src/scripts/relay-agent.php`), and that tree never
 * changes, so after an update the command ran old Relay code against the
 * shared Relay store — the same fault that made an old MCP server keep a
 * linked-box reply as a local message. Before loading any code, hand this call
 * over to the live generation's relay-agent.php with the same arguments.
 * The guard variable stops a second hop.
 */
if (getenv('AICLI_RELAY_AGENT_LIVE_HOP') === false) {
    $relayAgentLink = (string)(getenv('AICLI_RELAY_AGENT_LIVE_SRC') ?: '/usr/local/emhttp/plugins/unraid-aicliagents/src');   // test seam
    $relayAgentLive = realpath($relayAgentLink);
    $relayAgentMine = realpath(__DIR__ . '/..');
    // Only an INSTALLED generation hops (its tree sits under the plugin
    // directory). A copy run from a repository checkout serves itself.
    $relayAgentPluginDir = realpath(dirname($relayAgentLink));
    if ($relayAgentLive !== false && $relayAgentMine !== false && $relayAgentLive !== $relayAgentMine
        && $relayAgentPluginDir !== false && strpos($relayAgentMine, $relayAgentPluginDir . '/') === 0
        && is_file($relayAgentLive . '/scripts/relay-agent.php')) {
        putenv('AICLI_RELAY_AGENT_LIVE_HOP=1');
        $relayAgentArgs = array_merge([$relayAgentLive . '/scripts/relay-agent.php'], array_slice($argv, 1));
        if (function_exists('pcntl_exec')) @pcntl_exec(PHP_BINARY, $relayAgentArgs);
        // No pcntl (or the exec failed): run it as a child with the same stdio.
        $relayAgentRc = 1;
        passthru(implode(' ', array_map('escapeshellarg', array_merge([PHP_BINARY], $relayAgentArgs))), $relayAgentRc);
        exit($relayAgentRc);
    }
}

/**
 * TERMINAL_FAST_ATTACH.md S5: run once more with the PHP file cache, so the plugin's files are
 * not parsed again on each call. opcache.* are start-up settings: a script cannot turn them on
 * for itself, so it replaces its own process with a second PHP that has the flags (same argv,
 * same stdin, same exit code, same environment: no variable is added). It happens only when the
 * OPcache extension is loaded, no file cache is set yet, pcntl is available and the checked cache
 * folder is usable (UtilityService::phpCacheFlags). The second PHP has the file cache set, so
 * the condition is false there and no loop is possible. Without pcntl the script runs without the
 * cache; it never goes through a shell, because a shell hop would change the environment that
 * the caller controls.
 */
if (PHP_SAPI === 'cli' && extension_loaded('Zend OPcache') && (string)ini_get('opcache.file_cache') === ''
    && function_exists('pcntl_exec')) {
    require_once __DIR__ . '/../includes/services/SecretPaths.php';
    require_once __DIR__ . '/../includes/services/UtilityService.php';
    $cacheFlags = \AICliAgents\Services\UtilityService::phpCacheFlags();
    if ($cacheFlags !== []) {
        @pcntl_exec(PHP_BINARY, array_merge($cacheFlags, [$argv[0]], array_slice($argv, 1)));
    }
}

require_once __DIR__ . '/../includes/AICliAgentsManager.php';

use AICliAgents\Services\AgentRelayService;
use AICliAgents\Services\TmuxService;

$session = (string)(getenv('AICLI_SESSION_ID') ?: '');
$action = $argv[1] ?? 'topics';
$topic = $argv[2] ?? '';
$description = $argv[3] ?? '';

// #664 R-145: every action but the session-agnostic maintenance ones acts AS a
// session. With no AICLI_SESSION_ID it must stop with an error, not write
// anything under an empty id.
$relayAgentMaintenance = ['drain-all', 'peer-sync', 'sweep-orphans', 'purge-test-traces', 'http-listener-reconcile', 'help', '--help', '-h'];
if ($session === '' && !in_array($action, $relayAgentMaintenance, true)) {
    echo json_encode(['status'=>'error', 'message'=>'AICLI_SESSION_ID is not set, so this shell is not a Relay session. Run this command from an agent workspace.'], JSON_UNESCAPED_SLASHES) . PHP_EOL;
    exit(1);
}

switch ($action) {
    case 'topics':        $result = \AICliAgents\Services\RelayMcpTools::call('relay_list_topics', [], $session, null, null, 'relay-cli'); break;
    case 'subscriptions': $result = \AICliAgents\Services\RelayMcpTools::call('relay_cli_subscriptions', [], $session, null, null, 'relay-cli'); break;
    // inbox [--all] [--limit N] [--before ID|TIME] [--after ID|TIME] [--message-id ID]
    // No option: only UNREAD items. Any option (or --all): the old newest-20 view. Same rules as relay_get_inbox.
    case 'inbox':
        $inboxArgs = [];
        for ($i = 2; $i < count($argv); $i += 2) {
            if ((string)$argv[$i] === '--all') { $inboxArgs['all'] = true; $i--; continue; }
            $key = ltrim((string)$argv[$i], '-'); $key = $key === 'message-id' ? 'message_id' : $key;
            if (in_array($key, ['limit','before','after','message_id'], true) && isset($argv[$i + 1])) $inboxArgs[$key] = (string)$argv[$i + 1];
        }
        $result = \AICliAgents\Services\RelayMcpTools::call('relay_get_inbox', $inboxArgs, $session, null, null, 'relay-cli');
        break;
    case 'contacts':      $result = \AICliAgents\Services\RelayMcpTools::call('relay_list_contacts', [], $session, null, null, 'relay-cli'); break;
    case 'direct':        $result = \AICliAgents\Services\RelayMcpTools::call('relay_send_direct_message', ['recipient_session_id' => $topic, 'summary' => $description], $session, null, null, 'relay-cli'); break;
    case 'reply':         $result = \AICliAgents\Services\RelayMcpTools::call('relay_send_direct_message', ['recipient_session_id' => (string)($argv[4] ?? ''), 'summary' => $description, 'thread_id' => $topic], $session, null, null, 'relay-cli'); break;
    case 'create':        $result = \AICliAgents\Services\RelayMcpTools::call('relay_cli_create_topic', ['topic' => $topic, 'description' => $description], $session, null, null, 'relay-cli'); break;
    case 'update':        $result = \AICliAgents\Services\RelayMcpTools::call('relay_cli_update_topic', ['topic' => $topic, 'description' => $description], $session, null, null, 'relay-cli'); break;
    case 'archive':       $result = \AICliAgents\Services\RelayMcpTools::call('relay_cli_archive_topic', ['topic' => $topic], $session, null, null, 'relay-cli'); break;
    case 'delete':        $result = \AICliAgents\Services\RelayMcpTools::call('relay_cli_delete_topic', ['topic' => $topic], $session, null, null, 'relay-cli'); break;
    case 'join':          $result = \AICliAgents\Services\RelayMcpTools::call('relay_join_topic', ['topic' => $topic], $session, null, null, 'relay-cli'); break;
    case 'leave':         $result = \AICliAgents\Services\RelayMcpTools::call('relay_leave_topic', ['topic' => $topic], $session, null, null, 'relay-cli'); break;
    case 'publish':       $result = \AICliAgents\Services\RelayMcpTools::call('relay_publish_event', ['topic' => $topic, 'severity' => (string)($argv[3] ?? ''), 'summary' => (string)($argv[4] ?? '')], $session, null, null, 'relay-cli'); break;
    case 'request':       $result = \AICliAgents\Services\RelayMcpTools::call('relay_request', ['topic' => $topic, 'summary' => $description, 'ack_seconds' => (int)($argv[4] ?? 300), 'resolve_seconds' => (int)($argv[5] ?? 1800), 'client_request_id' => (string)($argv[6] ?? '')], $session, null, null, 'relay-cli'); break;
    case 'request-status':$result = \AICliAgents\Services\RelayMcpTools::call('relay_request_status', ['request_id' => $topic], $session, null, null, 'relay-cli'); break;
    case 'cancel-request':$result = \AICliAgents\Services\RelayMcpTools::call('relay_cancel_request', ['request_id' => $topic, 'note' => $description], $session, null, null, 'relay-cli'); break;
    case 'ack':           $result = \AICliAgents\Services\RelayMcpTools::call('relay_acknowledge_request', ['request_id' => $topic, 'note' => $description], $session, null, null, 'relay-cli'); break;
    case 'resolve':       $result = \AICliAgents\Services\RelayMcpTools::call('relay_resolve_request', ['request_id' => $topic, 'note' => $description], $session, null, null, 'relay-cli'); break;
    case 'fail':          $result = \AICliAgents\Services\RelayMcpTools::call('relay_fail_request', ['request_id' => $topic, 'note' => $description], $session, null, null, 'relay-cli'); break;
    // Session-agnostic: re-attempt delivery of every deferred DM notice across all
    // live sessions. Driven by the supervisor tick so a queued notice surfaces even
    // when no Manager browser tab is open to run the drawer poll.
    case 'drain-all':     $result = ['status'=>'ok', 'drain'=>TmuxService::drainAllPendingRelay()]; break;
    // RELAY_LINKED_BOXES.md §3: the supervisor's _relay_peer_tick. Sends each
    // linked box's outbox and refreshes hello + contacts every 60 s. Does
    // nothing when linked boxes are off or no box is paired.
    case 'peer-sync':     $result = \AICliAgents\Services\RelayPeerService::syncAll(($argv[2] ?? '') === '--force'); break;
    // #331: bring the Relay HTTP listener into the stored state (start or stop),
    // stopping any listener of an older generation. Run by the activation of a
    // new generation and by the supervisor when its audit cannot decide alone.
    // Session-agnostic and idempotent, like drain-all.
    // #383: remove the Relay traces of finished test sessions (ids "e2e…"). Session-
    // agnostic and idempotent; a running session is never touched. Run by
    // tests/lib/e2e-sessions.sh close and by the boot sweep.
    // #546: the supervisor's periodic sweep of subscriptions left by closed sessions
    // (a fresh file, a topic owner, a workspace, a DM peer and a remote client are kept).
    // R-056 (#634): the same periodic run also applies the store retention (once an hour at most).
    case 'sweep-orphans': $result = ['status'=>'ok', 'swept'=>AgentRelayService::sweepOrphanedSubscriptions(600), 'pruned'=>AgentRelayService::pruneStore()]; break;
    case 'purge-test-traces': $result = ['status'=>'ok', 'purged'=>AgentRelayService::purgeTestSessionTraces()]; break;
    case 'http-listener-reconcile': $result = AgentRelayService::ensureHttpListener(); break;
    // #773: list the actions, so an agent need not read the error text of a wrong one.
    case 'help':
    case '--help':
    case '-h':
        $result = ['status'=>'ok', 'text'=>"Usage: relay-agent.php <action> [arguments]\n"
            . "Actions: topics, subscriptions, inbox, contacts, direct, reply, create, update, archive, delete, join, leave, publish, request, request-status, cancel-request, ack, resolve, fail, help.\n"
            . "inbox: unread items only. Options: --all (older items too), --message-id ID (one exact message), --limit N, --before ID|TIME, --after ID|TIME.\n"
            . "direct <recipient_session_id> <message>   (opens a new thread)\n"
            . "reply <thread_id> <message> <recipient_session_id>   (keeps one thread; the recipient is LAST)\n"
            . "request <topic> <summary> [ack_seconds] [resolve_seconds] [client_request_id]\n"
            . "cancel-request <request_id> [note]"];
        break;
    default: $result = ['status'=>'error', 'message'=>'Unknown action. Use topics, subscriptions, inbox, contacts, direct, reply, create, update, archive, delete, join, leave, publish, request, request-status, cancel-request, ack, resolve, fail, help, drain-all, peer-sync, sweep-orphans, or purge-test-traces. Message shapes: "direct <recipient_session_id> <message>" and "reply <thread_id> <message> <recipient_session_id>".'];
}
echo json_encode($result, JSON_UNESCAPED_SLASHES) . PHP_EOL;
exit(($result['status'] ?? 'error') === 'ok' ? 0 : 1);
