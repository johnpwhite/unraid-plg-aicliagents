#!/bin/bash
_INSTALLER_RESOLVER="$(dirname "${BASH_SOURCE[0]}")/../storage/resolve_paths.sh"
[ -f "$_INSTALLER_RESOLVER" ] || _INSTALLER_RESOLVER="${EMHTTP_DEST:-/usr/local/emhttp/plugins/unraid-aicliagents}/src/scripts/storage/resolve_paths.sh"
source "$_INSTALLER_RESOLVER" || { echo 'resolve_paths.sh missing' >&2; exit 1; }
# AICliAgents Installer: Permissions, Shell Integration & Finalization

# --- Permissions ---
log_step "Setting file permissions..."
# D-80: Prune the 'agents' mount point to avoid thrashing Btrfs loopback metadata.
find "$EMHTTP_DEST" -path "$EMHTTP_DEST/agents" -prune -o -type d -exec chmod 755 {} \;
# D-50: Never blindly reset all files to 644 -- it kills executable bits for agent binaries.
chmod -R 755 "$EMHTTP_DEST/src/scripts" 2>/dev/null || true
chmod -R 755 "$EMHTTP_DEST/src/includes" 2>/dev/null || true
chmod -R 755 "$EMHTTP_DEST/src/assets" 2>/dev/null || true
# Bug #1042: the Secret Service daemon binary + launcher must be executable.
chmod -R 755 "$EMHTTP_DEST/src/secret-service" 2>/dev/null || true
chmod -R 755 "$EMHTTP_DEST/bin" 2>/dev/null || true
chmod 755 "$EMHTTP_DEST/agents" 2>/dev/null || true
chmod 755 "$EMHTTP_DEST/src/event"/* 2>/dev/null || true
log_ok "Permissions applied."

# --- Cleanup ---
rm -rf /tmp/node-extract-* /tmp/fd-extract-* /tmp/ripgrep-extract-*

# --- Unraid Event Hooks ---
# emhttpd calls /usr/local/sbin/emhttp_event <event> which loops over
# /usr/local/emhttp/plugins/*/event/<event> — the plugin's OWN event/ directory.
# It does NOT use /usr/local/emhttp/plugins/dynamix/events/.
#
# Event timing (from emhttp_event):
#   stopping          — beginning of cmdStop (before any unmounting) ← our hook point
#   unmounting_disks  — about to unmount disks and user shares
#   stopping_array    — AFTER user shares already unmounted (too late to prevent EBUSY)
#   disks_mounted     — user shares mounted (array start)
#
# We hook `stopping` (fires first, before shares unmount) so we can kill agent sessions
# whose CWDs are under /mnt/user before emhttpd tries umount. stopping_array is too late.
# The src/event/stopping handler internally detects IS_SHUTDOWN to distinguish a full
# server shutdown (kill everything) from an array-only stop (selective kill).
log_step "Registering Unraid event hooks..."

# Create event/ → src/event/ symlink so emhttp_event can find our scripts.
# emhttp_event checks for $Dir/event/<name> as a file or $Dir/event/<name>/ as a dir.
rm -f "$EMHTTP_DEST/event" 2>/dev/null || true
ln -sf "$EMHTTP_DEST/src/event" "$EMHTTP_DEST/event"

# Clean up the legacy dynamix hooks (wrong path — emhttpd never called them).
rm -f "/usr/local/emhttp/plugins/dynamix/events/stopping/aicli_sync" \
      "/usr/local/emhttp/plugins/dynamix/events/stopping_array/aicli_sync" \
      "/usr/local/emhttp/plugins/dynamix/events/disks_mounted/aicli_restore" 2>/dev/null || true

log_ok "Event hooks registered (stopping + stopping_array + disks_mounted)."

# --- Global Shell Integration ---
log_step "Applying global shell integration (aliases & PATH)..."
ln -sf "$EMHTTP_DEST/src/scripts/installer/shell-integration.sh" "/etc/profile.d/aicliagents.sh"
chmod 755 "$EMHTTP_DEST/src/scripts/installer/shell-integration.sh"
log_ok "Shell integration applied (/etc/profile.d/aicliagents.sh)."

# --- Manual Management Scripts ---
log_step "Deploying management scripts..."
if [ -f "$EMHTTP_DEST/src/scripts/user/repair-plugin.sh" ]; then
    chmod +x "$EMHTTP_DEST/src/scripts/user/repair-plugin.sh"
    ln -sf "$EMHTTP_DEST/src/scripts/user/repair-plugin.sh" "/usr/local/bin/aicli-repair"
    log_ok "aicli-repair command available."
fi
# AGENT_RUN_ENTRY_POINT.md R2: the wrapper that a script calls to start an agent run. It only calls
# `admin-agent.php run` with exec. The link points at the file, so a new generation needs no new link.
if [ -f "$EMHTTP_DEST/src/scripts/aicli-run" ]; then
    chmod +x "$EMHTTP_DEST/src/scripts/aicli-run"
    ln -sf "$EMHTTP_DEST/src/scripts/aicli-run" "/usr/local/bin/aicli-run"
    log_ok "aicli-run command available."
fi
if [ -f "$EMHTTP_DEST/src/scripts/aicli-run-report" ]; then
    chmod +x "$EMHTTP_DEST/src/scripts/aicli-run-report"
    ln -sf "$EMHTTP_DEST/src/scripts/aicli-run-report" "/usr/local/bin/aicli-run-report"
    log_ok "aicli-run-report command available."
fi

# --- PHP Post-Install Tasks ---
log_step "Initializing plugin services..."
# #337: each PHP step below runs with every inherited fd above 2 closed (the
# installer's UI pipe fd 4, the install lock fd 9). A daemon that PHP starts
# from here (the supervisor, a Relay listener) then cannot hold `plugin
# install`'s output open after this script exits.
AICLI_RUN_CLOSED=(bash /usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/aicli-detach.sh --run --)
# Follow-on #1: the plugin VERSION upgrade is the explicit format-migration
# trigger. The version-gated FileStorage::migrateFormat call lives in a SCRIPT
# FILE (not an inline php -r) so its namespaced facade calls aren't mangled by
# bash backslash handling (publish anti-pattern check). It MUST run BEFORE the
# version is saved below so it can read the OLD version. (Today migrateFormat is a
# no-op beyond the gate; the slow btrfs→squashfs conversion stays BACKGROUNDED —
# see D-308.)
"${AICLI_RUN_CLOSED[@]}" php /usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/installer/format-migrate.php "$VERSION" > /dev/null 2>&1

"${AICLI_RUN_CLOSED[@]}" php -r "
require_once '/usr/local/emhttp/plugins/unraid-aicliagents/src/includes/AICliAgentsManager.php';
aicli_migrate_home_path();
aicli_cleanup_legacy();
aicli_boot_resurrection();
saveAICliConfig(['version' => '$VERSION']);
" > /dev/null 2>&1

# #74: cleanup intentionally stops the old supervisor before replacing source.
# Do not report install success until the new daemon owns its pidfile and has a
# fresh heartbeat. A later WebUI request remains a self-heal backstop, not the
# primary restart mechanism for headless installs.
# Close installer lock fd 9 in the child. SupervisorService starts a daemon
# below PHP; without this redirection the daemon inherits the flock forever and
# every subsequent plugin update reports "Another install is running".
if ! "${AICLI_RUN_CLOSED[@]}" php /usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/installer/supervisor-ready.php > /dev/null 2>&1; then
    log_fail "Storage supervisor did not become ready after installation."
    exit 1
fi
log_ok "Services initialized. Plugin updated to v$VERSION."

# --- Agent Version Check Cron ---
log_step "Registering agent version check schedule..."
# #885: Unraid's update_cron reads /boot/config/plugins/<plugin>/*.cron. A file named like the
# plugin in /etc/cron.d is never read (that folder holds one crontab per Unix user), so the
# old files are removed and the lines go to *.cron files. Every line goes through cron-run.sh,
# which reports the job when the optional job_report_command setting names a reporter.
CRON_FILE="${PLUGIN_BASE}/agent-check.cron"
CRON_RUN="$EMHTTP_DEST/src/scripts/cron-run.sh"
# #925: seconds between two runs of a cron schedule, as "--interval=N " (empty when not simple).
# The same rule as JobRecordService::intervalFromCron: every N minutes, hourly, daily, weekly.
cron_interval_flag() {
    local m h dom mon dow extra n=""
    read -r m h dom mon dow extra <<< "$1"
    [ -n "$dow" ] && [ -z "$extra" ] && [ "$dom" = "*" ] && [ "$mon" = "*" ] || return 0
    if [[ "$m" =~ ^\*/([0-9]{1,2})$ ]] && [ "$h" = "*" ] && [ "$dow" = "*" ]; then
        n=$(( 10#${BASH_REMATCH[1]} * 60 ))
        { [ "$n" -ge 60 ] && [ "$n" -le 3540 ]; } || n=""
    elif [[ "$m" =~ ^[0-9]{1,2}$ ]] && [ "$((10#$m))" -le 59 ]; then
        if [ "$h" = "*" ] && [ "$dow" = "*" ]; then n=3600
        elif [[ "$h" =~ ^\*/([0-9]{1,2})$ ]] && [ "$dow" = "*" ]; then
            n=$(( 10#${BASH_REMATCH[1]} * 3600 ))
            { [ "$n" -ge 3600 ] && [ "$n" -le 82800 ]; } || n=""
        elif [[ "$h" =~ ^[0-9]{1,2}$ ]] && [ "$((10#$h))" -le 23 ]; then
            if [ "$dow" = "*" ]; then n=86400
            elif [[ "$dow" =~ ^[0-7]$ ]]; then n=604800; fi
        fi
    fi
    [ -n "$n" ] && printf -- '--interval=%s ' "$n"
    return 0
}
chmod 755 "$CRON_RUN" 2>/dev/null
rm -f /etc/cron.d/unraid-aicliagents.agent-check /etc/cron.d/unraid-aicliagents.health-check /etc/cron.d/unraid-aicliagents.backup-home
AGENT_CHECK_SCRIPT="$EMHTTP_DEST/src/scripts/agentcheck"
chmod 755 "$AGENT_CHECK_SCRIPT" 2>/dev/null
# Read schedule from config, default to daily at 6am
SCHEDULE=$(grep -oP 'version_check_schedule="\K[^"]+' "${PLUGIN_BASE}/unraid-aicliagents.cfg" 2>/dev/null || echo "0 6 * * *")
[ -z "$SCHEDULE" ] && SCHEDULE="0 6 * * *"
cat > "$CRON_FILE" <<CRON
# AICliAgents: Agent version check schedule
$SCHEDULE /bin/bash $CRON_RUN aicli-agent-check $(cron_interval_flag "$SCHEDULE")-- $AGENT_CHECK_SCRIPT &> /dev/null
CRON
/usr/local/sbin/update_cron 2>/dev/null || true
log_ok "Agent version check scheduled ($SCHEDULE)."

# --- Plugin Health Check Cron (R-09, Feature #1372) ---
log_step "Registering plugin health check schedule..."
HEALTH_CRON_FILE="${PLUGIN_BASE}/health-check.cron"
HEALTH_SCRIPT="$EMHTTP_DEST/src/scripts/healthcheck.php"
# Key absent -> default every 30 min; key present but EMPTY -> user disabled it
# (mirrors ConfigService::updateHealthCheckCron semantics).
if grep -q '^health_check_schedule=' "${PLUGIN_BASE}/unraid-aicliagents.cfg" 2>/dev/null; then
    HEALTH_SCHEDULE=$(grep -oP 'health_check_schedule="\K[^"]*' "${PLUGIN_BASE}/unraid-aicliagents.cfg" 2>/dev/null | head -n1)
else
    HEALTH_SCHEDULE="*/30 * * * *"
fi
if [ -n "$HEALTH_SCHEDULE" ]; then
    cat > "$HEALTH_CRON_FILE" <<CRON
# AICliAgents: plugin health check schedule
$HEALTH_SCHEDULE /bin/bash $CRON_RUN aicli-health-check --frequent $(cron_interval_flag "$HEALTH_SCHEDULE")-- /usr/bin/php $HEALTH_SCRIPT &> /dev/null
CRON
    log_ok "Plugin health check scheduled ($HEALTH_SCHEDULE)."
else
    rm -f "$HEALTH_CRON_FILE"
    log_ok "Plugin health check disabled by config."
fi
/usr/local/sbin/update_cron 2>/dev/null || true

# --- Home Backup Cron (HOME_BACKUP.md R1/R12) ---
# One cron.d file, one line per user with a home, mirroring the health-check
# cron above — but the schedule format (off|daily:HH:MM|weekly:D:HH:MM) and the
# per-user line count mean this is computed in PHP (BackupCronService), not
# grepped/templated here. Re-run on every install/upgrade so the cron always
# matches the saved cfg, even after a plugin update changes which users have a
# home.
log_step "Registering home backup schedule..."
"${AICLI_RUN_CLOSED[@]}" php /usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/installer/sync-backup-cron.php > /dev/null 2>&1
log_ok "Home backup schedule synced from config."

# --- Plain-folders offer (#496, CONVERT_LAYERED_TO_PLAIN_FOLDERS.md R13) ---
# One Unraid notification when a layered home sits on a disk that is not a USB
# stick. Read only; a marker on the flash stops repeats. Best effort: a failure
# here never fails the install.
"${AICLI_RUN_CLOSED[@]}" php /usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/convert-offer-notify.php > /dev/null 2>&1 || true
# #499: rebuild the storage notice in the Activity tray with the NEW code. The
# supervisor publishes only when the storage state changes, so an update left the
# old wording (and the old button) in the tray until then. Best effort.
"${AICLI_RUN_CLOSED[@]}" php /usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/supervisor/publish-storage-status.php > /dev/null 2>&1 || true

# Verify UI entry points (D-186: Ensure entry points exist for emhttp)
cd "$EMHTTP_DEST"
MISSING_ENTRY=0
for f in AICliAgents.page AICliAgentsManager.page AICliAjax.php AICliMenuIcon.page AICliNote.page AICliOpenFile.page AICliWiki.page ArrayStopWarning.page; do
    if [ ! -f "$f" ]; then
        cp -f "src/$f" "$f"
        MISSING_ENTRY=$((MISSING_ENTRY + 1))
    fi
done
# AICliRelayMcp.page was never a menu page (it has no page header). Unraid logged "Invalid .page format" for it on every
# page. It is now src/AICliRelayMcp.php, loaded by AICliAjax.php, so the old root copy must go.
rm -f AICliRelayMcp.page
[ "$MISSING_ENTRY" -gt 0 ] && log_status "  > Restored $MISSING_ENTRY missing UI entry point(s)."
cd - > /dev/null
