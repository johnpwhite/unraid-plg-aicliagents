<?php
/**
 * <module_context>
 *     <name>StorageTargetService</name>
 *     <description>
 *         S-11 (Feature #1355): the storage target picker's read-only enumeration
 *         engine. enumerateTargets(kind) discovers candidate persistence targets
 *         (appdata share pool, pools from disks.ini, /mnt/user, array disks, UD
 *         devices, network remotes, flash), probes each via FileStorage::probeTarget
 *         (S-01 capability probe — memoised per request) and returns a ranked list:
 *         appdata pool (ssd/nvme) > other posix pool > UD addons > UD disks >
 *         array direct disk > /mnt/user (FUSE warn) > flash > remotes (flagged).
 *         validateTarget(kind, path) is the shared per-kind policy verdict consumed
 *         by StorageHandler::preflightMigrate (refuse → error, warnings surfaced,
 *         exclusive-share /mnt/user paths resolved to the direct pool path).
 *     </description>
 *     <dependencies>FileStorage (probeTarget), StorageMountService (isPathAvailable)</dependencies>
 *     <constraints>READ-ONLY — never mutates config, mounts or files. Candidates
 *         capped at 12. Test-only env hooks: AICLI_DISKS_INI, AICLI_SHARES_INI,
 *         AICLI_MNT_ROOT, AICLI_ITEST_MOUNTED_PATHS (plus AICLI_STORAGECTL via
 *         FileStorage::probeTarget).</constraints>
 * </module_context>
 */

namespace AICliAgents\Services;

require_once __DIR__ . '/FileStorage.php';
require_once __DIR__ . '/StorageMountService.php';

class StorageTargetService {

    /** The default flash storage folder (the flash root under test is the sandbox). */
    public static function defaultFlashPath(): string { return SecretPaths::flashRoot() . '/persistence'; }
    const MAX_CANDIDATES = 12;

    /**
     * Enumerate ranked persistence target candidates for one storage kind.
     *
     * @param string     $kind   'home' | 'agent' — drives the S-02 network policy
     *                           (remotes refused for home; warn-gated for agents
     *                           behind storage_allow_remote_agent=1).
     * @param array|null $config plugin config (defaults to getAICliConfig()).
     * @return array<int,array<string,mixed>> candidates, sorted best-first. Each:
     *   {path, label, source, mount_class, engine, upper_mode, rotational,
     *    free_bytes, recommendation_rank, warnings[], refuse, current,
     *    recommended, advanced [, original_path, note, picked_via]}
     */
    public static function enumerateTargets(string $kind, ?array $config = null): array {
        $kind = ($kind === 'agent') ? 'agent' : 'home';
        if ($config === null) {
            $config = \function_exists('getAICliConfig') ? getAICliConfig() : [];
        }
        $mnt     = rtrim(getenv('AICLI_MNT_ROOT') ?: '/mnt', '/');
        $current = (string)($config[$kind . '_storage_path'] ?? self::defaultFlashPath());

        $cands   = [];
        $pools   = self::poolNames();
        $appPool = self::appdataPrimaryPool();

        // 1. The appdata share's primary pool — the recommended default location.
        if ($appPool !== null && in_array($appPool, $pools, true) && is_dir("$mnt/$appPool")) {
            $cands[] = self::candidate("$mnt/$appPool/appdata/aicliagents",
                "Appdata share pool: $appPool", 'appdata_pool', $kind, $config, $current);
        }
        // 2. Every pool from disks.ini (type="Cache" sections, trailing digits stripped).
        foreach ($pools as $pool) {
            if (!is_dir("$mnt/$pool")) continue;
            $cands[] = self::candidate("$mnt/$pool/aicliagents", "Pool: $pool", 'pool', $kind, $config, $current);
        }
        // 3. User shares (FUSE — probe warns user_share) when shfs is up.
        if (is_dir("$mnt/user") && self::mounted("$mnt/user")) {
            $cands[] = self::candidate("$mnt/user/appdata/aicliagents", 'User shares (/mnt/user)', 'user_share', $kind, $config, $current);
        }
        // 4. UD devices — /mnt/addons (UD-blessed plugin paths) before /mnt/disks.
        foreach (['addons' => 'ud_addons', 'disks' => 'ud_disk'] as $dir => $src) {
            foreach (self::subdirs("$mnt/$dir") as $d) {
                if (!self::mounted($d)) continue;
                // #465: offer a folder INSIDE the device (the same shape as the appdata
                // candidate). The device top folder is refused by validatePersistPath.
                $cands[] = self::candidate("$d/aicliagents", 'UD device: ' . basename($d), $src, $kind, $config, $current);
            }
        }
        // 5. Array direct disks — advanced only (bypasses FUSE, pins one spindle).
        foreach (self::subdirs($mnt) as $d) {
            if (!preg_match('/^disk\d+$/D', basename($d))) continue;
            if (!self::mounted($d)) continue;
            $cands[] = self::candidate("$d/aicliagents", 'Array disk: ' . basename($d), 'array_disk', $kind, $config, $current, true);
        }
        // 6. Network remotes — discover from /proc mount metadata and NEVER
        // touch the mounted filesystem here. A dead hard NFS/CIFS mount can put
        // glob/stat/findmnt --target/statfs in uninterruptible sleep, taking the
        // entire plugin page's debug request down with it (issue #39).
        $remoteMounts = self::remoteMountpoints("$mnt/remotes");
        foreach ($remoteMounts as $d) {
            $cands[] = self::remoteCandidate($d, 'Network share: ' . basename($d),
                $kind, $config, $current);
        }
        // 7. Flash — always present, always offered last among usable targets.
        $flashPath = (strpos($current, '/boot') === 0) ? $current : self::defaultFlashPath();
        $flash = self::candidate($flashPath, '', 'flash', $kind, $config, $current);
        $flash['label'] = ($flash['mount_class'] === 'boot_internal')
            ? 'Internal boot (durable)'
            : 'USB flash (fallback — wear-limited)';
        $cands[] = $flash;

        // Current path not among the candidates (custom location) → surface it.
        $havePaths = array_column($cands, 'path');
        if (!in_array($current, $havePaths, true)) {
            $remoteRoot = self::containingMountpoint($current, $remoteMounts);
            $cands[] = $remoteRoot !== null
                ? self::remoteCandidate($current, 'Current location', $kind, $config, $current, 'current')
                : self::candidate($current, 'Current location', 'current', $kind, $config, $current);
        }

        // Dedupe by path (first wins — list is built best-source-first), merging
        // the current marker and any exclusive-share resolution info from the
        // dropped duplicate (e.g. a /mnt/user current path that resolved onto
        // the appdata candidate).
        $seen = []; $unique = [];
        foreach ($cands as $c) {
            if (isset($seen[$c['path']])) {
                $i = $seen[$c['path']];
                if ($c['current']) $unique[$i]['current'] = true;
                foreach (['original_path', 'note', 'picked_via'] as $k) {
                    if (isset($c[$k]) && !isset($unique[$i][$k])) $unique[$i][$k] = $c[$k];
                }
                continue;
            }
            $seen[$c['path']] = count($unique);
            $unique[] = $c;
        }

        usort($unique, static function ($a, $b) {
            if ($a['recommendation_rank'] !== $b['recommendation_rank']) {
                return $a['recommendation_rank'] <=> $b['recommendation_rank'];
            }
            if ($a['free_bytes'] !== $b['free_bytes']) {
                return $b['free_bytes'] <=> $a['free_bytes'];
            }
            return strcmp($a['path'], $b['path']);
        });

        // Cap at MAX_CANDIDATES, never dropping the flash fallback or the current path.
        if (count($unique) > self::MAX_CANDIDATES) {
            $keep = []; $rest = [];
            foreach ($unique as $c) {
                if ($c['source'] === 'flash' || $c['current']) { $keep[] = $c; } else { $rest[] = $c; }
            }
            $unique = array_merge(array_slice($rest, 0, self::MAX_CANDIDATES - count($keep)), $keep);
            usort($unique, static fn($a, $b) => $a['recommendation_rank'] <=> $b['recommendation_rank']);
        }

        // Mark the single recommended candidate: best-ranked non-refused entry.
        foreach ($unique as $i => $c) {
            if (!$c['refuse']) { $unique[$i]['recommended'] = true; break; }
        }
        return $unique;
    }

    /**
     * Bug #1380: the QUALIFYING targets for a "move off USB flash drive"
     * graduation — the user-intent relocation policy (criterion b). Filters
     * enumerateTargets() to durable, NON-array, NON-flash, passthrough-capable,
     * NON-refused candidates the data can be moved TO. Reused by BOTH the gate
     * (FileStorage::canGraduate → StorageMetricsService `can_graduate`) and the
     * relocation action (the graduate-targets AJAX surface) so they can never
     * diverge. A target qualifies IFF:
     *   - engine      == passthrough  (a durable plain-directory target — the
     *                                  whole point of moving off the stick)
     *   - durability  == durable      (never volatile/network)
     *   - !refuse                     (the probe did not reject it)
     *   - mount_class NOT IN {array, boot_usb, boot_internal, remote, tmpfs,
     *                         user_share}  (non-array AND non-flash; the FUSE
     *                                       user_share and array spindle are
     *                                       excluded as relocation destinations)
     *   - not the entity's CURRENT flash location (can't move onto itself)
     *
     * @param string     $kind   'home' | 'agent'
     * @param array|null $config plugin config (defaults to getAICliConfig()).
     * @return array<int,array<string,mixed>> qualifying candidates, best-first.
     */
    public static function qualifyingGraduateTargets(string $kind, ?array $config = null): array {
        $kind = ($kind === 'agent') ? 'agent' : 'home';
        $all  = self::enumerateTargets($kind, $config);
        $excludedClasses = ['array', 'boot_usb', 'boot_internal', 'remote', 'tmpfs', 'user_share'];
        $out = [];
        foreach ($all as $t) {
            if (!empty($t['refuse'])) continue;
            if (!empty($t['current'])) continue;                 // can't move onto itself
            if (($t['engine'] ?? '') !== 'passthrough') continue; // durable plain-dir only
            if (($t['durability'] ?? 'durable') !== 'durable') continue;
            $mc = (string)($t['mount_class'] ?? '');
            // pool:<name> classes are durable non-flash non-array — keep them.
            if (in_array($mc, $excludedClasses, true)) continue;
            $out[] = $t;
        }
        return $out;
    }

    /**
     * HOME_BACKUP.md R2: resolve and validate a home-backup TARGET path — the
     * directory the snapshot tree is rsynced into. Never a `/mnt/user` FUSE
     * path (a home has tens of thousands of small files; rsync over shfs can
     * freeze the host), never inside a home mount or the plugin's own
     * persistence directory, and it must be writable.
     *
     * A `/mnt/user/<share>` path is first resolved onto its pool/disk path via
     * the SAME probe the target picker uses (validateTarget's realpath
     * resolution) — a share that cannot be resolved to a single backing path
     * stays FUSE and is refused.
     *
     * Test hook: AICLI_ITEST_FSTYPE_MAP="/path:fstype,/path2:fstype2" overrides
     * the findmnt fstype lookup (mirrors the AICLI_ITEST_MOUNTED_PATHS pattern
     * used elsewhere in this class) so PHPUnit can simulate a FUSE mount
     * without a real shfs.
     *
     * @return array{ok:bool, resolved:string, fs:string, free_bytes:int, message:string}
     */
    public static function resolveBackupTarget(string $path, ?array $config = null): array {
        $path = rtrim(trim($path), '/');
        if ($path === '' || $path[0] !== '/') {
            return self::backupTargetResult(false, $path, '', 0, 'The backup target must be an absolute path.');
        }
        if ($config === null) {
            $config = \function_exists('getAICliConfig') ? getAICliConfig() : [];
        }

        // Resolve an exclusive /mnt/user share path onto its pool/disk path —
        // never rsync a home across the FUSE share.
        $resolved = $path;
        if (preg_match('#^/mnt/user0?(/.*)?$#D', $path)) {
            $verdict = self::validateTarget('home', $path, $config);
            if (!empty($verdict['resolved_path'])) {
                $resolved = (string)$verdict['resolved_path'];
            }
        }

        // #749: a network place must be mounted and must take a small write. Ask first,
        // before any other call that touches the folder (a dead share can block it).
        $networkReason = self::networkPlaceReason($resolved, 'backup');
        if ($networkReason !== null) {
            return self::backupTargetResult(false, $resolved, '', 0, $networkReason);
        }

        $fstype = self::findmntFstype($resolved);
        if ($fstype !== '' && (strcasecmp($fstype, 'fuse.shfs') === 0 || stripos($fstype, 'fuse') === 0)) {
            return self::backupTargetResult(false, $resolved, $fstype, 0,
                "Target '$resolved' is a FUSE share mount — pick the pool or disk path directly, not a /mnt/user share.");
        }

        require_once __DIR__ . '/StoragePathResolver.php';
        $workRoot = StoragePathResolver::mountRoot() . '/work';
        if (self::isUnderPath($resolved, $workRoot)) {
            return self::backupTargetResult(false, $resolved, $fstype, 0,
                'The backup target cannot be inside a home mount.');
        }
        $persist = StoragePathResolver::homePersistPath('');
        if ($persist !== '' && self::isUnderPath($resolved, $persist)) {
            return self::backupTargetResult(false, $resolved, $fstype, 0,
                'The backup target cannot be inside the plugin persistence directory.');
        }

        // #653: a backup must survive a reboot and must be able to hold a "latest"
        // link. Fold "." and ".." out of the path first (so /mnt/cache/../../tmp/x is
        // seen as /tmp/x), follow links on the part that exists, then refuse RAM
        // (tmpfs, ramfs, rootfs), the flash drive (/boot, vfat) and the RAM folders.
        $resolved = self::collapseDots($resolved);
        [$anc, $suffix] = self::existingAncestor($resolved);
        $realAnc = ($anc !== '' && file_exists($anc)) ? realpath($anc) : false;
        $real = ($realAnc !== false ? rtrim($realAnc, '/') : $anc) . $suffix;
        foreach ([$resolved, $real] as $candidate) {
            if (self::isUnderPath($candidate, '/boot') || self::isUnderPath($candidate, '/dev/shm')) {
                return self::backupTargetResult(false, $resolved, $fstype, 0,
                    "Target '$resolved' is on the flash drive or in RAM. A backup there is lost or cannot be linked. Pick a pool or disk path.");
            }
        }
        $realFs = self::findmntFstype($real);
        if ($realFs !== '') $fstype = $realFs;
        if (in_array(strtolower($fstype), ['tmpfs', 'ramfs', 'rootfs', 'vfat', 'exfat', 'msdos'], true)) {
            return self::backupTargetResult(false, $resolved, $fstype, 0,
                "Target '$resolved' is on a $fstype filesystem (RAM or flash). A backup there is lost at reboot or cannot be linked. Pick a pool or disk path.");
        }
        if ($fstype === '') {
            foreach (['/tmp', '/root', '/var'] as $volatileRoot) {
                if (self::isUnderPath($real, $volatileRoot)) {
                    return self::backupTargetResult(false, $resolved, $fstype, 0,
                        "Target '$resolved' is in a RAM folder. A backup there is lost at reboot. Pick a pool or disk path.");
                }
            }
        }

        $writableCheck = is_dir($resolved) ? $resolved : self::existingAncestor($resolved)[0];
        if ($writableCheck === '' || !is_dir($writableCheck) || !is_writable($writableCheck)) {
            return self::backupTargetResult(false, $resolved, $fstype, 0,
                "Target '$resolved' is not writable.");
        }

        return self::backupTargetResult(true, $resolved, $fstype, self::freeBytes($resolved), '');
    }

    /**
     * #749: is a backup place on a network share ready? Runs
     * src/scripts/storage/remote_target.sh (the same checks the backup job runs).
     * A local place passes. For a network place the share must be mounted and
     * must answer: 'backup' makes a small write test, 'restore' only reads.
     * The child has a time limit; a share that does not answer is not ready.
     * AICLI_PROC_MOUNTS and AICLI_REMOTES_ROOT (test seams) reach the child.
     *
     * @return string|null one plain sentence when the place is not ready, else null
     */
    public static function networkPlaceReason(string $path, string $mode = 'backup'): ?string {
        $script = dirname(__DIR__, 2) . '/scripts/storage/remote_target.sh';
        if (!is_file($script)) {
            return preg_match('#^/mnt/remotes/#', $path)
                ? "The backup place $path is on a network share, and the plugin cannot check the share."
                : null;
        }
        $mode = ($mode === 'restore') ? 'restore' : 'backup';
        $proc = @proc_open( // nosemgrep: php.lang.security.tainted-exec.tainted-exec — array-form proc_open, no shell interpolation
            ['bash', $script, 'check', $path, $mode],
            [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes
        );
        if (!is_resource($proc)) return null;
        fclose($pipes[0]);
        stream_set_blocking($pipes[1], false);
        $out = '';
        $deadline = microtime(true) + 40.0;
        $code = -1;
        while (true) {
            $out .= (string)stream_get_contents($pipes[1]);
            $st = proc_get_status($proc);
            if (!$st['running']) { $code = (int)$st['exitcode']; break; }
            if (microtime(true) > $deadline) {
                // Do not wait for a blocked child.
                proc_terminate($proc, 9);
                fclose($pipes[1]); fclose($pipes[2]);
                return "The backup place $path is on a network share that does not answer. Check that the share is online, then try again.";
            }
            usleep(50000);
        }
        $out .= (string)stream_get_contents($pipes[1]);
        fclose($pipes[1]); fclose($pipes[2]);
        proc_close($proc);
        if ($code === 0) return null;
        $out = trim($out);
        return $out !== '' ? $out : "The backup place $path is not ready.";
    }

    /** @return array{ok:bool, resolved:string, fs:string, free_bytes:int, message:string} */
    private static function backupTargetResult(bool $ok, string $resolved, string $fs, int $freeBytes, string $message): array {
        return ['ok' => $ok, 'resolved' => $resolved, 'fs' => $fs, 'free_bytes' => $freeBytes, 'message' => $message];
    }

    /** #653: fold "." and ".." segments out of an absolute path without touching the disk. */
    private static function collapseDots(string $path): string {
        $out = [];
        foreach (explode('/', $path) as $seg) {
            if ($seg === '' || $seg === '.') continue;
            if ($seg === '..') { array_pop($out); continue; }
            $out[] = $seg;
        }
        return '/' . implode('/', $out);
    }

    /** $path === $root or a path strictly below it (both compared literally, no realpath). */
    private static function isUnderPath(string $path, string $root): bool {
        $root = rtrim($root, '/');
        return $root !== '' && ($path === $root || strncmp($path, $root . '/', strlen($root) + 1) === 0);
    }

    /**
     * The filesystem type at the deepest existing ancestor of $path, via
     * `findmnt -T`. AICLI_ITEST_FSTYPE_MAP is a test-only override: a
     * comma-separated list of "<path-or-ancestor>:<fstype>" pairs, first match
     * (by exact path or the path being under it) wins.
     */
    /**
     * The filesystem type at $path (or its deepest existing ancestor), '' when
     * unknown. Public for the folder browser's "New folder" action (HOME_BACKUP.md
     * 2026-09-24 follow-up), which refuses a FUSE parent the same way
     * resolveBackupTarget() refuses a FUSE target.
     */
    public static function fstypeAt(string $path): string {
        return self::findmntFstype($path);
    }

    private static function findmntFstype(string $path): string {
        $hook = getenv('AICLI_ITEST_FSTYPE_MAP');
        if ($hook !== false) {
            foreach (array_filter(explode(',', $hook)) as $pair) {
                $parts = explode(':', $pair, 2);
                $p = $parts[0] ?? '';
                $fs = $parts[1] ?? '';
                if ($p !== '' && ($path === $p || self::isUnderPath($path, $p))) {
                    return $fs;
                }
            }
            return '';
        }
        [$probePath] = self::existingAncestor($path);
        if ($probePath === '') return '';
        $proc = @proc_open( // nosemgrep: php.lang.security.tainted-exec.tainted-exec — array-form proc_open, no shell interpolation
            ['findmnt', '-T', $probePath, '-no', 'FSTYPE'],
            [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes
        );
        if (!is_resource($proc)) return '';
        $out = trim((string)stream_get_contents($pipes[1]));
        fclose($pipes[1]); fclose($pipes[2]); proc_close($proc);
        return $out;
    }

    /**
     * Shared per-kind target validation — the preflight_migrate policy seam
     * (S-06/S-11). Routes through FileStorage::probeTarget; falls back to the
     * legacy #341 findmnt fstype check when the probe itself is unavailable.
     *
     * @return array{ok:bool, message:string, warnings:array<int,string>, resolved_path:?string}
     */
    public static function validateTarget(string $kind, string $path, array $config): array {
        $kind = ($kind === 'agent') ? 'agent' : 'home';
        // #563: refuse a NEW save of a bare root (/mnt/<pool>, /mnt/user,
        // /mnt/diskN, a UD device top folder). Callers run this only for a path that
        // differs from the saved one, so an old saved value still loads. Network
        // paths keep their own per-kind policy below.
        if (strncmp($path, '/mnt/remotes', 12) !== 0) {
            require_once __DIR__ . '/StoragePathResolver.php';
            $shape = StoragePathResolver::validatePersistPath($path, $kind);
            if (empty($shape['ok'])) {
                return ['ok' => false, 'warnings' => ['invalid_persist_path'], 'resolved_path' => null,
                    'message' => "Persistence path '$path' is not allowed: " . (string)($shape['reason'] ?? 'invalid path')];
            }
        }
        // Issue #56: /mnt/user may exist as an ordinary rootfs stub before
        // shfs is mounted. Never probe or approve a future mkdir beneath it.
        if (!StorageMountService::isBackingMountAvailable($path)) {
            return ['ok' => false, 'warnings' => ['storage_unmounted'], 'resolved_path' => null,
                'message' => "Persistence path '$path' is unavailable because its backing storage is not mounted."];
        }
        // Probe the deepest existing ancestor — a not-yet-created subdirectory
        // of a valid mount is a valid target (execute_migrate mkdir -p's it).
        [$probePath, $suffix] = self::existingAncestor($path);
        $probe = FileStorage::probeTarget($probePath);
        if (in_array('probe_failed', (array)($probe['reasons'] ?? []), true)) {
            return self::legacyFstypeVerdict($path);
        }
        $warnings = array_values((array)($probe['warnings'] ?? []));
        if (!empty($probe['refuse'])) {
            return ['ok' => false, 'warnings' => $warnings, 'resolved_path' => null,
                'message' => "Persistence path '$path' is refused ("
                    . ($probe['fstype'] !== '' ? $probe['fstype'] . ', ' : '')
                    . $probe['mount_class'] . '): ' . implode(', ', $warnings ?: (array)$probe['reasons'])
                    . '. Choose a durable local path (pool, UD device, or flash).'];
        }
        if (($probe['mount_class'] ?? '') === 'remote' || ($probe['durability'] ?? '') === 'network') {
            if ($kind === 'home') {
                return ['ok' => false, 'warnings' => $warnings, 'resolved_path' => null,
                    'message' => "Persistence path '$path' is a network share — home storage must be on durable local storage (rejected_for_home)."];
            }
            if ((string)($config['storage_allow_remote_agent'] ?? '0') !== '1') {
                return ['ok' => false, 'warnings' => $warnings, 'resolved_path' => null,
                    'message' => "Persistence path '$path' is a network share. Remote agent storage requires storage_allow_remote_agent=\"1\" (not recommended)."];
            }
            $warnings[] = 'remote_agent_warn';
        }
        $resolved = null;
        if (!empty($probe['via_user_share'])
            && is_string($probe['realpath'] ?? null) && $probe['realpath'] !== ''
            && $probe['realpath'] . $suffix !== $path) {
            $resolved = $probe['realpath'] . $suffix;
        } elseif (($probe['mount_class'] ?? '') === 'user_share') {
            // 2026-09-23 (Bug #297): same fallback as candidate() above — a
            // share the live probe left on /mnt/user (still FUSE) may still
            // record, in its OWN config, that every file lives on one pool
            // (useCache="only"). Never a guess: resolveViaShareConfig() reads
            // that field from the SAME live per-share status source this
            // class already trusts for the appdata-pool recommendation
            // (appdataPrimaryPool(), shares.ini — emhttpd's generated mirror
            // of each share's /boot/config/shares/<share>.cfg) and fails
            // closed to null the moment the share spans disks, has no
            // section, or the resolved pool directory doesn't exist. This is
            // what executeMigrate() relies on to never write a live
            // /mnt/user (shfs) path as a migration destination when the
            // config can prove a single-pool path is equally correct.
            $viaCfg = self::resolveViaShareConfig($probePath, $suffix, $path);
            if ($viaCfg !== null) {
                $resolved = $viaCfg;
                $warnings[] = 'resolved_via_share_config';
            }
        }
        return ['ok' => true, 'message' => '', 'warnings' => array_values(array_unique($warnings)),
                'resolved_path' => $resolved];
    }

    /**
     * 2026-09-23 (Bug #297): resolve a /mnt/user0?/<share>(/rest) path whose
     * live probe did NOT already resolve it (the OS-level exclusive-share
     * bypass didn't fire — it is genuinely still FUSE) by reading the
     * NAMED share's own cache-mode fields from shares.ini — the same file
     * and the same useCache/cachePool keys appdataPrimaryPool() already
     * reads for the appdata share, generalised to any share name. Resolves
     * ONLY when useCache="only" (every file on one named pool) AND the
     * resolved pool directory actually exists; any other case (share spans
     * disks, "yes"/"prefer" caching, no shares.ini section, missing pool
     * dir) returns null — the raw /mnt/user path is kept, never rewritten
     * on a guess. Honours the same AICLI_SHARES_INI / AICLI_MNT_ROOT test
     * hooks as the rest of this class.
     *
     * $probePath/$suffix come from the SAME existingAncestor() split the
     * caller already computed (mirrors the realpath-resolution arm above),
     * so a not-yet-created destination subdirectory resolves exactly like
     * one that already exists; $path is the original full path, only used
     * to detect a no-op resolution.
     *
     * @return string|null the resolved pool path (+ suffix), or null when
     *   no safe resolution is possible.
     */
    private static function resolveViaShareConfig(string $probePath, string $suffix, string $path): ?string {
        $mnt = rtrim(getenv('AICLI_MNT_ROOT') ?: '/mnt', '/');
        $quoted = preg_quote($mnt, '#');
        if (!preg_match('#^' . $quoted . '/user0?/([^/]+)(/.*)?$#', $probePath, $m)) return null;
        $share = $m[1];
        $rest = ($m[2] ?? '') . $suffix;
        $cfg = self::shareCacheConfig($share);
        if ($cfg === null || $cfg['useCache'] !== 'only') return null;
        $pool = $cfg['cachePool'] !== '' ? $cfg['cachePool'] : 'cache';
        if (!preg_match('/^[A-Za-z0-9_.-]+$/D', $pool)) return null;
        $target = "$mnt/$pool/$share";
        if (!is_dir($target)) return null;
        $resolved = $target . $rest;
        return ($resolved !== $path) ? $resolved : null;
    }

    /**
     * The named share's `useCache` / `cachePool` fields from shares.ini
     * (generalises appdataPrimaryPool()'s section parser to an arbitrary
     * share name). @return array{useCache:string,cachePool:string}|null
     * null when the share has no section in the file.
     */
    private static function shareCacheConfig(string $share): ?array {
        $ini = getenv('AICLI_SHARES_INI') ?: '/var/local/emhttp/shares.ini';
        if (!is_file($ini)) return null;
        $in = false; $useCache = ''; $cachePool = ''; $found = false;
        foreach ((array)@file($ini, FILE_IGNORE_NEW_LINES) as $line) {
            if ($line !== '' && $line[0] === '[') {
                if ($in) break; // left the target share's section
                $in = (str_replace(['[', ']', '"'], '', $line) === $share);
                if ($in) $found = true;
                continue;
            }
            if (!$in) continue;
            if (strpos($line, 'useCache=') === 0)  $useCache  = trim(substr($line, 9), '"');
            if (strpos($line, 'cachePool=') === 0) $cachePool = trim(substr($line, 10), '"');
        }
        if (!$found) return null;
        return ['useCache' => $useCache, 'cachePool' => $cachePool];
    }

    // -------------------------------------------------------------------------
    // internals
    // -------------------------------------------------------------------------

    /** Build one probed candidate entry (see enumerateTargets shape). */
    private static function candidate(string $path, string $label, string $source,
                                      string $kind, array $config, string $current,
                                      bool $advanced = false): array {
        // Probe the deepest EXISTING ancestor: the recommended targets (e.g.
        // /mnt/<pool>/appdata/aicliagents) usually don't exist yet, and findmnt
        // can't classify a non-existent path — the filesystem verdict is
        // mount-level, so the ancestor's probe is the target's probe.
        [$probePath, $suffix] = self::existingAncestor($path);
        $probe    = FileStorage::probeTarget($probePath);
        $warnings = array_values((array)($probe['warnings'] ?? []));
        $refuse   = !empty($probe['refuse']);
        $original = null; $note = null;

        // Exclusive-share resolution: surface the realpath as the actionable
        // value (this is what gets STORED); keep the picked /mnt/user path as info.
        if (!empty($probe['via_user_share'])
            && is_string($probe['realpath'] ?? null) && $probe['realpath'] !== ''
            && $probe['realpath'] . $suffix !== $path) {
            $original = $path;
            $path = $probe['realpath'] . $suffix;
            $note = "Resolves to $path (exclusive share) — the direct pool path is stored.";
        } elseif (($probe['mount_class'] ?? '') === 'user_share') {
            // 2026-09-23 (Bug #297): the live probe did NOT resolve this path
            // off /mnt/user (it is genuinely still FUSE-backed). Ask the
            // share's OWN config whether it keeps every file on one pool
            // anyway. See the matching block in validateTarget() below for
            // the full rationale — kept in sync deliberately.
            $viaCfg = self::resolveViaShareConfig($probePath, $suffix, $path);
            if ($viaCfg !== null) {
                $original = $path;
                $path = $viaCfg;
                $note = "This share keeps all its files on one pool (useCache=\"only\") — resolves to $path.";
                $warnings[] = 'resolved_via_share_config';
            }
        }

        // S-02 per-kind network policy (the probe has no kind axis — applied here).
        if (($probe['mount_class'] ?? '') === 'remote' || ($probe['durability'] ?? '') === 'network') {
            if ($kind === 'home') {
                $refuse = true;
                $warnings[] = 'rejected_for_home';
            } else {
                $warnings[] = 'remote_agent_warn';
                if ((string)($config['storage_allow_remote_agent'] ?? '0') !== '1') $refuse = true;
            }
        }

        $entry = [
            'path'        => $path,
            'label'       => $label,
            'source'      => $source,
            'mount_class' => (string)($probe['mount_class'] ?? 'other'),
            'engine'      => (string)($probe['engine'] ?? 'layering'),
            'upper_mode'  => (string)($probe['upper_mode'] ?? 'zram'),
            // Bug #1380: surface the probe durability axis so the graduate gate
            // (qualifyingGraduateTargets) can require durable, non-network targets.
            'durability'  => (string)($probe['durability'] ?? 'durable'),
            'rotational'  => !empty($probe['rotational']),
            'free_bytes'  => self::freeBytes($path),
            'warnings'    => array_values(array_unique($warnings)),
            'refuse'      => $refuse,
            'current'     => ($path === $current || $original === $current),
            'recommended' => false,
            'advanced'    => $advanced,
        ];
        if ($original !== null) {
            $entry['original_path'] = $original;
            $entry['note']          = $note;
            $entry['picked_via']    = $original;
        }
        $entry['recommendation_rank'] = self::rank($source, $probe, $refuse, $entry['mount_class']);
        return $entry;
    }

    /**
     * Build a network candidate using mount-table facts only. This is not a
     * reduced timeout probe: hard network mounts can remain in D-state after a
     * timeout and leak an unkillable helper. Mandatory page-load code therefore
     * performs zero filesystem operations below a remote mountpoint.
     */
    private static function remoteCandidate(string $path, string $label, string $kind,
                                            array $config, string $current,
                                            string $source = 'remote'): array {
        $warnings = ['network_target', 'remote_probe_skipped'];
        $refuse = true;
        if ($kind === 'home') {
            $warnings[] = 'rejected_for_home';
        } else {
            $warnings[] = 'remote_agent_warn';
            $refuse = (string)($config['storage_allow_remote_agent'] ?? '0') !== '1';
        }
        $entry = [
            'path' => $path,
            'label' => $label,
            'source' => $source,
            'mount_class' => 'remote',
            'engine' => 'layering',
            'upper_mode' => 'zram',
            'durability' => 'network',
            'rotational' => false,
            'free_bytes' => 0,
            'warnings' => $warnings,
            'refuse' => $refuse,
            'current' => ($path === $current),
            'recommended' => false,
            'advanced' => false,
            'probe_status' => 'metadata_only',
        ];
        $entry['recommendation_rank'] = self::rank($source, [], $refuse, 'remote');
        return $entry;
    }

    /**
     * Ranking policy (see docs/specs/STORAGE_TARGET_PICKER.md):
     *   1 appdata pool (non-rotational posix) · 2 other posix pool / rotational
     *   appdata pool · 3 UD addons · 4 UD disks · 5 array direct disk ·
     *   6 /mnt/user · 7 flash · 8 remote · 9 other · 99 refused.
     * Non-posix pool/UD targets are demoted by +4 (below /mnt/user).
     */
    private static function rank(string $source, array $probe, bool $refuse, string $mountClass): int {
        if ($refuse) return 99;
        $posixFull = (($probe['posix'] ?? '') === 'posix_full');
        switch ($source) {
            case 'appdata_pool':
                if (!$posixFull) return 6;
                return !empty($probe['rotational']) ? 2 : 1;
            case 'pool':       $r = 2; break;
            case 'ud_addons':  $r = 3; break;
            case 'ud_disk':    $r = 4; break;
            case 'array_disk': return 5;
            case 'user_share': return 6;
            case 'flash':      return 7;
            case 'remote':     return 8;
            case 'current':    return self::rankFromClass($mountClass);
            default:           return 9;
        }
        return $posixFull ? $r : $r + 4;
    }

    /** Rank a custom 'current' candidate by its probed mount class. */
    private static function rankFromClass(string $class): int {
        if (strpos($class, 'pool:') === 0) return 2;
        switch ($class) {
            case 'ud_addons':     return 3;
            case 'ud_disk':       return 4;
            case 'array':         return 5;
            case 'user_share':    return 6;
            case 'boot_usb':
            case 'boot_internal': return 7;
            case 'remote':        return 8;
            default:              return 9;
        }
    }

    /**
     * Pool names from disks.ini — the PHP port of the proven classify-path.sh /
     * detect_backend.sh awk: sections are ["cache"] / ["cache2"], a pool member
     * has type="Cache", and a further member (cache2) joins the pool of the section
     * it extends (R-124, #662: only the disk-number suffix is stripped, so a pool
     * called pool1 stays pool1). AICLI_DISKS_INI overrides the path (same hook as the bash side).
     * @return array<int,string> sorted unique pool names
     */
    public static function poolNames(): array {
        $ini = getenv('AICLI_DISKS_INI') ?: '/var/local/emhttp/disks.ini';
        if (!is_file($ini)) return [];
        $cacheSections = []; $section = '';
        foreach ((array)@file($ini, FILE_IGNORE_NEW_LINES) as $line) {
            if ($line !== '' && $line[0] === '[') {
                $section = str_replace(['[', ']', '"'], '', $line);
                continue;
            }
            if (strpos($line, 'type=') === 0 && trim(substr($line, 5)) === '"Cache"') {
                if ($section !== '') $cacheSections[] = $section;
            }
        }
        return self::poolNamesFromSections($cacheSections);
    }

    /**
     * R-124 (#662): the pool names of a list of type="Cache" section names. A section is a
     * further member of a pool (cache2 of cache) only when the same name without its trailing
     * digit(s) is also a Cache section. A pool whose own name ends in a digit (pool1) stays a pool.
     * The same rule is in classify-path.sh and detect_backend.sh. Pure.
     * @param array<int,string> $cacheSections
     * @return array<int,string> sorted unique pool names
     */
    public static function poolNamesFromSections(array $cacheSections): array {
        $known = array_flip($cacheSections);
        $pools = [];
        foreach ($cacheSections as $s) {
            $member = false;
            $t = $s;
            while ($t !== '' && ctype_digit(substr($t, -1))) {
                $t = substr($t, 0, -1);
                if ($t !== '' && isset($known[$t])) { $member = true; break; }
            }
            if (!$member) $pools[$s] = true;
        }
        $names = array_map('strval', array_keys($pools));
        sort($names);
        return $names;
    }

    /**
     * The appdata share's primary pool from shares.ini (["appdata"] section,
     * cachePool key; Unraid's default pool name 'cache' when the key is empty
     * but the share exists with a cache mode). null when no appdata share or
     * it does not use a pool (useCache="no"). AICLI_SHARES_INI overrides.
     */
    public static function appdataPrimaryPool(): ?string {
        $ini = getenv('AICLI_SHARES_INI') ?: '/var/local/emhttp/shares.ini';
        if (!is_file($ini)) return null;
        $in = false; $useCache = ''; $cachePool = ''; $found = false;
        foreach ((array)@file($ini, FILE_IGNORE_NEW_LINES) as $line) {
            if ($line !== '' && $line[0] === '[') {
                if ($in) break; // left the appdata section
                $in = (str_replace(['[', ']', '"'], '', $line) === 'appdata');
                if ($in) $found = true;
                continue;
            }
            if (!$in) continue;
            if (strpos($line, 'useCache=') === 0)  $useCache  = trim(substr($line, 9), '"');
            if (strpos($line, 'cachePool=') === 0) $cachePool = trim(substr($line, 10), '"');
        }
        if (!$found || $useCache === 'no') return null;
        return $cachePool !== '' ? $cachePool : 'cache';
    }

    /**
     * Split $path into [deepest existing ancestor, '/remaining/suffix'].
     * ['', $path] never happens — the walk stops at '/'. The probe targets the
     * ancestor (findmnt can't classify non-existent paths); the suffix is
     * re-appended after any exclusive-share realpath resolution.
     * @return array{0:string,1:string}
     */
    private static function existingAncestor(string $path): array {
        $p = $path; $suffix = '';
        while ($p !== '' && $p !== '/' && !file_exists($p)) {
            $parent = dirname($p);
            if ($parent === $p) break;
            $suffix = '/' . basename($p) . $suffix;
            $p = $parent;
        }
        return [$p, $suffix];
    }

    /** Immediate subdirectories of $dir (sorted), [] when absent. */
    private static function subdirs(string $dir): array {
        $out = glob(rtrim($dir, '/') . '/*', GLOB_ONLYDIR);
        if (!is_array($out)) return [];
        sort($out);
        return $out;
    }

    /**
     * Mounted paths directly beneath the remote root, without dereferencing
     * that root. Tests reuse AICLI_ITEST_MOUNTED_PATHS; production reads the
     * kernel's mountinfo pseudo-file (override: AICLI_MOUNTINFO).
     *
     * @return array<int,string>
     */
    public static function remoteMountpoints(string $remoteRoot): array {
        $root = rtrim($remoteRoot, '/');
        $hook = getenv('AICLI_ITEST_MOUNTED_PATHS');
        if ($hook !== false) {
            $paths = array_filter(explode(':', $hook), static fn($p) => self::isBelow($p, $root));
        } else {
            $mountinfo = getenv('AICLI_MOUNTINFO') ?: '/proc/self/mountinfo';
            $paths = [];
            foreach ((array)@file($mountinfo, FILE_IGNORE_NEW_LINES) as $line) {
                $fields = explode(' ', $line);
                if (count($fields) < 5) continue;
                $path = self::decodeMountinfoPath($fields[4]);
                if (self::isBelow($path, $root)) $paths[] = $path;
            }
        }
        $paths = array_values(array_unique($paths));
        sort($paths);
        return $paths;
    }

    private static function containingMountpoint(string $path, array $mounts): ?string {
        $best = null;
        foreach ($mounts as $mount) {
            if ($path === $mount || strpos($path, rtrim($mount, '/') . '/') === 0) {
                if ($best === null || strlen($mount) > strlen($best)) $best = $mount;
            }
        }
        return $best;
    }

    private static function isBelow(string $path, string $root): bool {
        return strpos($path, $root . '/') === 0;
    }

    /** Decode the octal escapes used for spaces, tabs, newlines and backslashes. */
    private static function decodeMountinfoPath(string $path): string {
        return preg_replace_callback('/\\\\([0-7]{3})/', static function ($m) {
            return chr(octdec($m[1]));
        }, $path) ?? $path;
    }

    /**
     * Is $path backed by a real mount right now? UD/remote paths must BE a
     * mountpoint (their parents /mnt/disks etc. are tmpfs); /mnt/user and
     * /mnt/disk<N> reuse StorageMountService::isPathAvailable (shfs / per-disk
     * /proc/mounts checks). AICLI_ITEST_MOUNTED_PATHS (colon-separated) forces
     * the verdict for tests.
     */
    private static function mounted(string $path): bool {
        $hook = getenv('AICLI_ITEST_MOUNTED_PATHS');
        if ($hook !== false) {
            return in_array($path, array_filter(explode(':', $hook)), true);
        }
        if (preg_match('#^/mnt/(user0?|disk\d+)(/|$)#', $path)) {
            return StorageMountService::isPathAvailable($path);
        }
        return self::findmntTarget($path) === $path;
    }

    /** findmnt -rn -o TARGET --target <path> via injection-safe array proc_open. */
    private static function findmntTarget(string $path): string {
        $proc = @proc_open( // nosemgrep: php.lang.security.tainted-exec.tainted-exec — array-form proc_open, no shell interpolation
            ['findmnt', '-rn', '-o', 'TARGET', '--target', $path],
            [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes
        );
        if (!is_resource($proc)) return '';
        $out = trim((string)stream_get_contents($pipes[1]));
        fclose($pipes[1]); fclose($pipes[2]); proc_close($proc);
        return $out;
    }

    /** Free bytes (statfs) at the nearest existing ancestor of $path. */
    private static function freeBytes(string $path): int {
        $p = $path;
        while ($p !== '' && $p !== '/' && !is_dir($p)) {
            $parent = dirname($p);
            if ($parent === $p) break;
            $p = $parent;
        }
        if ($p === '' || !is_dir($p)) return 0;
        $free = @disk_free_space($p);
        return ($free === false) ? 0 : (int)$free;
    }

    /**
     * Legacy #341 verdict — findmnt fstype check, used ONLY when the capability
     * probe itself is unavailable (probe_failed). Mirrors the pre-S-11 inline
     * preflightMigrate logic byte-for-byte in behaviour.
     * $fstypeOverride is the test seam: a string replaces the findmnt answer. Production passes none.
     * @return array{ok:bool, message:string, warnings:array<int,string>, resolved_path:?string}
     */
    public static function legacyFstypeVerdict(string $path, ?string $fstypeOverride = null): array {
        $fstype = '';
        if ($fstypeOverride !== null) {
            $fstype = $fstypeOverride;
        } else {
            $proc = @proc_open( // nosemgrep: php.lang.security.tainted-exec.tainted-exec — array-form proc_open, no shell interpolation
                ['findmnt', '--noheadings', '--output', 'FSTYPE', '--target', $path],
                [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes
            );
            if (is_resource($proc)) {
                $fstype = trim((string)stream_get_contents($pipes[1]));
                fclose($pipes[1]); fclose($pipes[2]); proc_close($proc);
            }
        }
        $blocked = ['tmpfs', 'ramfs', 'devtmpfs', 'overlay', 'zram', 'squashfs'];
        if (in_array($fstype, $blocked, true)) {
            return ['ok' => false, 'warnings' => [], 'resolved_path' => null,
                'message' => "Persistence path '$path' is on $fstype — not a durable filesystem. "
                    . 'Choose a path on ext4, xfs, btrfs, zfs, or vfat.'];
        }
        if ($fstype === '') {
            return ['ok' => false, 'warnings' => [], 'resolved_path' => null,
                'message' => "Cannot determine filesystem type for '$path'. "
                    . 'Ensure the path exists and is mounted before setting it as the persistence location.'];
        }
        return ['ok' => true, 'message' => '', 'warnings' => ['probe_unavailable'], 'resolved_path' => null];
    }
}
