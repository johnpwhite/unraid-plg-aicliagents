<?php
/**
 * <module_context>
 *     <name>GitHomeService</name>
 *     <description>Git-backed home config (OP #1365 / finding H-04, opt-in). Wraps a
 *     git repo rooted at the MOUNTED overlay agent home (same home_unavailable gate
 *     as HubProjector::resolveHome — never touches an unmounted home). init() writes
 *     the deny-by-default .gitignore (first rule `*`; explicit whitelist of every
 *     hub-projected file; the OAuth trio ~/.claude.json, ~/.gemini/mcp-oauth-tokens.json,
 *     ~/.codex/auth.json explicitly re-denied) then creates the repo + initial commit.
 *     Auto-commits are debounced: commitIfEnabled() appends the summary to a /tmp
 *     pending marker and only commits when the last commit is older than 30 s; a
 *     pending marker is flushed by the NEXT commitIfEnabled() or status() call (the
 *     UI polls status, so pending changes land within one poll cycle — no daemon
 *     change needed). Remote push/pull authenticate via a PAT from the SecretService
 *     vault (key HUB_GIT_TOKEN) injected through GIT_ASKPASS env — never argv, never
 *     disk, never logs.</description>
 *     <dependencies>HubProjector (resolveHome), ConfigService, SecretService, LogService</dependencies>
 *     <constraints>ALL git invocations via proc_open array form (no shell), as
 *     `git -C $home -c safe.directory=$home` (overlay mounts trip git's dubious-
 *     ownership check) with a fixed author identity (AICli Hub &lt;aicli@localhost&gt;)
 *     so the user's global gitconfig is never required nor modified. commit/restore
 *     take the SAME per-user lock as TaskService::persistHome
 *     (/tmp/unraid-aicliagents/init_&lt;user&gt;.lock) so git never interleaves with a
 *     bake. Never logs commit message bodies beyond names/counts, never logs the
 *     PAT. Test hooks: AICLI_HUB_HOME (via HubProjector), AICLI_HUB_GIT_TEST_ENABLED
 *     (force enabled+autocommit without touching /boot config),
 *     AICLI_HUB_GIT_DEBOUNCE_S (override the 30 s debounce).</constraints>
 * </module_context>
 */

namespace AICliAgents\Services\Hub;

use AICliAgents\Services\ConfigService;
use AICliAgents\Services\LogService;
use AICliAgents\Services\SecretService;

class GitHomeService {

    /** Auto-commit debounce window (seconds). Env-overridable for tests. */
    const DEBOUNCE_S = 30;

    /** R-14 (#211): cap on coalesced summaries in one commit body. */
    const MAX_BODY_LINES = 200;
    /** Fixed branch — keeps push/pull refspecs deterministic. */
    const BRANCH = 'main';
    /** Vault key holding the remote PAT (SecretService agent vault). */
    const TOKEN_KEY = 'HUB_GIT_TOKEN';
    /** .gitignore managed-block fence (user rules outside are preserved). */
    const GI_FENCE_OPEN  = '# >>> aicli-hub managed — do not edit inside >>>';
    const GI_FENCE_CLOSE = '# <<< aicli-hub <<<';
    /** Clean/smudge filter name (sanitizes resolved secrets <-> {KEY} placeholders). */
    const SECRET_FILTER = 'aicli-secrets';
    /**
     * Clean-only twin of the filter above, for the canonical store .aicli/hub/mcp.json (#590).
     * That file keeps {KEY} placeholders in the working tree, so a checkout must not
     * resolve them: smudge is `cat`.
     */
    const SECRET_FILTER_CLEAN_ONLY = 'aicli-secrets-clean';
    /** Home-relative path of the canonical MCP store (guarded against raw secrets). */
    const HUB_MCP_REL = '.aicli/hub/mcp.json';
    /** Where the snapshotted plugin settings live inside the managed home (home-relative). */
    const PLUGIN_BACKUP_REL = '.aicli/plugin-backup';
    /**
     * The ONLY plugin-config files snapshotted for backup — tiny + secret-free. Deny-by-
     * default: secrets.cfg, the secrets/ dir, ssh_keys.json, ~/.aicli/.exported_keys_*,
     * envs/, and especially persistence/ (GIGABYTES of squashfs) are NEVER copied.
     */
    const PLUGIN_BACKUP_FILES = ['unraid-aicliagents.cfg', 'versions.json', 'secrets_freeform_keys.json'];

    /** @var bool|null memoised git-availability probe */
    private static $gitAvailable = null;

    // ------------------------------------------------------------------
    // availability / gating
    // ------------------------------------------------------------------

    /**
     * `command -v git` equivalent as a pure-PHP PATH walk (no subprocess, no
     * shell). Stock Unraid does not bundle git and neither does this plugin —
     * the UI surfaces "install git via NerdTools" guidance when this is false.
     */
    public static function gitAvailable(): bool {
        if (self::$gitAvailable !== null) return self::$gitAvailable;
        $path = getenv('PATH');
        if ($path === false || $path === '') {
            $path = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin';
        }
        foreach (explode(':', $path) as $dir) {
            if ($dir !== '' && @is_executable(rtrim($dir, '/') . '/git')) {
                return self::$gitAvailable = true;
            }
        }
        return self::$gitAvailable = false;
    }

    /** Opt-in master switch (config key hub_git_enabled; absent = off). */
    public static function enabled(): bool {
        if (getenv('AICLI_HUB_GIT_TEST_ENABLED') === '1') return true;
        $config = ConfigService::getConfig();
        return (string)($config['hub_git_enabled'] ?? '0') === '1';
    }

    /** Auto-commit toggle — defaults ON once the git layer is enabled. */
    public static function autocommitEnabled(): bool {
        if (!self::enabled()) return false;
        if (getenv('AICLI_HUB_GIT_TEST_ENABLED') === '1') return true;
        $config = ConfigService::getConfig();
        return (string)($config['hub_git_autocommit'] ?? '1') === '1';
    }

    /** Repo initialized at the (mounted) home? */
    public static function initialized(): bool {
        $home = self::home();
        return $home !== null && is_dir("$home/.git");
    }

    private static function debounceSeconds(): int {
        $env = getenv('AICLI_HUB_GIT_DEBOUNCE_S');
        if ($env !== false && $env !== '' && is_numeric($env)) return max(0, (int)$env);
        return self::DEBOUNCE_S;
    }

    /** Mounted home path or null (same gate as HubProjector). */
    private static function home(): ?string {
        $info = HubProjector::resolveHome();
        return $info['ok'] ? $info['home'] : null;
    }

    private static function user(): string {
        $config = ConfigService::getConfig();
        $user = (string)($config['user'] ?? 'root');
        return $user === '' ? 'root' : $user;
    }

    private static function lockFile(): string {
        // MUST stay identical to TaskService::persistHome's lock path — this is
        // the interlock that keeps git from interleaving with a bake.
        $stateRoot = \AICliAgents\Services\SecretPaths::stateRoot();
        @mkdir($stateRoot, 0755, true);
        return \AICliAgents\Services\SecretPaths::homePersistLockPath(self::user());
    }

    private static function pendingMarker(): string {
        $user = preg_replace('/[^a-zA-Z0-9_-]/', '_', self::user());
        $stateRoot = \AICliAgents\Services\SecretPaths::stateRoot();
        @mkdir($stateRoot, 0755, true);
        return "$stateRoot/hub_git_pending_{$user}";
    }

    // ------------------------------------------------------------------
    // git plumbing — proc_open array form ONLY, no shell anywhere
    // ------------------------------------------------------------------

    /**
     * Run git against the home repo. Identity and safe.directory ride along as
     * -c flags on EVERY invocation: the overlay-mounted home is typically owned
     * by the session user while the web ctx runs as root, which trips git's
     * dubious-ownership check without safe.directory; the inline identity means
     * no global gitconfig is needed or touched.
     * @param string[] $args
     * @param array<string,string>|null $extraEnv extra env (e.g. GIT_ASKPASS + PAT)
     * @return array{rc:int,out:string,err:string}
     */
    // nosemgrep: php.lang.security.exec-use.exec-use
    private static function git(array $args, ?array $extraEnv = null, int $timeoutS = 30, ?string $stdin = null): array {
        $home = self::home();
        if ($home === null) return ['rc' => -1, 'out' => '', 'err' => 'home_unavailable'];
        $argv = array_merge([
            'git', '-C', $home,
            '-c', "safe.directory=$home",
            '-c', 'user.name=AICli Hub',
            '-c', 'user.email=aicli@localhost',
            '-c', 'init.defaultBranch=' . self::BRANCH,
            '-c', 'core.fileMode=false',
            // R-12 (#211): the home accumulates nested git repos that agents create for
            // their own state (Codex's tmp plugins dir, Antigravity's brain/ dirs, Grok's
            // marketplace caches). git recursing into one that is mid-init, has an unborn
            // branch, or a malformed HEAD used to fail the whole backup. Never recurse.
            '-c', 'submodule.recurse=false',
        ], self::hardeningArgs(), $args);

        // #643: this process runs as root, but ~/.git belongs to the session user, so
        // an agent can write to .git/config and to ~/.gitconfig. Pin every setting that
        // can run a program (above), ignore the system and global config files here,
        // and never inherit GIT_* variables from the web context.
        $hard = ['GIT_CONFIG_NOSYSTEM' => '1', 'GIT_CONFIG_GLOBAL' => '/dev/null', 'GIT_ATTR_NOSYSTEM' => '1'];
        if ($extraEnv !== null) {
            // proc_open's env REPLACES the environment — rebuild a minimal one.
            $env = array_merge([
                'PATH' => (string)(getenv('PATH') ?: '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'),
                'HOME' => $home,
            ], $extraEnv, $hard);
        } else {
            // The clean/smudge filter script needs the normal environment to open the vault.
            $env = [];
            foreach (getenv() as $k => $v) {
                if (strpos((string)$k, 'GIT_') === 0) continue;
                $env[$k] = (string)$v;
            }
            $env = array_merge($env, $hard);
        }
        self::scrubRepoConfig($home);

        $desc = [1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
        if ($stdin !== null) $desc[0] = ['pipe', 'r'];
        // nosemgrep: php.lang.security.exec-use.exec-use
        $proc = @proc_open($argv, $desc, $pipes, $home, $env);
        if (!is_resource($proc)) return ['rc' => -1, 'out' => '', 'err' => 'proc_open failed'];
        if ($stdin !== null) {
            fwrite($pipes[0], $stdin);
            fclose($pipes[0]);
            unset($pipes[0]);
        }
        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);
        $out = ''; $err = '';
        $deadline = microtime(true) + $timeoutS;
        while (true) {
            $status = proc_get_status($proc);
            $out .= (string)stream_get_contents($pipes[1]);
            $err .= (string)stream_get_contents($pipes[2]);
            if (!$status['running']) break;
            if (microtime(true) > $deadline) {
                proc_terminate($proc, 9);
                foreach ($pipes as $p) { if (is_resource($p)) fclose($p); }
                proc_close($proc);
                return ['rc' => -2, 'out' => trim($out), 'err' => "git timed out after {$timeoutS}s"];
            }
            usleep(20000);
        }
        $out .= (string)stream_get_contents($pipes[1]);
        $err .= (string)stream_get_contents($pipes[2]);
        foreach ($pipes as $p) { if (is_resource($p)) fclose($p); }
        proc_close($proc);
        // proc_get_status's exitcode is only valid on the FIRST running=false
        // observation — which is exactly the $status the loop broke on.
        $rc = (int)$status['exitcode'];
        return ['rc' => $rc, 'out' => trim($out), 'err' => trim($err)];
    }

    /**
     * #643: `-c` flags that win over the repository's own .git/config. They switch off
     * every git setting that can start a program (hooks, file-system monitor, ssh and
     * proxy commands, credential helpers, pagers, external diff, the ext:: transport)
     * and pin the two secret filters to their real commands.
     * @return string[]
     */
    private static function hardeningArgs(): array {
        $cmd = escapeshellarg(\AICliAgents\Services\UtilityService::cliPhpBinary()) . ' ' . escapeshellarg(self::filterScriptPath());
        $f = 'filter.' . self::SECRET_FILTER;
        $c = 'filter.' . self::SECRET_FILTER_CLEAN_ONLY;
        return [
            '-c', 'core.hooksPath=/dev/null',
            '-c', 'core.fsmonitor=false',
            '-c', 'core.sshCommand=ssh',
            '-c', 'core.pager=cat',
            '-c', 'core.askPass=',
            '-c', 'core.editor=true',
            '-c', 'credential.helper=',
            '-c', 'protocol.ext.allow=never',
            '-c', "$f.clean=$cmd clean",
            '-c', "$f.smudge=$cmd smudge",
            '-c', "$f.required=true",
            '-c', "$c.clean=$cmd clean",
            '-c', "$c.smudge=cat",
            '-c', "$c.required=true",
        ];
    }

    /**
     * Settings in the repository's own config that can start a program and that a `-c`
     * pin cannot cover (a filter, diff or merge driver with any name, an include file,
     * an alias, a rewritten URL). Pure: takes the config text, returns the dotted names.
     * @return string[] e.g. ['filter.evil', 'include.path', 'core.fsmonitor']
     */
    public static function unsafeConfigEntries(string $configText): array {
        $bad = [];
        $section = ''; $sub = '';
        foreach (preg_split('/\R/', $configText) ?: [] as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#' || $line[0] === ';') continue;
            if (preg_match('/^\[\s*([A-Za-z0-9-]+)(?:\s+"((?:[^"\\\\]|\\\\.)*)"|\.([^\]\s]+))?\s*\]/', $line, $m)) {
                $section = strtolower($m[1]);
                $sub = ($m[2] ?? '') !== '' ? $m[2] : (string)($m[3] ?? '');
                if (in_array($section, ['include', 'includeif', 'alias', 'url', 'pager', 'protocol', 'credential', 'submodule'], true)) {
                    $bad[] = $section . ($sub !== '' ? ".$sub" : '') . ' (section)';
                } elseif ($section === 'filter' && !in_array($sub, [self::SECRET_FILTER, self::SECRET_FILTER_CLEAN_ONLY], true)) {
                    $bad[] = "filter.$sub (section)";
                } elseif (in_array($section, ['diff', 'merge', 'difftool', 'mergetool'], true) && $sub !== '') {
                    $bad[] = "$section.$sub (section)";
                }
                // A key may follow the header on the same line; it is rare and covered by -c pins.
                continue;
            }
            $key = strtolower(trim(explode('=', $line, 2)[0]));
            if ($section === 'core' && in_array($key, ['fsmonitor', 'hookspath', 'sshcommand', 'gitproxy', 'pager', 'editor', 'askpass', 'attributesfile', 'worktree'], true)) {
                $bad[] = "core.$key";
            } elseif (in_array($section, ['diff', 'merge'], true) && in_array($key, ['external', 'tool', 'textconv', 'command', 'driver'], true)) {
                $bad[] = "$section.$key";
            } elseif ($section === 'filter' && $key === 'process') {
                $bad[] = "filter.$sub.process"; // a long-running filter: the -c pins cannot unset it
            } elseif ($section === 'gpg' && substr($key, -7) === 'program') {
                $bad[] = "gpg.$key";
            } elseif ($section === 'remote' && in_array($key, ['proxy', 'uploadpack', 'receivepack', 'vcs'], true)) {
                $bad[] = "remote.$sub.$key";
            } elseif (in_array($section, ['uploadpack', 'receive'], true) && $key !== '') {
                if (in_array($key, ['packobjectshook', 'procreceive'], true)) $bad[] = "$section.$key";
            } elseif (in_array($section, ['sequence', 'init'], true) && in_array($key, ['editor', 'templatedir'], true)) {
                $bad[] = "$section.$key";
            }
        }
        return array_values(array_unique($bad));
    }

    /** True while scrubRepoConfig is healing, so its own git calls do not scrub again. */
    private static $scrubbing = false;
    /** Config file stamp already found clean in this process (path|mtime|size). */
    private static $scrubbedStamp = '';

    /**
     * #643: remove program-starting entries from ~/.git/config before git reads it as root.
     * The `-c` pins in hardeningArgs() are the main defence; this covers the entries a
     * pin cannot name. A removal is logged. Residual risk: an agent that rewrites the
     * file between this check and the git call (the pins still hold).
     */
    private static function scrubRepoConfig(string $home): void {
        if (self::$scrubbing) return;
        $cfg = "$home/.git/config";
        if (!is_file($cfg) || is_link($cfg)) return;
        clearstatcache(true, $cfg);
        $stamp = $cfg . '|' . (int)@filemtime($cfg) . '|' . (int)@filesize($cfg);
        if ($stamp === self::$scrubbedStamp) return;
        $bad = self::unsafeConfigEntries((string)@file_get_contents($cfg));
        if (empty($bad)) { self::$scrubbedStamp = $stamp; return; }
        self::$scrubbing = true;
        try {
            foreach ($bad as $name) {
                if (substr($name, -10) === ' (section)') {
                    self::git(['config', '--local', '--remove-section', substr($name, 0, -10)]);
                } else {
                    self::git(['config', '--local', '--unset-all', $name]);
                }
            }
            LogService::log('hub git: removed program-starting entries from the backup repository config: '
                . implode(', ', $bad), LogService::LOG_WARN, 'GitHomeService');
        } finally {
            self::$scrubbing = false;
        }
        clearstatcache(true, $cfg);
        self::$scrubbedStamp = $cfg . '|' . (int)@filemtime($cfg) . '|' . (int)@filesize($cfg);
    }

    // ------------------------------------------------------------------
    // .gitignore generation (pure + testable)
    // ------------------------------------------------------------------

    /**
     * Deny-by-default .gitignore managed block.
     *
     * Semantics (verified by GitHomeServiceTest leak guards):
     *  - `*` denies every FILE by default — a future vendor token file cannot
     *    leak by omission; new vendors require an explicit `!` whitelist entry.
     *  - the directory re-include rule (bang-star-slash, second rule below)
     *    re-includes every DIRECTORY so git descends and the file-level
     *    whitelist can match (gitignore never un-ignores a file whose
     *    parent directory is still ignored — `!.claude/settings.json` alone
     *    would be dead under a bare `*`). Directories themselves are never
     *    tracked by git, so this re-include leaks nothing.
     *  - The OAuth trio is re-denied at the END (last match wins) with named
     *    comments so the exclusion is self-documenting even though `*` already
     *    covers them — and so no future whitelist glob can accidentally
     *    out-rank them.
     */
    /**
     * R-11 (#211): the ONE derivation of the backup whitelist. `generateGitignore()`
     * renders it as ignore rules; `backupPathspecs()` renders it as git pathspecs for
     * staging. Both call this, so the file git is told to ignore and the paths git is
     * told to stage can never drift apart.
     * @return string[] gitignore-style patterns, relative to the home root
     */
    public static function backupWhitelist(): array {
        // DERIVE the whitelist from the projector registry so the backup can NEVER drift
        // from what is injected. THIS IS THE FIX for the audit-era bug where newly-wired
        // surfaces (~/.kilo/rules, ~/.agents/skills, OpenCode AGENTS.md, …) were silently
        // excluded from the backup. Every MCP / instruction / skills / commands path the hub
        // projects is whitelisted; the OAuth trio is re-denied last (see below). NOTE: the
        // projected per-agent MCP files can carry RESOLVED secret env values — versioning
        // them is a documented tradeoff; the canonical .aicli/hub store keeps the placeholder
        // form regardless.
        $oauthDeny = ['.claude.json', '.gemini/mcp-oauth-tokens.json', '.codex/auth.json'];
        // .aicli/hub/** = canonical store; plugin-backup/** = snapshotted /boot settings;
        // workspaces.json = the (home-resident) workspace definitions. NOT .aicli/** wholesale
        // — that would sweep in ~/.aicli/.exported_keys_* (secrets) and other state.
        // '.claude/CLAUDE.md' + '.claude/rules/**' are backed up as Claude config in their
        // own right: the user's own global instructions live there, and since Claude's hub
        // instruction moved from a CLAUDE.md fence to a dedicated ~/.claude/rules/ file
        // (docs/specs/AGENT_RULES_INJECTION_STRATEGY.md), CLAUDE.md is no longer covered by
        // the instructionVendors loop below — whitelist it explicitly so it stays in backup.
        $whitelist = ['.aicli/hub/**', '.aicli/plugin-backup/**', '.aicli/workspaces.json',
                      '.claude/settings.json', '.claude/agents/**', '.claude/CLAUDE.md', '.claude/rules/**'];
        foreach (HubProjector::supportedVendors() as $p)   $whitelist[] = $p->relPath();              // MCP files
        foreach (HubProjector::instructionVendors() as $p) $whitelist[] = $p->relPath();              // instruction files
        // File-path-convention policy files (docs/specs/AGENT_FILE_PATH_CONVENTION.md): the fence
        // agents share relPath() with their instruction-file entry above (de-duped by the
        // array_unique below); Kilo's dedicated ~/.kilo/rules/aicli-file-paths.md is the only
        // genuinely NEW path this adds.
        foreach (HubProjector::policyInstructionVendors() as $p) $whitelist[] = $p->relPath();
        foreach (HubProjector::treeVendors() as $p)        $whitelist[] = rtrim($p->relPath(), '/') . '/**'; // skills/commands dirs
        // Drop anything that is OAuth-excluded (e.g. ~/.claude.json is also Claude's MCP path).
        $whitelist = array_values(array_filter(array_unique($whitelist), fn($x) => !in_array($x, $oauthDeny, true)));
        sort($whitelist);
        return $whitelist;
    }

    /**
     * R-11 (#211): the whitelist as git PATHSPECS for `git add -A -- …`.
     * A trailing `/**` becomes the plain directory (git recurses a directory pathspec on
     * its own); a file entry passes through unchanged. Staging only these means a nested
     * git repository outside the whitelist — an agent's own `git init` under the home,
     * which `git add -A` would otherwise record as a gitlink and then recurse into — is
     * never even considered. `.gitignore` still governs what inside them is eligible.
     * @return string[]
     */
    public static function backupPathspecs(): array {
        $specs = ['.gitignore'];   // .gitattributes is not whitelisted, so git ignores it
        foreach (self::backupWhitelist() as $w) {
            $specs[] = (substr($w, -3) === '/**') ? substr($w, 0, -3) : $w;
        }
        return array_values(array_unique($specs));
    }

    public static function generateGitignore(): string {
        $whitelist = self::backupWhitelist();
        $lines = [
            self::GI_FENCE_OPEN,
            '# Deny-by-default: only explicitly whitelisted paths ever enter git.',
            '*',
            '# Re-include directories so git descends (files stay denied by *).',
            '!*/',
            '',
            '# The backup machinery itself',
            '!.gitignore',
            '',
            '# Whitelist DERIVED from the Config-Hub projector registry (canonical .aicli/hub',
            '# store + Claude config + every projected MCP / instruction / skills / commands',
            '# surface) so it can never drift from what is injected. Adding a new agent surface',
            '# auto-includes it in the backup.',
        ];
        foreach ($whitelist as $path) $lines[] = '!' . $path;
        $lines = array_merge($lines, [
            '',
            '# ---- OAuth / credential exclusions (explicit re-denies; LAST = wins) ----',
            '# ~/.claude.json co-locates the Claude Code OAuth token with user-level',
            '# settings/MCP — excluded ENTIRELY. The MCP config is recoverable from the',
            '# canonical .aicli/hub store; manage Claude settings via ~/.claude/settings.json.',
            '.claude.json',
            '# ~/.gemini/mcp-oauth-tokens.json — Gemini CLI OAuth tokens.',
            '.gemini/mcp-oauth-tokens.json',
            '# ~/.codex/auth.json — Codex CLI auth credentials.',
            '.codex/auth.json',
            self::GI_FENCE_CLOSE,
        ]);
        return implode("\n", $lines) . "\n";
    }

    /**
     * Write/refresh ~/.gitignore: a pre-existing user file keeps its own rules
     * OUTSIDE the fence (block replaced in place when present, appended when
     * not). The managed block sits LAST so deny-by-default cannot be defeated
     * by earlier user rules.
     */
    private static function writeGitignore(string $home): bool {
        $file = "$home/.gitignore";
        $block = self::generateGitignore();
        $existing = is_file($file) ? (string)@file_get_contents($file) : '';
        $openPos = strpos($existing, self::GI_FENCE_OPEN);
        $closePos = strpos($existing, self::GI_FENCE_CLOSE);
        if ($openPos !== false && $closePos !== false && $closePos > $openPos) {
            $before = substr($existing, 0, $openPos);
            $after = substr($existing, $closePos + strlen(self::GI_FENCE_CLOSE));
            $content = rtrim($before . ltrim($after, "\n"));
            $content = ($content === '' ? '' : $content . "\n\n") . $block;
        } else {
            $content = ($existing === '' ? '' : rtrim($existing) . "\n\n") . $block;
        }
        return \AICliAgents\Services\AtomicWriteService::write($file, $content);
    }

    // ------------------------------------------------------------------
    // secret clean/smudge filter (resolved secrets <-> {KEY} placeholders)
    // ------------------------------------------------------------------

    /** Absolute path to the clean/smudge filter php script (deployed + in-repo). */
    public static function filterScriptPath(): string {
        return dirname(__DIR__, 3) . '/scripts/user/git-secret-filter.php';
    }

    /**
     * Pure clean/smudge transform (the filter script delegates here so it is unit-testable).
     *  - clean:  resolved secret VALUE -> {KEY}. Longest values first so a value that is a
     *            substring of another isn't partially clobbered; empty / <6-char values are
     *            skipped (a tiny "secret" would cause coincidental false-positive replaces).
     *  - smudge: {KEY} -> resolved secret value.
     * Only vault-shaped keys ([A-Z][A-Z0-9_]+) are considered.
     * @param array<string,mixed> $secrets KEY => value
     */
    public static function applySecretFilter(string $mode, string $content, array $secrets): string {
        $valid = [];
        foreach ($secrets as $k => $v) {
            if (preg_match('/^[A-Z][A-Z0-9_]{1,127}$/D', (string)$k)) $valid[(string)$k] = (string)$v;
        }
        if ($mode === 'clean') {
            $pairs = [];
            foreach ($valid as $k => $v) {
                if ($v === '' || strlen($v) < 6) continue;
                $pairs[] = [$v, '{' . $k . '}'];
                // #666 R-158: a value with a quote, a backslash or a newline (a PEM key) sits
                // in a JSON, TOML or YAML file in its ESCAPED form. Match those forms too.
                foreach (self::escapedForms($v) as $form) $pairs[] = [$form, '{' . $k . '}'];
            }
            usort($pairs, static fn($a, $b) => strlen($b[0]) <=> strlen($a[0]));
            foreach ($pairs as [$val, $ph]) $content = str_replace($val, $ph, $content);
            return $content;
        }
        foreach ($valid as $k => $v) $content = str_replace('{' . $k . '}', $v, $content);
        return $content;
    }

    /**
     * The ways a secret value can be written inside a quoted string of a config file:
     * JSON or TOML or YAML double-quoted (with and without the escaped slash), and YAML
     * single-quoted. Only forms that differ from the raw value are returned.
     * @return string[]
     */
    public static function escapedForms(string $value): array {
        $forms = [];
        $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (is_string($json) && strlen($json) >= 2) $forms[] = substr($json, 1, -1);
        $jsonSlash = json_encode($value, JSON_UNESCAPED_UNICODE);
        if (is_string($jsonSlash) && strlen($jsonSlash) >= 2) $forms[] = substr($jsonSlash, 1, -1);
        $forms[] = str_replace("'", "''", $value);
        return array_values(array_filter(array_unique($forms), static fn($f) => $f !== $value && strlen($f) >= 6));
    }

    /**
     * Managed .gitattributes: route every per-agent MCP file (which HubProjector resolves
     * {SECRET} placeholders into) through the clean/smudge filter, so the COMMITTED blob is
     * sanitized while the working tree stays resolved. DERIVED from the MCP projector
     * registry (minus the OAuth-excluded ~/.claude.json) so it can't drift.
     */
    public static function generateGitAttributes(): string {
        $oauth = ['.claude.json', '.gemini/mcp-oauth-tokens.json', '.codex/auth.json'];
        $paths = [];
        foreach (HubProjector::supportedVendors() as $p) {
            if (in_array($p->relPath(), $oauth, true)) continue;
            $paths[] = $p->relPath();
        }
        $paths = array_values(array_unique($paths));
        sort($paths);
        $lines = [
            self::GI_FENCE_OPEN,
            '# Sanitize resolved secrets out of the COMMITTED per-agent MCP files (the working',
            '# tree stays resolved). Filter defined in .git/config (filter.' . self::SECRET_FILTER . '.*).',
        ];
        foreach ($paths as $rel) $lines[] = $rel . ' filter=' . self::SECRET_FILTER;
        $lines[] = '# The canonical MCP store: clean only, so a vault value that reached it is committed as {KEY}.';
        $lines[] = self::HUB_MCP_REL . ' filter=' . self::SECRET_FILTER_CLEAN_ONLY;
        $lines[] = self::GI_FENCE_CLOSE;
        return implode("\n", $lines) . "\n";
    }

    /** Write/refresh ~/.gitattributes (same managed-fence discipline as .gitignore). */
    private static function writeGitAttributes(string $home): bool {
        $file = "$home/.gitattributes";
        $block = self::generateGitAttributes();
        $existing = is_file($file) ? (string)@file_get_contents($file) : '';
        $openPos = strpos($existing, self::GI_FENCE_OPEN);
        $closePos = strpos($existing, self::GI_FENCE_CLOSE);
        if ($openPos !== false && $closePos !== false && $closePos > $openPos) {
            $before = substr($existing, 0, $openPos);
            $after = substr($existing, $closePos + strlen(self::GI_FENCE_CLOSE));
            $content = rtrim($before . ltrim($after, "\n"));
            $content = ($content === '' ? '' : $content . "\n\n") . $block;
        } else {
            $content = ($existing === '' ? '' : rtrim($existing) . "\n\n") . $block;
        }
        return \AICliAgents\Services\AtomicWriteService::write($file, $content);
    }

    /**
     * Register the clean/smudge filter in THIS repo's .git/config (local, never committed).
     * `required=true` makes git ABORT if the filter errors — it can never fall back to the
     * raw secret-bearing blob. Uses the command-line PHP (#880): inside the web server PHP_BINARY is php-fpm, which cannot run a filter.
     */
    private static function configureSecretFilter(): void {
        $cmd = escapeshellarg(\AICliAgents\Services\UtilityService::cliPhpBinary()) . ' ' . escapeshellarg(self::filterScriptPath());
        self::git(['config', 'filter.' . self::SECRET_FILTER . '.clean',  $cmd . ' clean']);
        self::git(['config', 'filter.' . self::SECRET_FILTER . '.smudge', $cmd . ' smudge']);
        self::git(['config', 'filter.' . self::SECRET_FILTER . '.required', 'true']);
        self::git(['config', 'filter.' . self::SECRET_FILTER_CLEAN_ONLY . '.clean',  $cmd . ' clean']);
        self::git(['config', 'filter.' . self::SECRET_FILTER_CLEAN_ONLY . '.smudge', 'cat']);
        self::git(['config', 'filter.' . self::SECRET_FILTER_CLEAN_ONLY . '.required', 'true']);
    }

    /**
     * Last line of defence for the canonical MCP store (#590). The clean filter turns a
     * vault VALUE back into {KEY}; this guard catches the rest, a raw secret that is in
     * no vault entry. It reads the STAGED blob, so it sees what would be committed. When
     * the blob holds one, the file is unstaged for this commit (the rest of the backup
     * goes on) and the reason is logged. Returns the problems found (names, no values).
     * @return string[]
     */
    private static function unstageMcpStoreWithRawSecrets(): array {
        $r = self::git(['show', ':' . self::HUB_MCP_REL]);
        if ($r['rc'] !== 0 || $r['out'] === '') return []; // not staged: nothing to guard
        $data = json_decode($r['out'], true);
        $problems = is_array($data) ? \AICliAgents\Services\Hub\HubStore::rawSecretProblems((array)($data['servers'] ?? [])) : [];
        if (empty($problems)) return [];
        self::git(['reset', '-q', '--', self::HUB_MCP_REL]);
        LogService::log('hub git: ' . self::HUB_MCP_REL . ' left out of the commit, it holds a raw secret ('
            . implode('; ', $problems) . '). Move the value to Secrets and use {KEY}.', LogService::LOG_WARN, 'GitHomeService');
        return $problems;
    }

    // ------------------------------------------------------------------
    // plugin-settings backup/restore (the small, secret-free config)
    // ------------------------------------------------------------------

    /** Plugin config dir on flash (overridable for tests via AICLI_PLUGIN_CFG_DIR; the flash root under test is the sandbox). */
    private static function pluginCfgDir(): string {
        $env = getenv('AICLI_PLUGIN_CFG_DIR');
        return ($env !== false && $env !== '') ? rtrim($env, '/') : \AICliAgents\Services\SecretPaths::flashRoot();
    }

    /**
     * Snapshot the curated, secret-free plugin settings (PLUGIN_BACKUP_FILES) from flash
     * into ~/.aicli/plugin-backup so they ride along in the next commit. Runs in the plugin's
     * commit path (root web ctx — the only context that can read the 0700 plugin dir on
     * flash). NEVER touches secrets or the GB-scale persistence/ squashfs. A source file that
     * has gone away is dropped from the backup so the repo mirrors the live settings.
     */
    public static function snapshotPluginSettings(string $home): void {
        $src = self::pluginCfgDir();
        $dst = rtrim($home, '/') . '/' . self::PLUGIN_BACKUP_REL;
        if (!is_dir($dst)) @mkdir($dst, 0700, true);
        foreach (self::PLUGIN_BACKUP_FILES as $f) {
            $s = "$src/$f"; $d = "$dst/$f";
            if (is_file($s)) { @copy($s, $d); @chmod($d, 0600); }
            elseif (is_file($d)) { @unlink($d); }
        }
    }

    /**
     * Restore the snapshotted plugin settings back to flash — a DELIBERATE, user-confirmed
     * action (never automatic on pull: writing live plugin config mid-operation is a
     * foot-gun). Copies only PLUGIN_BACKUP_FILES that exist in the backup; the workspace
     * definitions live in the home (~/.aicli/workspaces.json) and are restored by the
     * checkout itself. @return array{status:string,restored:string[],message?:string}
     */
    public static function restorePluginSettings(): array {
        if (!self::initialized()) return ['status' => 'error', 'message' => 'git layer not initialized'];
        $home = self::home();
        if ($home === null) return ['status' => 'error', 'reason' => 'home_unavailable', 'message' => 'agent home is not mounted'];
        $src = rtrim($home, '/') . '/' . self::PLUGIN_BACKUP_REL;
        if (!is_dir($src)) return ['status' => 'error', 'message' => 'no plugin-settings backup found — commit once first'];
        $dst = self::pluginCfgDir();
        if (!is_dir($dst)) return ['status' => 'error', 'message' => 'plugin config dir missing'];
        $restored = [];
        foreach (self::PLUGIN_BACKUP_FILES as $f) {
            if (is_file("$src/$f") && @copy("$src/$f", "$dst/$f")) { @chmod("$dst/$f", 0600); $restored[] = $f; }
        }
        LogService::log('hub git: restored plugin settings [' . implode(',', $restored) . ']', LogService::LOG_INFO, 'GitHomeService');
        return ['status' => 'ok', 'restored' => $restored];
    }

    // ------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------

    /**
     * Initialize the git layer: write the deny-by-default .gitignore, git init,
     * initial commit. Idempotent — re-running refreshes the managed .gitignore
     * block and commits it if it changed, but never re-inits.
     * Does NOT flip the hub_git_enabled config key — the AJAX handler owns that
     * (keeps this service runnable under the test env hooks without /boot).
     */
    public static function init(): array {
        if (!self::gitAvailable()) {
            return ['status' => 'error', 'reason' => 'git_unavailable',
                    'message' => 'git is not installed — install it via NerdTools (Community Applications) to enable config backup.'];
        }
        $home = self::home();
        if ($home === null) {
            return ['status' => 'error', 'reason' => 'home_unavailable',
                    'message' => 'The agent home overlay is not mounted — start a session or the array, then retry.'];
        }
        if (!self::writeGitignore($home)) {
            return ['status' => 'error', 'message' => 'failed to write .gitignore'];
        }

        // R-15 (#211): a .git directory that exists but is unusable (missing HEAD/config
        // after a crash) counts as "needs init" too — repoValid, not mere presence, decides.
        $fresh = !self::repoValid($home);
        if ($fresh) {
            $r = self::git(['init', '-b', self::BRANCH]);
            if ($r['rc'] !== 0) {
                // Older git without -b: fall back to plain init (init.defaultBranch
                // -c flag still applies on ≥2.28; ancient gits land on master and
                // push/pull below would need the branch renamed — log it).
                $r = self::git(['init']);
                if ($r['rc'] !== 0) {
                    return ['status' => 'error', 'message' => 'git init failed: ' . $r['err']];
                }
            }
        }

        // Register the secret clean/smudge filter (.git/config, local) + the .gitattributes
        // that routes per-agent MCP files through it, BEFORE the commit so the committed
        // blobs are sanitized. Idempotent on re-init.
        self::configureSecretFilter();
        if (!self::writeGitAttributes($home)) {
            return ['status' => 'error', 'message' => 'failed to write .gitattributes'];
        }

        $commit = self::lockedCommit($fresh ? 'hub: initial config backup' : 'hub: refresh managed config');
        // #666 R-157: a failed first commit must not be reported as a working backup.
        // The caller flips the opt-in only on 'ok'. 'busy' and 'error' go back as they are.
        if (($commit['status'] ?? '') !== 'ok') {
            self::fixOwnership($home);
            if (($commit['status'] ?? '') === 'busy') return $commit;
            return ['status' => 'error', 'message' => (string)($commit['message'] ?? 'the first config backup commit failed')];
        }

        self::fixOwnership($home);
        LogService::log('hub git: init ' . ($fresh ? 'created repo' : 'refreshed existing repo') . " at $home", LogService::LOG_INFO, 'GitHomeService');
        return ['status' => 'ok', 'created' => $fresh];
    }

    /**
     * Status surface for the UI (and the debounce flush consumer: a due pending
     * marker is flushed here, so the tab's status poll publishes coalesced
     * auto-commits without any daemon involvement).
     */
    public static function status(): array {
        $out = [
            'status' => 'ok',
            'gitAvailable' => self::gitAvailable(),
            'enabled' => self::enabled(),
            'autocommit' => self::autocommitEnabled(),
            'initialized' => false,
            'branch' => self::BRANCH,
            'homeAvailable' => self::home() !== null,
            'dirty' => 0,
            'commits' => 0,
            'lastCommit' => null,
            'pending' => false,
            'remote' => '',
            'tokenSet' => false,
            // R-14 (#211): the backup used to report enabled/ok while every commit
            // failed. `healthy` false means the last commit attempt failed and nothing
            // is being saved — the History card shows `lastError` verbatim.
            'healthy' => true,
            'lastError' => null,
        ];
        $out['lastError'] = self::lastFailure();
        if ($out['lastError'] !== null) $out['healthy'] = false;
        if (!$out['gitAvailable'] || !$out['homeAvailable'] || !self::initialized()) return $out;
        $out['initialized'] = true;

        // Flush a due pending auto-commit on the poll path (debounce consumer).
        self::flushPendingIfDue();

        // R-11 (#211): scope `dirty` to the paths the backup actually covers. A whole-tree
        // read counts the nested repos and every other unbacked path, so the card would
        // show a permanent uncommitted-change count that no commit can ever clear.
        $home = self::home();
        $dirtySpecs = $home !== null ? self::stageablePathspecs($home) : [];
        $st = self::git(array_merge(['status', '--porcelain', '--ignore-submodules=all', '--'], $dirtySpecs));
        if ($st['rc'] === 0) {
            $out['dirty'] = $st['out'] === '' ? 0 : count(explode("\n", $st['out']));
        } else {
            // R-14: reading this as "clean" is exactly how the dead backup looked healthy.
            $out['healthy'] = false;
            if ($out['lastError'] === null) {
                $out['lastError'] = ['message' => 'git status failed: ' . $st['err'], 'ts' => time()];
            }
        }
        $cnt = self::git(['rev-list', '--count', 'HEAD']);
        if ($cnt['rc'] === 0) $out['commits'] = (int)$cnt['out'];
        $last = self::git(['log', '-1', '--pretty=format:%H%x1f%h%x1f%ct%x1f%s']);
        if ($last['rc'] === 0 && $last['out'] !== '') {
            $f = explode("\x1f", $last['out']);
            if (count($f) === 4) {
                $out['lastCommit'] = ['hash' => $f[0], 'short' => $f[1], 'ts' => (int)$f[2], 'subject' => $f[3]];
            }
        }
        $out['pending'] = is_file(self::pendingMarker());
        $remote = self::git(['remote', 'get-url', 'origin']);
        if ($remote['rc'] === 0) $out['remote'] = $remote['out'];
        $out['tokenSet'] = (string)(SecretService::getAgentSecrets()[self::TOKEN_KEY] ?? '') !== '';
        return $out;
    }

    // ------------------------------------------------------------------
    // commits (debounced auto-commit + manual)
    // ------------------------------------------------------------------

    /**
     * Debounced auto-commit hook, called by the hub save paths AFTER their own
     * successful writes. Mechanism (documented choice): every call appends the
     * summary (names only, never values) to a /tmp pending marker; if the last
     * commit is older than the 30 s debounce window the marker is flushed into
     * ONE commit immediately, otherwise the marker waits for the NEXT
     * commitIfEnabled() call or the UI's status() poll to flush it. Bursts of
     * saves therefore coalesce into a single commit ≥30 s apart with all their
     * summaries in the commit body. No-op (never an error) when the layer is
     * off, git is absent, the repo is uninitialized, or the home is unmounted.
     */
    public static function commitIfEnabled(string $summary): void {
        if (!self::autocommitEnabled() || !self::gitAvailable() || !self::initialized()) return;
        $summary = self::sanitizeMessage($summary);
        $marker = self::pendingMarker();
        $existing = is_file($marker) ? (string)@file_get_contents($marker) : '';
        if (strpos($existing, $summary . "\n") === false) {
            @file_put_contents($marker, $existing . $summary . "\n");
            @chmod($marker, 0600);
        }
        self::flushPendingIfDue();
    }

    /** Flush the pending marker into one commit when the debounce has elapsed. */
    private static function flushPendingIfDue(): void {
        if (!self::autocommitEnabled()) return;
        $marker = self::pendingMarker();
        if (!is_file($marker)) return;
        $last = self::git(['log', '-1', '--pretty=format:%ct']);
        $lastTs = ($last['rc'] === 0 && $last['out'] !== '') ? (int)$last['out'] : 0;
        if ((time() - $lastTs) < self::debounceSeconds()) return; // still inside the window
        $lines = array_values(array_filter(array_map('trim', explode("\n", (string)@file_get_contents($marker)))));
        if (empty($lines)) { @unlink($marker); return; }
        $subject = count($lines) === 1 ? $lines[0] : ('hub: ' . count($lines) . ' coalesced changes');
        // R-14 (#211): the marker now survives a failed commit, so cap the body. The
        // append path de-duplicates by summary, but summaries embed file names, so a long
        // outage across many files could otherwise build an unreadable commit message.
        if (count($lines) === 1) {
            $body = '';
        } elseif (count($lines) <= self::MAX_BODY_LINES) {
            $body = implode("\n", $lines);
        } else {
            $body = implode("\n", array_slice($lines, -self::MAX_BODY_LINES))
                  . "\n… and " . (count($lines) - self::MAX_BODY_LINES) . ' earlier change(s)';
        }
        $r = self::lockedCommit($subject, $body);
        // R-14 (#211): consume the marker ONLY on success. It used to be unlinked on
        // error too, so a failing commit silently discarded the queued summaries as
        // well as the commit. 'busy' (a bake in flight) already retried; an error now
        // behaves the same way, so the work survives until the cause is fixed.
        if (($r['status'] ?? '') === 'ok') {
            @unlink($marker);
        }
    }

    /**
     * Manual commit (hub_git_commit). Bypasses the debounce; still takes the
     * per-user bake interlock.
     */
    public static function commit(string $message): array {
        if (!self::gitAvailable()) return ['status' => 'error', 'reason' => 'git_unavailable', 'message' => 'git is not installed'];
        if (!self::initialized()) return ['status' => 'error', 'message' => 'git layer not initialized'];
        return self::lockedCommit(self::sanitizeMessage($message));
    }

    /**
     * add -A + commit under the SAME per-user lock TaskService::persistHome
     * takes, so a commit can never interleave with a bake (and vice versa —
     * the committed tree is always consistent with what gets baked). Non-
     * blocking with a short retry; a held lock returns busy rather than
     * stalling the web request behind a long bake.
     */
    /**
     * R-11 (#211): the whitelist pathspecs that git will accept right now.
     *
     * `git add -- <pathspec>` is fatal on a pathspec that matches nothing, and the
     * whitelist covers every agent the hub knows about — most are not installed on any
     * given box. Keep a spec when it exists on disk OR is already tracked: the second
     * case is what stages the DELETION of a whitelisted file that has been removed, so
     * filtering on existence alone would silently stop recording deletions.
     *
     * One `ls-files` call, matched in memory — not one git call per spec.
     * @return string[]
     */
    private static function stageablePathspecs(string $home): array {
        $tracked = [];
        $ls = self::git(['ls-files']);
        if ($ls['rc'] === 0 && $ls['out'] !== '') {
            foreach (explode("\n", $ls['out']) as $f) {
                $f = trim($f);
                if ($f !== '') $tracked[$f] = true;
            }
        }
        $specs = [];
        foreach (self::backupPathspecs() as $s) {
            if (file_exists($home . '/' . $s) || is_link($home . '/' . $s)) { $specs[] = $s; continue; }
            if (isset($tracked[$s])) { $specs[] = $s; continue; }
            $prefix = $s . '/';
            foreach ($tracked as $f => $_) {
                if (strncmp($f, $prefix, strlen($prefix)) === 0) { $specs[] = $s; break; }
            }
        }
        return self::dropIgnored($home, $specs);
    }

    /**
     * R-11 (#211): drop pathspecs git would refuse. `git add -- <spec>` is fatal on a
     * spec the .gitignore excludes, where a bare `git add -A` silently skipped it. Real
     * directories survive (the managed block re-includes directories) but a SYMLINK to a
     * directory does not —
     * `~/.claude/skills` and `~/.claude/agents` are bootstrap symlinks into
     * ~/.claude-config, so git treats them as ignored files. They were never in the
     * backup before either; dropping them keeps behaviour identical instead of
     * force-adding (`-f`), which could pull in a path the deny-list exists to keep out.
     * One `check-ignore --stdin` call for the whole list.
     * @param string[] $specs
     * @return string[]
     */
    private static function dropIgnored(string $home, array $specs): array {
        if (empty($specs)) return $specs;
        // rc 0 = at least one ignored, 1 = none ignored, >1 = a real error (keep all).
        $r = self::git(['check-ignore', '--stdin'], null, 30, implode("\n", $specs) . "\n");
        if ($r['rc'] > 1) return $specs;
        $ignored = [];
        foreach (explode("\n", $r['out']) as $line) {
            $line = trim($line);
            if ($line !== '') $ignored[$line] = true;
        }
        return array_values(array_filter($specs, fn($s) => !isset($ignored[$s])));
    }

    /**
     * R-13 (#211): remove every gitlink (mode 160000) from the index. A gitlink is what
     * `git add -A` records for a directory that happens to contain its own `.git`; it
     * stores no content, and its only effect is to make `git status`/`git add` recurse
     * into that repo — which fails the whole backup when the nested repo is mid-init, on
     * an unborn branch, or has a malformed HEAD. Idempotent.
     */
    private static function purgeGitlinks(): void {
        $ls = self::git(['ls-files', '-s']);
        if ($ls['rc'] !== 0 || $ls['out'] === '') return;
        $paths = [];
        foreach (explode("\n", $ls['out']) as $line) {
            // "<mode> <sha> <stage>\t<path>"
            if (strncmp($line, '160000 ', 7) !== 0) continue;
            $tab = strpos($line, "\t");
            if ($tab === false) continue;
            $paths[] = substr($line, $tab + 1);
        }
        if (empty($paths)) return;
        // --cached: index only — the nested repo on disk is never touched (verified).
        // -f is required, not optional: git refuses a plain --cached removal when the
        // staged gitlink differs from both the worktree and HEAD ("use -f to force
        // removal"), which is exactly the state a gitlink staged-but-not-yet-committed
        // is in. -f overrides only that safety check; with --cached it cannot delete
        // anything from disk.
        $r = self::git(array_merge(['rm', '--cached', '-q', '-f', '--ignore-unmatch', '--'], $paths));
        if ($r['rc'] === 0) {
            LogService::log('hub git: dropped ' . count($paths) . ' nested-repo gitlink(s) from the backup index',
                LogService::LOG_INFO, 'GitHomeService');
        }
    }

    /**
     * R-15 (#211): is ~/.git a usable git repository RIGHT NOW? A directory alone is not
     * enough — a crash can leave the object store while HEAD/config/refs are lost, and git
     * then refuses every command with "not a git repository", failing every backup forever.
     * Cheap file check first (missing HEAD is the exact corruption seen on .4), then one
     * authoritative `rev-parse --git-dir`.
     */
    private static function repoValid(string $home): bool {
        if (!is_dir("$home/.git") || !is_file("$home/.git/HEAD")) return false;
        $r = self::git(['rev-parse', '--git-dir']);
        return $r['rc'] === 0;
    }

    /**
     * R-15 (#211): guarantee a usable repository, repairing a corrupted one in place.
     * `git init` on an existing ~/.git recreates the missing HEAD/config/refs and never
     * touches the object store or the working tree, so the next commit re-establishes the
     * backup from the current files. The lost commit history is unrecoverable, but no
     * backed-up file is ever at risk. Returns false only if `git init` itself fails.
     */
    private static function ensureRepo(string $home): bool {
        if (self::repoValid($home)) return true;
        $broken = is_dir("$home/.git"); // a .git that exists but is unusable → repair, not first-init
        $r = self::git(['init', '-b', self::BRANCH]);
        if ($r['rc'] !== 0) $r = self::git(['init']); // older git without -b
        if ($r['rc'] !== 0) {
            LogService::log('hub git: could not (re)initialise the backup repository: ' . $r['err'],
                LogService::LOG_ERROR, 'GitHomeService');
            return false;
        }
        self::configureSecretFilter();
        self::writeGitAttributes($home);
        if ($broken) {
            LogService::log('hub git: re-initialised a corrupted backup repository in place '
                . '(HEAD/config were missing; history reset, backed-up files intact) — #211',
                LogService::LOG_WARN, 'GitHomeService');
        }
        return self::repoValid($home);
    }

    /** R-14 (#211): where the last commit failure is recorded for status() to surface. */
    private static function failureMarker(): string {
        $user = preg_replace('/[^a-zA-Z0-9_-]/', '_', self::user());
        $stateRoot = \AICliAgents\Services\SecretPaths::stateRoot();
        @mkdir($stateRoot, 0755, true);
        return "$stateRoot/hub_git_error_{$user}";
    }

    /**
     * R-14 (#211): record a commit failure AND return it, so every failing path in
     * lockedCommit() is one `return self::fail(...)`. Before this, a failure was returned
     * to a caller that discarded it (commitIfEnabled() is void), so the backup could be
     * dead for days while status() still reported enabled/healthy.
     */
    private static function fail(string $message): array {
        @file_put_contents(self::failureMarker(), json_encode(['message' => $message, 'ts' => time()]));
        LogService::log('hub git: commit FAILED — ' . $message, LogService::LOG_WARN, 'GitHomeService');
        return ['status' => 'error', 'message' => $message];
    }

    /** R-14: clear the recorded failure once a commit (or a clean no-op) succeeds. */
    private static function clearFailure(): void {
        @unlink(self::failureMarker());
    }

    /** R-14: the recorded failure, or null. @return array{message:string,ts:int}|null */
    public static function lastFailure(): ?array {
        $raw = @file_get_contents(self::failureMarker());
        if ($raw === false || $raw === '') return null;
        $d = json_decode($raw, true);
        if (!is_array($d) || !isset($d['message'])) return null;
        return ['message' => (string)$d['message'], 'ts' => (int)($d['ts'] ?? 0)];
    }

    private static function lockedCommit(string $subject, string $body = ''): array {
        $fp = @fopen(self::lockFile(), 'w+');
        if (!$fp) return ['status' => 'error', 'message' => 'cannot open interlock file'];
        $got = false;
        for ($i = 0; $i < 10; $i++) { // ~1 s of patience
            if (flock($fp, LOCK_EX | LOCK_NB)) { $got = true; break; }
            usleep(100000);
        }
        if (!$got) {
            fclose($fp);
            LogService::log('hub git: commit deferred — bake interlock held', LogService::LOG_DEBUG, 'GitHomeService');
            return ['status' => 'busy', 'message' => 'a home bake is in flight — the commit will retry'];
        }
        try {
            // Refresh the deny-by-default whitelist AND the secret-filter attributes from
            // the CURRENT projector registry BEFORE staging — so newly-wired surfaces (and
            // whitelist/filter code fixes) take effect on every commit, not only at init().
            // Without this, an existing repo keeps a stale whitelist and silently never
            // backs up new agent surfaces (or leaves new MCP files unsanitized).
            $home = self::home();
            if ($home === null) return self::fail('the agent home overlay is not mounted');
            // R-15 (#211): self-heal a corrupted repository BEFORE any git work. A crash can
            // leave ~/.git with its object store intact but HEAD/config/refs gone, so git
            // reports "not a git repository" and every backup fails forever. Re-init in place
            // recreates the plumbing without touching objects or the working tree.
            if (!self::ensureRepo($home)) {
                return self::fail('git backup repository is missing and could not be re-initialised');
            }
            self::snapshotPluginSettings($home); // curated /boot settings -> ~/.aicli/plugin-backup
            self::writeGitignore($home);
            self::configureSecretFilter();
            self::writeGitAttributes($home);
            // R-13 (#211): drop any gitlink (mode 160000) a previous `add -A` recorded.
            // They hold no content and exist only to make git recurse into a nested repo.
            // Idempotent — a no-op once the index is clean.
            self::purgeGitlinks();

            // R-11 (#211): stage ONLY the whitelisted pathspecs. `git add -A` swept the
            // whole home, recording every nested git repo as a gitlink and then failing
            // when git could not read one of them.
            $specs = self::stageablePathspecs($home);
            if (!empty($specs)) {
                $add = self::git(array_merge(['add', '-A', '--'], $specs));
                if ($add['rc'] !== 0) return self::fail('git add failed: ' . $add['err']);
                self::unstageMcpStoreWithRawSecrets(); // #590
            }
            // R-11 (#211): ask whether anything is STAGED, not whether the whole tree is
            // clean. Now that the nested-repo gitlinks are gone (R-13) those directories
            // are untracked, and the managed ignore re-includes directories, so a
            // whole-tree `status --porcelain` is permanently non-empty. Testing it would
            // make every run attempt an empty commit and then report itself unhealthy.
            // `diff --cached --quiet`: rc 0 = nothing staged, 1 = something staged.
            $staged = self::git(['diff', '--cached', '--quiet', '--ignore-submodules=all']);
            if ($staged['rc'] === 0) {
                self::clearFailure();
                return ['status' => 'ok', 'committed' => false, 'message' => 'nothing to commit'];
            }
            // R-14: anything other than 0/1 is a real fault, not "nothing to do".
            if ($staged['rc'] !== 1) return self::fail('git diff --cached failed: ' . $staged['err']);
            $msg = $subject . ($body !== '' ? "\n\n" . $body : '');
            $r = self::git(['commit', '-m', $msg]);
            if ($r['rc'] !== 0) return self::fail('git commit failed: ' . $r['err']);
            LogService::log("hub git: commit '" . $subject . "'", LogService::LOG_INFO, 'GitHomeService');
            self::clearFailure();
            return ['status' => 'ok', 'committed' => true];
        } finally {
            flock($fp, LOCK_UN);
            fclose($fp);
        }
    }

    // ------------------------------------------------------------------
    // history / diff / restore
    // ------------------------------------------------------------------

    /** Last $limit commits, newest first, each with its touched-file list. */
    public static function log(int $limit = 20): array {
        if (!self::initialized()) return ['status' => 'error', 'message' => 'git layer not initialized'];
        $limit = max(1, min(50, $limit));
        $r = self::git(['log', "-$limit", '--name-only', '--pretty=format:%x01%H%x1f%h%x1f%ct%x1f%s']);
        if ($r['rc'] !== 0) return ['status' => 'error', 'message' => 'git log failed: ' . $r['err']];
        $commits = [];
        foreach (array_filter(explode("\x01", $r['out'])) as $rec) {
            $lines = explode("\n", trim($rec));
            $f = explode("\x1f", array_shift($lines));
            if (count($f) !== 4) continue;
            $commits[] = [
                'hash' => $f[0], 'short' => $f[1], 'ts' => (int)$f[2], 'subject' => $f[3],
                'files' => array_values(array_filter(array_map('trim', $lines))),
            ];
        }
        return ['status' => 'ok', 'commits' => $commits];
    }

    /**
     * Diff of a single file: CURRENT working tree vs its content at $ref
     * (i.e. the restore preview — what Restore would change back). Output is
     * size-capped; the UI renders it in an escaped <pre>.
     */
    public static function diffFile(string $path, string $ref): array {
        $err = self::validatePathRef($path, $ref);
        if ($err !== null) return ['status' => 'error', 'message' => $err];
        if (!self::initialized()) return ['status' => 'error', 'message' => 'git layer not initialized'];
        $r = self::git(['diff', '--no-ext-diff', '--no-textconv', $ref, '--', $path]); // #643: no program from a driver
        if ($r['rc'] !== 0 && $r['rc'] !== 1) { // diff exits 1 with differences under some configs
            return ['status' => 'error', 'message' => 'git diff failed: ' . $r['err']];
        }
        $diff = $r['out'];
        if (strlen($diff) > 262144) $diff = substr($diff, 0, 262144) . "\n… (diff truncated at 256 KB)";
        return ['status' => 'ok', 'diff' => $diff, 'identical' => $diff === ''];
    }

    /**
     * Restore one file from a past commit: checkout the single path, then
     * auto-commit "hub: restore <path> from <short-ref>" so the restore itself
     * is in history (and undoable). Guards: the path must be inside the
     * whitelist (i.e. NOT gitignored — otherwise this endpoint would be a
     * write-to-arbitrary-home-path primitive) and must exist at $ref.
     */
    public static function restoreFile(string $path, string $ref): array {
        $err = self::validatePathRef($path, $ref);
        if ($err !== null) return ['status' => 'error', 'message' => $err];
        if (!self::initialized()) return ['status' => 'error', 'message' => 'git layer not initialized'];

        // Whitelist guard: check-ignore rc 0 == ignored == NOT restorable.
        $ig = self::git(['check-ignore', '-q', '--', $path]);
        if ($ig['rc'] === 0) {
            return ['status' => 'error', 'message' => "refusing to restore '$path' — outside the backup whitelist"];
        }
        $exists = self::git(['cat-file', '-e', "$ref:$path"]);
        if ($exists['rc'] !== 0) {
            return ['status' => 'error', 'message' => "'$path' does not exist at $ref"];
        }

        $fp = @fopen(self::lockFile(), 'w+');
        if (!$fp) return ['status' => 'error', 'message' => 'cannot open interlock file'];
        if (!flock($fp, LOCK_EX | LOCK_NB)) {
            fclose($fp);
            return ['status' => 'busy', 'message' => 'a home bake is in flight — retry shortly'];
        }
        try {
            // #644: an edit made inside the auto-commit delay is not in history yet, and the
            // checkout below would discard it. Save it as its own commit first, so the
            // restore stays undoable.
            self::git(['add', '-A', '--', $path]);
            if (self::git(['diff', '--cached', '--quiet', '--', $path])['rc'] === 1) {
                $s = self::git(['commit', '-m', "hub: save pending edits to $path before restore", '--', $path]);
                if ($s['rc'] !== 0) return ['status' => 'error', 'message' => 'could not save your pending edits before the restore: ' . $s['err']];
            }
            $co = self::git(['checkout', $ref, '--', $path]);
            if ($co['rc'] !== 0) return ['status' => 'error', 'message' => 'git checkout failed: ' . $co['err']];
            $short = substr($ref, 0, 12);
            self::git(['add', '-A', '--', $path]);
            // Decide on THIS path only. The whole-tree status is rarely empty, so a restore of
            // identical content (nothing staged) used to reach `git commit` and fail.
            if (self::git(['diff', '--cached', '--quiet', '--', $path])['rc'] === 1) {
                $c = self::git(['commit', '-m', "hub: restore $path from $short", '--', $path]);
                if ($c['rc'] !== 0) return ['status' => 'error', 'message' => 'restored but commit failed: ' . $c['err']];
            }
            self::fixOwnership(rtrim((string)self::home(), '/') . '/' . $path);
            LogService::log("hub git: restored $path from $short", LogService::LOG_INFO, 'GitHomeService');
            return ['status' => 'ok'];
        } finally {
            flock($fp, LOCK_UN);
            fclose($fp);
        }
    }

    // ------------------------------------------------------------------
    // remote (explicit push only — never automatic)
    // ------------------------------------------------------------------

    /**
     * Set (or replace) the origin remote. http:// and https:// are both accepted
     * (http for trusted LAN git servers — see the cleartext caveat below). URLs with
     * embedded userinfo (user:pass@host) are refused on EITHER scheme: the token is
     * injected at push/pull time via GIT_ASKPASS env, never written into the URL (which
     * would land in plaintext in .git/config on disk). The two failure modes are
     * reported distinctly so an http URL isn't mislabelled an "embedded credentials"
     * error.
     */
    public static function setRemote(string $url): array {
        if (!self::initialized()) return ['status' => 'error', 'message' => 'git layer not initialized'];
        $url = trim($url);
        // Embedded credentials — refused on both schemes (the PAT is supplied via
        // GIT_ASKPASS, so it must NOT be in the URL). Reported separately from the
        // scheme check so the message is accurate.
        if (strpos($url, '@') !== false) {
            return ['status' => 'error', 'message' => 'remove the credentials from the URL — your token is added automatically and securely at push time (via GIT_ASKPASS), so the URL must be the bare repo address with no user:token@ part'];
        }
        if (!preg_match('#^https?://[A-Za-z0-9._~:/?\#\[\]!$&\'()*+,;=%-]+$#D', $url)) {
            return ['status' => 'error', 'message' => 'remote must be an http:// or https:// URL'];
        }
        $insecure = (strncmp($url, 'http://', 7) === 0);
        self::git(['remote', 'remove', 'origin']); // idempotent — ignore failure
        $r = self::git(['remote', 'add', 'origin', $url]);
        if ($r['rc'] !== 0) return ['status' => 'error', 'message' => 'remote add failed: ' . $r['err']];
        LogService::log('hub git: remote origin set (' . ($insecure ? 'http' : 'https') . ')', LogService::LOG_INFO, 'GitHomeService');
        // `insecure` lets the UI warn that an http remote sends the token in cleartext.
        return ['status' => 'ok', 'insecure' => $insecure];
    }

    /** Explicit push (UI button only — auto-push is deliberately not a thing). */
    public static function push(): array {
        return self::remoteOp(['push', '-u', 'origin', self::BRANCH]);
    }

    /** Fast-forward-only pull (service-level capability; no auto consumer). */
    public static function pull(): array {
        return self::remoteOp(['pull', '--ff-only', 'origin', self::BRANCH]);
    }

    private static function remoteOp(array $args): array {
        if (!self::initialized()) return ['status' => 'error', 'message' => 'git layer not initialized'];
        $remote = self::git(['remote', 'get-url', 'origin']);
        if ($remote['rc'] !== 0) return ['status' => 'error', 'message' => 'no remote configured — set a remote URL first'];
        $token = (string)(SecretService::getAgentSecrets()[self::TOKEN_KEY] ?? '');
        if ($token === '') {
            return ['status' => 'error', 'message' => 'no ' . self::TOKEN_KEY . ' in the secrets vault — save a token first'];
        }
        $askpass = self::askpassPath();
        if (!is_file($askpass)) return ['status' => 'error', 'message' => 'git-askpass helper missing'];
        @chmod($askpass, 0755);
        $r = self::git($args, [
            'GIT_ASKPASS' => $askpass,
            'GIT_TERMINAL_PROMPT' => '0',
            'AICLI_GIT_PAT' => $token,      // env-only — never argv, never disk
        ], 120);
        if ($r['rc'] !== 0) {
            // stderr may quote the URL but never the PAT (askpass-fed).
            return ['status' => 'error', 'message' => 'git ' . $args[0] . ' failed: ' . $r['err']];
        }
        LogService::log('hub git: ' . $args[0] . ' origin/' . self::BRANCH . ' ok', LogService::LOG_INFO, 'GitHomeService');
        return ['status' => 'ok', 'output' => $r['out'] !== '' ? $r['out'] : $r['err']];
    }

    private static function askpassPath(): string {
        // src/includes/services/hub → up 3 = src (works deployed and in-repo).
        return dirname(__DIR__, 3) . '/scripts/user/git-askpass.sh';
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    /** Commit-message hygiene: strip control chars, collapse, cap length. */
    private static function sanitizeMessage(string $msg): string {
        $msg = preg_replace('/[\x00-\x1f\x7f]+/', ' ', $msg);
        $msg = trim(preg_replace('/\s{2,}/', ' ', (string)$msg));
        if ($msg === '') $msg = 'hub: update';
        return strlen($msg) > 200 ? substr($msg, 0, 197) . '…' : $msg;
    }

    /** Repo-relative path + ref validation shared by diff/restore. */
    private static function validatePathRef(string $path, string $ref): ?string {
        if ($path === '' || $path[0] === '/' || $path[0] === '-' || strpos($path, '..') !== false
            || !preg_match('#^[A-Za-z0-9._/ -]{1,256}$#D', $path)) {
            return 'invalid path';
        }
        if (!preg_match('/^[0-9a-f]{4,40}$/iD', $ref) && $ref !== 'HEAD') {
            return 'invalid ref (commit hash or HEAD)';
        }
        return null;
    }

    /**
     * The web ctx runs as root but the home may belong to the session user —
     * chown what we created so the user's own git/agents keep working. Mirrors
     * VendorProjector::fixOwnership. Best-effort, never fatal.
     */
    private static function fixOwnership(string $target): void {
        $home = self::home();
        if ($home === null) return;
        $st = @stat($home);
        if (!is_array($st) || (int)$st['uid'] === 0) return;
        $uid = (int)$st['uid']; $gid = (int)$st['gid'];
        foreach (["$home/.git", "$home/.gitignore"] as $p) {
            if (!file_exists($p)) continue;
            self::chownRecursive($p, $uid, $gid);
        }
        if ($target !== $home && file_exists($target)) @chown($target, $uid);
    }

    private static function chownRecursive(string $path, int $uid, int $gid): void {
        @chown($path, $uid); @chgrp($path, $gid);
        if (!is_dir($path) || is_link($path)) return;
        foreach (scandir($path) ?: [] as $f) {
            if ($f === '.' || $f === '..') continue;
            self::chownRecursive("$path/$f", $uid, $gid);
        }
    }
}
