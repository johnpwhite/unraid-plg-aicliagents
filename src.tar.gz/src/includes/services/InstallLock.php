<?php
/**
 * <module_context>
 *     <name>InstallLock</name>
 *     <description>#150: a global, cross-process lock that serializes agent
 *     installs. Each upgrade spawns its own install-bg.php, and each install's
 *     layer consolidation writes to the USB flash. Running several at once hammers
 *     a slow flash — observed on Tower: dstate backpressure, deferred agent-home
 *     mounts (bake_lock_held), and the shfs-wedge-watch tripping. This lock makes
 *     the heavy npm-fetch + flash-consolidation phase run one-at-a-time; the rest
 *     queue behind it (the UI already shows an "upgrading" chip). Non-blocking
 *     flock in a poll loop with a deadline — NEVER a bare blocking flock — so a
 *     wedged holder can never hang every other install forever.</description>
 *     <dependencies>none</dependencies>
 *     <constraints>Lock file lives on tmpfs (/tmp), not flash — the lock itself
 *     must never add flash writes.</constraints>
 * </module_context>
 */

namespace AICliAgents\Services;

class InstallLock
{
    /** The global install lock: under the state root (the sandbox under test). */
    public static function defaultLockFile(): string { return SecretPaths::stateRoot() . '/install-global.lock'; }

    /**
     * Acquire the global install lock (non-blocking poll). Keep the returned file
     * handle referenced for the whole critical section — the lock releases on
     * release()/fclose or when the process exits (so a crashed holder never wedges
     * the queue). If the lock can't be taken within $deadlineSec we return
     * held=false and queued=true; the caller must stop this install rather than
     * write to flash beside the holder. $onWait fires the first
     * time we have to queue, then again every $repeatSec seconds, so the caller can
     * keep its tray row fresh while it waits (#619: one call let a healthy queued
     * install show as stalled after 2 minutes and failed after 20).
     *
     * @return array{fh:?resource, held:bool, queued:bool}
     */
    public static function acquire(?callable $onWait = null, int $deadlineSec = 1500, ?string $lockFile = null, int $pollUs = 400000, int $repeatSec = 30): array
    {
        $lockFile = $lockFile ?? self::defaultLockFile();
        @mkdir(dirname($lockFile), 0755, true);
        $fh = @fopen($lockFile, 'c');
        if (!$fh) return ['fh' => null, 'held' => false, 'queued' => false];

        $deadline = time() + max(1, $deadlineSec);
        $queued = false;
        $nextWait = 0;
        while (true) {
            if (@flock($fh, LOCK_EX | LOCK_NB)) {
                return ['fh' => $fh, 'held' => true, 'queued' => $queued];
            }
            $queued = true;
            if ($onWait && time() >= $nextWait) {
                try { $onWait(); } catch (\Throwable $e) { /* status update is best-effort */ }
                $nextWait = time() + max(1, $repeatSec);
            }
            if (time() >= $deadline) {
                // Return control so the caller can fail this install safely.
                return ['fh' => $fh, 'held' => false, 'queued' => $queued];
            }
            usleep($pollUs);
        }
    }

    /** A queued install that reached its deadline must not enter the write phase. */
    public static function timedOutWaiting(array $lock): bool
    {
        return !empty($lock['queued']) && empty($lock['held']);
    }

    /** Release a lock returned by acquire(). Safe to call with a non-held/failed result. */
    public static function release(array $lock): void
    {
        $fh = $lock['fh'] ?? null;
        if (is_resource($fh)) {
            @flock($fh, LOCK_UN);
            @fclose($fh);
        }
    }
}
