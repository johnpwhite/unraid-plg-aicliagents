<?php
/**
 * <module_context>
 *     <name>StorageMountService</name>
 *     <description>Mounting and lifecycle management for AICliAgents storage.</description>
 *     <dependencies>LogService, ConfigService</dependencies>
 *     <constraints>Under 150 lines. Manages SquashFS + OverlayFS stacks.</constraints>
 * </module_context>
 */

namespace AICliAgents\Services;

class StorageMountService {
    const AGENT_MNT_BASE = "/usr/local/emhttp/plugins/unraid-aicliagents/agents";
    const MIGRATION_LOCK = "/tmp/unraid-aicliagents/migration.lock";
    const EMERGENCY_FLAG = "/tmp/unraid-aicliagents/.emergency_mode";
    const EMERGENCY_HOME = "/tmp/unraid-aicliagents/emergency_home";

    public static function isMigrationInProgress() {
        return file_exists(self::MIGRATION_LOCK);
    }

    public static function isEmergencyMode() {
        return file_exists(self::EMERGENCY_FLAG);
    }

    /** Runtime check: is this path usable right now? */
    public static function isPathAvailable(string $path): bool {
        if (empty($path)) return false;
        // For /mnt/user/ paths, the directory can exist on tmpfs even when the array is stopped.
        // mkdir/writes succeed but data goes to RAM and is lost. Check if shfs is actually mounted.
        if (preg_match('#^/mnt/user0?(/|$)#', $path)) {
            $mounts = @file_get_contents('/proc/mounts') ?: '';
            if (strpos($mounts, 'shfs /mnt/user') === false) return false;
        }
        // For /mnt/disk* paths (individual array disks), check if the specific disk is mounted
        if (preg_match('#^/mnt/(disk\d+)(/|$)#', $path, $m)) {
            $mounts = $mounts ?? (@file_get_contents('/proc/mounts') ?: '');
            if (strpos($mounts, " /mnt/{$m[1]} ") === false) return false;
        }
        return is_dir($path) && is_readable($path);
    }

    /**
     * Classify a path by storage type. Delegates to classify-path.sh (single source of truth).
     * Returns: 'flash' | 'array' | 'pool:<name>' | 'unassigned' | 'ram' | 'unknown'
     */
    public static function classifyPath(string $path): string {
        if (empty($path)) return 'unknown';
        $script = "/usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/storage/classify-path.sh";
        if (!file_exists($script)) {
            // Fallback: basic classification without disks.ini pool detection
            if (strpos($path, '/boot/') === 0 || $path === '/boot') return 'flash';
            if (strpos($path, '/tmp/') === 0 || $path === '/tmp') return 'ram';
            if (preg_match('#^/mnt/(user0?|disk\d+)(/|$)#', $path)) return 'array';
            if (preg_match('#^/mnt/(disks|remotes)(/|$)#', $path)) return 'unassigned';
            return 'unknown';
        }
        $result = trim((string)shell_exec("bash " . escapeshellarg($script) . " " . escapeshellarg($path) . " 2>/dev/null"));
        return !empty($result) ? $result : 'unknown';
    }

    /** Does this path depend on the Unraid array or a pool? */
    public static function isArrayDependent(string $path): bool {
        $class = self::classifyPath($path);
        return ($class === 'array' || strpos($class, 'pool:') === 0);
    }

    /** Legacy stubs. OverlayFS is always writable via ZRAM. */
    public static function lock() { return true; }
    public static function unlock() { return true; }

    /**
     * Ensures the agent binary storage is mounted for a specific agent.
     *
     * Mounts are only considered healthy if the registered binary path is actually
     * readable through the mount. Overlay mounts can end up in a "phantom" state
     * where /proc/mounts shows them as active but the SquashFS lowerdir has been
     * unmounted/replaced (e.g., after an agent upgrade swaps in a new .sqsh). In
     * that state only the ZRAM upper-layer files are visible — the binary is
     * gone and launches fail with MODULE_NOT_FOUND. We detect this, lazy-unmount
     * the phantom, and fall through to rebuild the stack cleanly.
     */
    public static function ensureAgentMounted($agentId) {
        if (self::isMigrationInProgress()) return false;

        $mnt = self::AGENT_MNT_BASE . "/$agentId";

        if (self::isMounted($mnt)) {
            if (self::isAgentMountHealthy($agentId)) return true;
            LogService::log("Stale agent mount detected for '$agentId' (binary missing under healthy-looking overlay). Unmounting to rebuild.", LogService::LOG_WARN, "StorageMountService");
            // nosemgrep: php.lang.security.exec-use.exec-use
            @shell_exec("umount -l " . escapeshellarg($mnt) . " 2>&1");
            // fall through to remount via mount_stack.sh below
        }

        $persistPath = StoragePathResolver::agentPersistPath();

        if (!self::isPathAvailable($persistPath)) {
            LogService::log("Agent mount skipped: storage path $persistPath is not accessible.", LogService::LOG_WARN, "StorageMountService");
            return false;
        }

        LogService::log("Mounting Agent Stack: $agentId", LogService::LOG_INFO, "StorageMountService");

        $script = "/usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/storage/mount_stack.sh";
        // nosemgrep: php.lang.security.exec-use.exec-use
        exec("bash " . escapeshellarg($script) . " agent " . escapeshellarg($agentId) . " " . escapeshellarg($persistPath) . " 2>&1", $out, $res);

        if ($res !== 0) {
            LogService::log("Mount script FAILED for agent $agentId: " . implode("\n", $out), LogService::LOG_ERROR, "StorageMountService");
        }

        return ($res === 0);
    }

    /**
     * Ensures the user home storage is mounted.
     *
     * Mirrors the agent-mount health-check pattern: verifies the path is
     * genuinely an overlay mount (not a phantom proc entry), and serializes
     * concurrent callers with a per-user flock so two simultaneous PHP
     * requests cannot both invoke mount_stack.sh.
     */
    public static function ensureHomeMounted($user) {
        if (self::isMigrationInProgress()) return false;

        $workDir = UtilityService::getWorkDir($user);
        $mnt = "$workDir/home";

        // Emergency mode: home is a symlink to the temp RAM dir — treat as mounted
        if (is_link($mnt) && self::isEmergencyMode()) return true;

        // Fast path: already a healthy overlay mount
        if (self::isMounted($mnt) && self::isHomeMountHealthy($user)) return true;

        // Serialize concurrent mounts for the same user with an advisory lock.
        // Losers block until the winner finishes, then re-check before mounting.
        $safeUser = preg_replace('/[^a-zA-Z0-9_.-]/', '_', $user) ?: 'unknown';
        $lockFile = "/tmp/unraid-aicliagents/home_mount_{$safeUser}.lock";
        $lock = @fopen($lockFile, 'c');
        if ($lock !== false) {
            flock($lock, LOCK_EX);
            if (self::isMounted($mnt) && self::isHomeMountHealthy($user)) {
                flock($lock, LOCK_UN);
                fclose($lock);
                return true;
            }
        }

        $persistPath = StoragePathResolver::homePersistPath($user);

        if (!self::isPathAvailable($persistPath)) {
            LogService::log("Home mount skipped: storage path $persistPath is not accessible.", LogService::LOG_WARN, "StorageMountService");
            if ($lock !== false) { flock($lock, LOCK_UN); fclose($lock); }
            return false;
        }

        // Phantom mount: stale /proc/mounts entry but not a healthy overlay.
        // Lazy-unmount to clear it, then reassemble the stack cleanly.
        if (self::isMounted($mnt)) {
            LogService::log("Stale home mount detected for '$user' (not a healthy overlay). Unmounting to rebuild.", LogService::LOG_WARN, "StorageMountService");
            // nosemgrep: php.lang.security.exec-use.exec-use
            @shell_exec("umount -l " . escapeshellarg($mnt) . " 2>&1");
        }

        LogService::log("Mounting Home Stack for $user", LogService::LOG_INFO, "StorageMountService");

        $script = "/usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/storage/mount_stack.sh";
        // nosemgrep: php.lang.security.exec-use.exec-use
        exec("bash " . escapeshellarg($script) . " home " . escapeshellarg($user) . " " . escapeshellarg($persistPath) . " 2>&1", $out, $res);

        if ($res !== 0) {
            LogService::log("Mount script FAILED for home $user: " . implode("\n", $out), LogService::LOG_ERROR, "StorageMountService");
        }

        if ($lock !== false) { flock($lock, LOCK_UN); fclose($lock); }
        return ($res === 0);
    }

    /**
     * Verifies the home overlay mount is genuinely an OverlayFS, not a phantom
     * proc entry. A healthy home mount reads "overlay <mnt> overlay ..." in /proc/mounts.
     */
    public static function isHomeMountHealthy(string $user): bool {
        $mnt = rtrim(UtilityService::getWorkDir($user) . "/home", '/');
        $mounts = file_exists('/proc/mounts') ? (string)file_get_contents('/proc/mounts') : '';
        return (bool)preg_match("#^overlay\s+" . preg_quote($mnt, '#') . "\s+overlay\b#m", $mounts);
    }

    /**
     * Forcefully unmounts a path.
     */
    public static function unmount($path) {
        if (empty($path)) return false;
        $path = rtrim($path, '/');
        if (!self::isMounted($path)) return true;
        
        LogService::log("Unmounting $path...", LogService::LOG_DEBUG, "StorageMountService");
        exec("umount -l " . escapeshellarg($path) . " 2>&1", $out, $res);
        return ($res === 0);
    }

    /**
     * Checks if a generic path is mounted.
     */
    public static function isMounted($path) {
        if (empty($path)) return false;
        $path = rtrim($path, '/');
        $mounts = file_exists('/proc/mounts') ? file_get_contents('/proc/mounts') : '';
        // D-324: Exact path match to prevent matching /agents when checking /agents/gh-copilot
        return (preg_match("#\s" . preg_quote($path) . "\s#", $mounts) === 1);
    }

    /**
     * Verifies an agent's overlay mount actually exposes the registered binary.
     * Used by ensureAgentMounted() to detect "phantom mount" states where the
     * overlay is present but its SquashFS lowerdir has been unmounted — only
     * ZRAM upper-layer files are visible and the binary is missing.
     */
    public static function isAgentMountHealthy(string $agentId): bool {
        $registry = function_exists('getAICliAgentsRegistry') ? getAICliAgentsRegistry() : [];
        $bin = $registry[$agentId]['binary'] ?? '';
        $fallback = $registry[$agentId]['binary_fallback'] ?? '';
        if (empty($bin) && empty($fallback)) return true; // nothing to check
        if ($bin && is_file($bin)) return true;
        if ($fallback && is_file($fallback)) return true;
        return false;
    }

    /**
     * Commits changes from ZRAM to SquashFS.
     *
     * For $type === 'home': delta bake via commit_stack.sh + post-bake threshold
     * auto-consolidate (the historic behaviour — home is a delta-stack).
     *
     * For $type === 'agent' (WP #748 J, 2026-05-13): routes directly to
     * consolidate(), which bakes the merged mount view (the just-installed
     * package) as a single fresh `_consolidated_` layer, atomically replaces
     * the layer set, and remounts with a single lowerdir. One layer per agent,
     * no delta accumulation, no later consolidate. See
     * docs/specs/STORAGE_DURABILITY_SUPERVISOR.md §"Agent storage — single
     * layer, always persisted".
     *
     * Returns the exit code: 0=Success, 1=Fail, 2=Busy(Baked but RAM not cleared).
     */
    public static function commitChanges($type, $id) {
        // WP #748 J — agents always collapse to a single layer on every install
        // /upgrade. Bypass commit_stack.sh's delta path entirely.
        if ($type === 'agent') {
            return self::consolidate($type, $id) ? 0 : 1;
        }

        $persistPath = ($type === 'home')
            ? StoragePathResolver::homePersistPath($id)
            : StoragePathResolver::agentPersistPath();

        // Don't attempt bake if the persist path is unavailable
        if (!self::isPathAvailable($persistPath)) {
            LogService::log("Persist skipped for $type $id: storage path $persistPath not accessible.", LogService::LOG_WARN, "StorageMountService");
            return 1;
        }

        $script = "/usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/storage/commit_stack.sh";

        $upperDir = StoragePathResolver::zramUpper($type, $id);
        $dirtyMB = 0;
        if (is_dir($upperDir)) {
            $io = shell_exec("du -sm " . escapeshellarg($upperDir) . " 2>/dev/null | cut -f1");
            $dirtyMB = (int)trim((string)$io);
        }

        LogService::log("Initiating SquashFS persistence bake for $type $id ($dirtyMB MB dirty)...", LogService::LOG_INFO, "StorageMountService");
        LifecycleLogService::log(LifecycleLogService::LEVEL_INFO, 'StorageMountService', 'bake_start', ['type' => $type, 'id' => $id, 'dirty_mb' => $dirtyMB, 'persist_path' => $persistPath]);
        // nosemgrep: php.lang.security.exec-use.exec-use
        exec("bash " . escapeshellarg($script) . " " . escapeshellarg($type) . " " . escapeshellarg($id) . " " . escapeshellarg($persistPath), $out, $res);

        if ($res === 0) {
            LogService::log("Successfully persisted $dirtyMB MB of RAM storage to Flash disk for $type $id.", LogService::LOG_INFO, "StorageMountService");
            LifecycleLogService::log(LifecycleLogService::LEVEL_INFO, 'StorageMountService', 'bake_ok', ['type' => $type, 'id' => $id, 'dirty_mb' => $dirtyMB, 'result' => 0]);
        } elseif ($res === 2) {
            LogService::log("Successfully backed up $dirtyMB MB to Flash for $id, but RAM flush deferred due to active session.", LogService::LOG_INFO, "StorageMountService");
            LifecycleLogService::log(LifecycleLogService::LEVEL_INFO, 'StorageMountService', 'bake_deferred_busy', ['type' => $type, 'id' => $id, 'dirty_mb' => $dirtyMB]);
        } else {
            LogService::log("FAILED SquashFS persistence bake for $type $id. Check commit_stack.sh output.", LogService::LOG_ERROR, "StorageMountService");
            LifecycleLogService::log(LifecycleLogService::LEVEL_ERROR, 'StorageMountService', 'bake_failed', ['type' => $type, 'id' => $id, 'result' => $res]);
        }

        // Phase 1: Write manifest entry after a successful or busy-but-baked commit.
        // Silent on failure — manifest writes are instrumentation, not load-bearing yet.
        if ($res === 0 || $res === 2) {
            $entity = "$type/$id";
            $sqshFiles = glob("$persistPath/{$type}_{$id}_*.sqsh") ?: [];
            if (!empty($sqshFiles)) {
                usort($sqshFiles, static fn($a, $b) => filemtime($b) <=> filemtime($a));
                $newest = $sqshFiles[0];
                $sha256 = LayerManifestService::computeFileSha256($newest);
                LayerManifestService::addLayer($entity, [
                    'filename'     => basename($newest),
                    'sha256'       => $sha256 ?? '',
                    'bytes'        => (int)filesize($newest),
                    'kind'         => 'delta',
                    'created_at'   => date('Y-m-d\TH:i:s\Z'),
                    'persist_path' => $persistPath,
                ]);
            }
        }

        // D-404: Auto-consolidate when layer count exceeds threshold to prevent loop
        // device exhaustion. Fire on both $res === 0 (clean commit + ZRAM flush) AND
        // $res === 2 (baked-but-busy: delta .sqsh was still created, so it still
        // counts toward the total). Previously we only fired on $res === 0 — but
        // the home stack is almost always busy (ttyd + tmux + agent hold fds on
        // the mount), so deltas piled up forever. consolidate_layers.sh uses
        // umount -l (lazy) so it's safe to run while sessions are open; the
        // script itself documents the transient I/O as expected.
        //
        // WP #268: previously the busy threshold was 15 to avoid a visible
        // remount during active use, but the home stack is permanently busy
        // (ttyd + tmux + agents), so deltas piled up to ~7-8 before users
        // noticed. Lowered to 5 to match idle — users see slightly more
        // remounts during sustained activity but Flash wear stays bounded.
        //
        // WP #748 J: home-only. Agents never reach this code path (the agent
        // branch at the top returns early via consolidate()), but the explicit
        // type guard documents the invariant: under J, agents collapse to one
        // layer per install — no layer-count-driven consolidate ever applies.
        if ($type === 'home' && ($res === 0 || $res === 2)) {
            $layerCount = count(glob("$persistPath/{$type}_{$id}_*.sqsh"));
            $threshold = 5;
            if ($layerCount >= $threshold) {
                // WP #271 follow-up: defer consolidation if the mount is busy.
                // Earlier behaviour was to consolidate via lazy umount even with
                // active processes, which orphaned in-flight writes (the cause of
                // the workspaces / claude credentials loss reported on this box).
                // Now: if any process holds the mount, mark a pending intent and
                // run later when the mount goes idle (hooked into gracefulClose
                // and the AJAX dispatcher's lazy backstop).
                $mnt = StoragePathResolver::homeMount($id);
                if (self::isMountBusy($mnt)) {
                    self::markConsolidatePending($type, $id);
                    LogService::log("Auto-consolidation deferred for $type $id ($layerCount layers >= $threshold). Mount busy — will run when idle.", LogService::LOG_INFO, "StorageMountService");
                } else {
                    LogService::log("Auto-consolidation triggered for $type $id ($layerCount layers >= $threshold threshold, mount idle).", LogService::LOG_INFO, "StorageMountService");
                    self::consolidate($type, $id);
                }
            }
        }

        return $res;
    }


    /**
     * Consolidates layers into a single base volume.
     */
    public static function consolidate($type, $id) {
        $persistPath = ($type === 'home')
            ? StoragePathResolver::homePersistPath($id)
            : StoragePathResolver::agentPersistPath();
        $script = "/usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/storage/consolidate_layers.sh";

        $oldSize = 0;
        foreach (glob("$persistPath/{$type}_{$id}_*.sqsh") as $f) {
            $oldSize += (int)filesize($f);
        }
        $oldSizeMB = round($oldSize / 1024 / 1024, 2);

        LogService::log("Initiating layer consolidation for $type $id (Current footprint: $oldSizeMB MB)...", LogService::LOG_INFO, "StorageMountService");
        LifecycleLogService::log(LifecycleLogService::LEVEL_INFO, 'StorageMountService', 'consolidate_start', ['type' => $type, 'id' => $id, 'old_size_mb' => $oldSizeMB]);
        // nosemgrep: php.lang.security.exec-use.exec-use
        exec("bash " . escapeshellarg($script) . " " . escapeshellarg($type) . " " . escapeshellarg($id) . " " . escapeshellarg($persistPath), $out, $res);

        if ($res === 0) {
            $newSize = 0;
            $sqshAfter = glob("$persistPath/{$type}_{$id}_*.sqsh") ?: [];
            foreach ($sqshAfter as $f) {
                $newSize += (int)filesize($f);
            }
            $newSizeMB = round($newSize / 1024 / 1024, 2);
            LogService::log("Successfully consolidated storage layers for $id. Footprint changed from $oldSizeMB MB to $newSizeMB MB on Flash.", LogService::LOG_INFO, "StorageMountService");
            LifecycleLogService::log(LifecycleLogService::LEVEL_INFO, 'StorageMountService', 'consolidate_ok', ['type' => $type, 'id' => $id, 'old_mb' => $oldSizeMB, 'new_mb' => $newSizeMB]);

            // Phase 1: Replace manifest entries with the single consolidated layer
            if (!empty($sqshAfter)) {
                $consolidated = $sqshAfter[0];
                $sha256 = LayerManifestService::computeFileSha256($consolidated);
                $newLayer = [
                    'filename'   => basename($consolidated),
                    'sha256'     => $sha256 ?? '',
                    'bytes'      => (int)filesize($consolidated),
                    'kind'       => 'consolidated',
                    'created_at' => date('Y-m-d\TH:i:s\Z'),
                ];
                LayerManifestService::replaceLayers("$type/$id", [$newLayer], $persistPath);
            }
        } else {
            LogService::log("FAILED consolidation for $type $id. Check consolidate_layers.sh output.", LogService::LOG_ERROR, "StorageMountService");
            LifecycleLogService::log(LifecycleLogService::LEVEL_ERROR, 'StorageMountService', 'consolidate_failed', ['type' => $type, 'id' => $id, 'result' => $res]);
        }

        return ($res === 0);
    }

    public static function repairHomeStorage($user) {
        if (empty($user)) return false;
        LogService::log("Initiating mount repair sequence for home $user...", LogService::LOG_WARN, "StorageMountService");
        
        // For SquashFS, repair means remounting or consolidating.
        $res = self::ensureHomeMounted($user);
        if ($res) {
            LogService::log("Successfully verified and remounted storage stack for $user.", LogService::LOG_INFO, "StorageMountService");
        }
        return $res;
    }

    // -----------------------------------------------------------------------
    // Pending-consolidation queue (WP #271 follow-up)
    //
    // When auto-consolidate would fire on a busy mount, we record a marker
    // file instead of running consolidate immediately. The marker is checked
    // and (if the mount is idle) drained at three trigger points:
    //   1. gracefulClose() — a session just ended, mount activity dropped
    //   2. stopTerminal()  — manual close
    //   3. The AJAX dispatcher's lazy backstop — throttled to once per 60s
    // The UI surfaces an "Awaiting idle" badge while a marker exists.
    // -----------------------------------------------------------------------

    private const PENDING_DIR = '/tmp/unraid-aicliagents';

    /**
     * Returns true if any process holds an open fd on the mount.
     * Uses `fuser -sm` (silent, mount-points only) — same check commit_stack.sh
     * uses. A return code of 0 means at least one process is using the mount.
     * Argument is shell-escaped via escapeshellarg.
     */
    public static function isMountBusy(string $mnt): bool
    {
        if (empty($mnt) || !is_dir($mnt)) return false;
        // Append `; echo __RC=$?` so we can read the rc through shell_exec
        // (sandbox-friendly — no exec/system).
        $cmd = 'fuser -sm ' . escapeshellarg($mnt) . ' 2>/dev/null; echo __RC=$?';
        $out = (string)@shell_exec($cmd);
        if (preg_match('/__RC=(\d+)/', $out, $m)) {
            return ((int)$m[1] === 0);
        }
        return false;
    }

    public static function markConsolidatePending(string $type, string $id): void
    {
        $f = self::pendingMarkerPath($type, $id);
        @file_put_contents($f, (string)time());
        LifecycleLogService::log(LifecycleLogService::LEVEL_INFO, 'StorageMountService', 'consolidate_marker_set', ['type' => $type, 'id' => $id]);
    }

    public static function clearConsolidatePending(string $type, string $id): void
    {
        @unlink(self::pendingMarkerPath($type, $id));
        LifecycleLogService::log(LifecycleLogService::LEVEL_INFO, 'StorageMountService', 'consolidate_marker_cleared', ['type' => $type, 'id' => $id]);
    }

    /**
     * Returns the unix timestamp the consolidate was first deferred, or null
     * if no pending marker exists. The UI uses this to render a "since" hint.
     */
    public static function getConsolidatePendingSince(string $type, string $id): ?int
    {
        $f = self::pendingMarkerPath($type, $id);
        if (!file_exists($f)) return null;
        $contents = trim((string)@file_get_contents($f));
        return ctype_digit($contents) ? (int)$contents : null;
    }

    private static function pendingMarkerPath(string $type, string $id): string
    {
        // Sanitise id so it can't escape the marker directory.
        $safeId = preg_replace('/[^a-zA-Z0-9_.-]/', '_', $id) ?: 'unknown';
        return self::PENDING_DIR . "/.consolidate_pending_{$type}_{$safeId}";
    }

}
