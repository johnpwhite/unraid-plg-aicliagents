<?php
/**
 * <module_context>
 *     <name>FileStorage</name>
 *     <description>
 *         Epic #1310 — the single, authoritative filestorage management component.
 *         Consumers express WHAT they want (ensureReady / persist / release / status)
 *         and never touch files, mounts, layers or the manifest directly. All storage
 *         complexity (overlay, zram, bake, consolidate, reclaim, manifest, boot-
 *         integrity, locks, busy-arbitration, migration) is PRIVATE behind this
 *         interface (see docs/00-governance/adr/0001-single-filestorage-management-component.md).
 *
 *         STEP 1 (this commit) introduces the facade as a DARK 1:1 pass-through over
 *         the existing storagectl seam + StorageMountService — no consumer is
 *         re-pointed yet, so behaviour is unchanged. Later slices re-point consumers
 *         (Steps 3-5), add the passthrough backend (Step 6), move manifest authority
 *         into bash (Step 7), and bound migration to two triggers (Step 8).
 *     </description>
 *     <dependencies>storagectl.sh, StorageMountService, StoragePathResolver, TraceContext</dependencies>
 * </module_context>
 */

namespace AICliAgents\Services;

/**
 * Result of ensureReady(): is the entity's storage usable right now?
 * Preserves the `exit 2 = deferred` lingua franca. Most exit-2 mounts kept the
 * live overlay, so they remain usable. A path-move defer has no live mount and
 * stays deferred without being reported as a hard failure.
 */
final class FileStorageReadiness
{
    public bool $ok = false;
    public bool $deferred = false;
    public ?string $deferReason = null;
    public int $exit = 1;
    /** ready | deferred | unavailable */
    public string $state = 'unavailable';

    public static function fromExit(int $exit, ?string $deferReason): self
    {
        $r = new self();
        $r->exit = $exit;
        $r->deferReason = $deferReason;
        if ($exit === 0) {
            $r->ok = true; $r->deferred = false; $r->state = 'ready';
        } elseif ($exit === 2) {
            $r->ok = true; $r->deferred = true; $r->state = 'deferred';
        } else {
            $r->ok = false; $r->deferred = false; $r->state = 'unavailable';
        }
        return $r;
    }

    /** A transient defer can be unavailable without being a failed mount. */
    public static function unavailableDeferred(string $deferReason): self
    {
        $r = new self();
        $r->exit = 2;
        $r->deferred = true;
        $r->deferReason = $deferReason;
        $r->state = 'deferred';
        return $r;
    }
}

/**
 * L1 (WP#1333): the {ok, deferred, deferReason, exit} shape + the exit-2-decode
 * (`exit 2 = deferred = still usable`) shared by persist() and release(), which were
 * byte-identical. ONE place to thread a future exit code (e.g. exit 3 guard_reject)
 * instead of duplicate decoders. `new self()` resolves to the using class.
 */
trait FileStorageExitResultTrait
{
    public bool $ok = false;
    public bool $deferred = false;
    public ?string $deferReason = null;
    public int $exit = 1;
    /**
     * #357: the changes are on durable storage. Exit 0, or exit 2 with a reason
     * that still wrote the layer (mount_busy, busy_cooldown). An exit 2 with a
     * reason in FileStorage::NOT_SAVED_DEFER_REASONS wrote NOTHING: ok stays
     * true (the entity is usable, nothing broke) but saved is false.
     */
    public bool $saved = false;
    /**
     * #567: the save found nothing to write (the writable layer was empty). The
     * seam answers exit 0 with outcome "noop". The save did nothing, so the UI
     * must show a neutral "Nothing to save", never a green "Persisted".
     */
    public bool $nothingToSave = false;

    public static function fromExit(int $exit, ?string $deferReason): self
    {
        $r = new self();
        $r->exit = $exit;
        $r->deferReason = $deferReason;
        $r->ok = ($exit === 0 || $exit === 2);
        $r->deferred = ($exit === 2);
        $r->saved = FileStorage::bakeResultSaved($exit, $deferReason);
        return $r;
    }
}

/** Result of persist(): idempotent flush; self-defers (exit 2) when busy. */
final class FileStoragePersistResult
{
    use FileStorageExitResultTrait;
}

/** Result of release(): tear down for shutdown/close (subsumes unmount + flush). */
final class FileStorageReleaseResult
{
    use FileStorageExitResultTrait;
}

/** Result of migratePath()/migrateFormat() — lifecycle-bounded (Step 8). */
final class FileStorageMigrationResult
{
    public bool $ok = false;
    /** none | migrated | resumed | rolled_back | failed */
    public string $state = 'none';
    public ?string $error = null;

    public static function make(bool $ok, string $state, ?string $error = null): self
    {
        $r = new self();
        $r->ok = $ok; $r->state = $state; $r->error = $error;
        return $r;
    }
}

/**
 * status(entity) DTO — exactly the ADR shape, with additive fields so the
 * existing React UI keeps binding unchanged (toArray() is a SUPERSET of today's
 * aicli_get_storage_status). New UI reads supportsBake/supportsConsolidate to
 * render the Bake/Consolidate controls conditionally.
 */
final class FileStorageStatus
{
    /** ready | deferred | unavailable | halted | emergency | fresh */
    public string $state = 'unavailable';
    /** flash | passthrough — emitted by the seam (detect_backend). */
    public string $backend = 'flash';
    public bool $supportsBake = true;          // emitted by the seam
    public bool $supportsConsolidate = true;   // emitted by the seam
    public bool $supportsSideBySide = false;  // emitted for agent generation activation
    public ?array $consolidate = null;         // emitted by the seam (home status)
    public ?array $layers = null;              // emitted by the seam; flash-only, null on passthrough
    // additive (UI superset) — emitted by the seam's mount{} object
    public string $merged = '';
    public bool $mounted = false;
    // L6 (WP#1333): the ADR's eventual fields — the storagectl seam (emit_json) does
    // NOT emit these TODAY, so they always carry their defaults. Kept as the forward
    // contract but NOT parsed from the seam (parsing absent keys only produced phantom
    // nulls and a dead state='halted' branch). TODO-with-emitter: emit haltState /
    // dirtyBytes / isDurable / forceReclaim / bootIntegrity from the seam, then wire
    // the derivation here. Until then HaltService/etc. remain the halt authority.
    public bool $isDurable = true;
    public int $dirtyBytes = 0;
    public ?array $haltState = null;
    public ?array $forceReclaim = null;
    public ?array $bootIntegrity = null;

    /** Back-compat string entry point — prefer fromArray() (no encode/decode round-trip). */
    public static function fromStoragectlJson(string $json): self
    {
        $j = json_decode($json, true);
        return self::fromArray(is_array($j) ? $j : []);
    }

    /**
     * L6 (WP#1333): build from the seam's already-decoded array (status() holds the
     * decoded array, so this kills the json_encode→json_decode round-trip). Parses
     * ONLY keys the seam actually emits; the ADR's not-yet-emitted fields keep their
     * defaults (see the property block).
     * @param array<string,mixed> $j
     */
    public static function fromArray(array $j): self
    {
        $s = new self();
        // L6 (WP#1333): parse ONLY the keys the seam (emit_json) actually emits today.
        $s->backend = (string)($j['backend'] ?? 'flash');
        $s->supportsBake = array_key_exists('supportsBake', $j) ? (bool)$j['supportsBake'] : ($s->backend === 'flash');
        $s->supportsConsolidate = array_key_exists('supportsConsolidate', $j) ? (bool)$j['supportsConsolidate'] : ($s->backend === 'flash');
        $s->supportsSideBySide = array_key_exists('supportsSideBySide', $j)
            ? (bool)$j['supportsSideBySide']
            : false;

        $mount = is_array($j['mount'] ?? null) ? $j['mount'] : [];
        $s->merged = (string)($mount['merged'] ?? '');
        $s->mounted = (bool)($mount['mounted'] ?? false);

        $s->layers = (isset($j['layers']) && is_array($j['layers'])) ? $j['layers'] : null;
        $s->consolidate = is_array($j['consolidate'] ?? null) ? $j['consolidate'] : null;

        // Coarse state from the emitted keys. NOTE: halt is NOT derivable here yet —
        // the seam does not emit haltState (see the property block); HaltService is the
        // halt authority until that emitter exists (TODO-with-emitter).
        if ($s->mounted) {
            $s->state = 'ready';
        } elseif (empty($s->layers)) {
            $s->state = 'fresh';
        } else {
            $s->state = 'unavailable';
        }
        return $s;
    }

    public function toArray(): array
    {
        return [
            'state' => $this->state,
            'backend' => $this->backend,
            'isDurable' => $this->isDurable,
            'supportsBake' => $this->supportsBake,
            'supportsConsolidate' => $this->supportsConsolidate,
            'supportsSideBySide' => $this->supportsSideBySide,
            'dirtyBytes' => $this->dirtyBytes,
            'mounted' => $this->mounted,
            'merged' => $this->merged,
            'layers' => $this->layers ?? [],
            'consolidate' => $this->consolidate,
            'haltState' => $this->haltState,
            'forceReclaim' => $this->forceReclaim,
            'bootIntegrity' => $this->bootIntegrity,
        ];
    }
}

final class FileStorage
{
    /** Ignore a path-move marker after the supervisor's 30-minute freshness window. */
    public const MIGRATION_MARKER_MAX_AGE_S = 1800;
    /** Maximum time a migration waits for short home-mount shared locks. */
    public const MIGRATION_LOCK_WAIT_S = 5.0;
    private const STORAGECTL = '/usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/storage/storagectl.sh';

    /**
     * #357 (HOME_STORAGE_LIFECYCLE.md "a save that meets a non-bake lock holder"):
     * the bake defer reasons that mean NO layer was written. bake_lock_held = the
     * bake waited its limit for another storage operation (a reconcile check, a
     * consolidate swap) and gave up; sqlite_backup_deferred = a database copy was
     * locked before the layer was packed; no_space (#374, as an exit 2) = the
     * file system of the SQLite stage folder had no room for the database
     * copies, so nothing was staged. KEEP IN SYNC with
     * AICLI_NOT_SAVED_DEFER_REASONS in src/scripts/storage/common.sh.
     */
    public const NOT_SAVED_DEFER_REASONS = ['bake_lock_held', 'sqlite_backup_deferred', 'no_space'];

    /**
     * #357: does a bake result mean the changes are on durable storage? Exit 0,
     * or exit 2 with a reason that still wrote the layer. Pure.
     */
    public static function bakeResultSaved(int $exit, ?string $deferReason): bool
    {
        if ($exit === 0) return true;
        if ($exit !== 2) return false;
        return !in_array((string)$deferReason, self::NOT_SAVED_DEFER_REASONS, true);
    }

    /**
     * Parse an "type/id" entity string into ['type'=>..., 'id'=>...].
     * type ∈ {home, agent}; id is everything after the first '/'. Pure.
     * @return array{type:string,id:string}
     */
    public static function parseEntity(string $entity): array
    {
        $pos = strpos($entity, '/');
        if ($pos === false) {
            throw new \InvalidArgumentException("FileStorage entity must be 'type/id': '$entity'");
        }
        $type = substr($entity, 0, $pos);
        $id = substr($entity, $pos + 1);
        if ($type !== 'home' && $type !== 'agent') {
            throw new \InvalidArgumentException("FileStorage entity type must be home|agent: '$type'");
        }
        if ($id === '') {
            throw new \InvalidArgumentException("FileStorage entity id is empty: '$entity'");
        }
        return ['type' => $type, 'id' => $id];
    }

    /**
     * Backend capabilities for a persist PATH (genuine device test), via
     * detect_backend.sh. Returns ['backend','supportsBake','supportsConsolidate'].
     * Errs toward flash on any failure (data-safety invariant). Stable per path.
     * @return array{backend:string,supportsBake:bool,supportsConsolidate:bool}
     */
    public static function backendForPath(string $persistPath): array
    {
        // F9 (WP#1332): memoise per PHP request — the 5s UI poll resolves the same
        // path(s) every tick and the device verdict is boot-stable, so one shell_exec
        // per distinct path per request suffices (no per-entity re-probe).
        static $memo = [];
        if (array_key_exists($persistPath, $memo)) {
            return $memo[$persistPath];
        }
        $script = dirname(self::STORAGECTL) . '/detect_backend.sh';
        $backend = 'flash';
        if ($persistPath !== '' && is_file($script)) {
            // nosemgrep: php.lang.security.exec-use.exec-use
            $out = trim((string) @shell_exec('bash ' . escapeshellarg($script) . ' ' . escapeshellarg($persistPath) . ' 2>/dev/null'));
            if ($out === 'flash' || $out === 'passthrough') { $backend = $out; }
        }
        $flash = ($backend === 'flash');
        return $memo[$persistPath] = ['backend' => $backend, 'supportsBake' => $flash, 'supportsConsolidate' => $flash];
    }

    /**
     * #372 (docs/specs/HOME_STORAGE_LIFECYCLE.md "2026-09-30 — the live mount
     * wins"): the upper mode ('zram' | 'disk') for a NEW mount on this persist
     * path — the storage_backend_mode policy first, then the device test. It is
     * bash `entity_upper_mode` itself (`detect_backend.sh --upper-mode`), so PHP
     * and bash decide the mode in ONE place. A mounted entity keeps the upper the
     * kernel shows; callers read that first (StorageMountService::resolveHomeUpperPath).
     * Any failure gives 'zram' (the wear-safe answer, the same bias as bash).
     * AICLI_DETECT_BACKEND_SH: test-only script-path override.
     */
    public static function upperModeForPath(string $persistPath, string $type = ''): string
    {
        static $memo = [];
        $memoKey = $persistPath . "\0" . $type;
        if (array_key_exists($memoKey, $memo)) {
            return $memo[$memoKey];
        }
        $script = getenv('AICLI_DETECT_BACKEND_SH') ?: dirname(self::STORAGECTL) . '/detect_backend.sh';
        $mode = 'zram';
        if ($persistPath !== '' && is_file($script)) {
            // nosemgrep: php.lang.security.exec-use.exec-use
            // #456: the type ('home') lets the person's storage_upper_mode apply to homes only.
            $typeArg = preg_match('/^(home|agent)$/D', $type) === 1 ? ' ' . $type : '';
            $out = trim((string) @shell_exec('bash ' . escapeshellarg($script) . ' --upper-mode ' . escapeshellarg($persistPath) . $typeArg . ' 2>/dev/null'));
            if ($out === 'zram' || $out === 'disk') { $mode = $out; }
        }
        return $memo[$memoKey] = $mode;
    }

    /**
     * S-01 (#1351, DARK phase): full capability probe for a persist PATH via the
     * read-only `storagectl probe` verb (detect_backend.sh probe_target). Returns
     * the decoded probe JSON: {schema, path, realpath, fstype, mount_class,
     * via_user_share, durability, wear, posix, rotational, max_file_bytes,
     * engine, upper_mode, refuse, warnings[], reasons[]}. Memoised per path per
     * request (same pattern as backendForPath: the 5s UI poll resolves the same
     * path(s) every tick and the verdict is boot-stable). On ANY failure (script
     * missing, non-zero exit, undecodable/implausible JSON) returns a safe
     * fallback — engine=layering, upper_mode=zram, refuse=false, reason
     * probe_failed — the err-toward-flash bias, and never blocks a caller.
     *
     * DARK invariant: nothing routes engine decisions through this yet;
     * backendForPath above stays the live verdict (do NOT derive one from the
     * other until the S-01 switch-over phase).
     *
     * AICLI_STORAGECTL env: test-only script-path override (mirrors the
     * AICLI_MANIFEST_PATH precedent in StoragePathResolver). Honoured by
     * probeTarget AND (since S-08 #1353) the seam() verbs, so PHPUnit can stub
     * status/mount round-trips; production never sets it.
     * @return array<string,mixed>
     */
    public static function probeTarget(string $path): array
    {
        static $memo = [];
        if (array_key_exists($path, $memo)) {
            return $memo[$path];
        }
        $fallback = [
            'schema' => 1, 'path' => $path, 'realpath' => $path,
            'fstype' => '', 'mount_class' => 'other', 'via_user_share' => false,
            'durability' => 'durable', 'wear' => 'wear_sensitive', 'posix' => 'posix_none',
            'rotational' => false, 'max_file_bytes' => 0,
            'engine' => 'layering', 'upper_mode' => 'zram', 'refuse' => false,
            'warnings' => [], 'reasons' => ['probe_failed'],
        ];
        $script = getenv('AICLI_STORAGECTL') ?: self::STORAGECTL;
        if ($path === '' || !is_file($script)) {
            return $memo[$path] = $fallback;
        }
        $out = [];
        $exit = 1;
        // nosemgrep: php.lang.security.exec-use.exec-use
        exec('bash ' . escapeshellarg($script) . ' probe --persist ' . escapeshellarg($path) . ' 2>/dev/null', $out, $exit);
        $json = json_decode(implode("\n", $out), true);
        if ($exit !== 0 || !is_array($json)
            || !in_array($json['engine'] ?? '', ['layering', 'passthrough'], true)) {
            return $memo[$path] = $fallback;
        }
        return $memo[$path] = $json;
    }

    /**
     * F8 (WP#1332): the EFFECTIVE backend capabilities — the SINGLE PHP implementation
     * of the layers-stay-flash invariant, mirroring bash effective_backend_from_facts.
     * An entity that still has .sqsh layers is flash (bakeable) regardless of the
     * device verdict; only a layer-free entity adopts the device's backend. The UI
     * consumes THIS named method (not an inline re-implementation), so it can never
     * gate the Bake/Consolidate controls on a different rule than the engine.
     * backendForPath() above is the RAW DEVICE verdict (no invariant); this applies it.
     * @return array{backend:string,supportsBake:bool,supportsConsolidate:bool}
     */
    public static function effectiveBackendCaps(string $deviceBackend, bool $hasLayers): array
    {
        $eff   = $hasLayers ? 'flash' : ($deviceBackend === 'passthrough' ? 'passthrough' : 'flash');
        $flash = ($eff === 'flash');
        return ['backend' => $eff, 'supportsBake' => $flash, 'supportsConsolidate' => $flash];
    }

    /**
     * Bug #1380: the PURE graduate-OFFER rule — the PHP mirror of bash
     * graduate_offer_from_facts (detect_backend.sh). "Graduate" means MOVE THE
     * DATA OFF A USB FLASH DRIVE onto a durable non-array non-flash target, so
     * the offer is made IFF ALL of:
     *   - $deviceBackend == 'flash'          (the v1 GENUINE device test classes
     *                                         the persist device flash — a
     *                                         removable/USB-transport device)
     *   - $probeWear == 'wear_sensitive'     (the v2 probe confirms a genuine
     *                                         USB/removable device; an internal-
     *                                         boot ZFS/SSD is wear_normal and
     *                                         yields FALSE even WITH .sqsh layers)
     *   - $hasLayers                          (there is layered data on the stick)
     *   - $hasQualifyingTarget                (criterion b: a durable, non-array,
     *                                         non-flash, passthrough-capable,
     *                                         non-refused relocation target exists
     *                                         — see qualifyingGraduateTargets)
     * Conservative: any missing/odd fact refuses. On an internal-boot box every
     * entity is wear_normal, so this is FALSE for all of them (the Bug #1380
     * acceptance test). Consumed by StorageMetricsService (per-entity
     * `can_graduate`) and unit-tested without mounts (GraduateActionTest).
     *
     * NOTE — this REPLACES the S-10 (#1354) recommendation rule, which gated on
     * the in-place layering→passthrough op_graduate (device==passthrough &&
     * engine==passthrough). That op remains (storagectl graduate / op_graduate)
     * for the post-relocation engine drop, but is no longer the surfaced offer.
     */
    public static function canGraduate(string $deviceBackend, string $probeWear, bool $hasLayers, bool $hasQualifyingTarget): bool
    {
        return $deviceBackend === 'flash'
            && $probeWear === 'wear_sensitive'
            && $hasLayers
            && $hasQualifyingTarget;
    }

    /**
     * Forgejo #496 (docs/specs/CONVERT_LAYERED_TO_PLAIN_FOLDERS.md R9): the PURE
     * "Convert to plain folders" offer rule — the PHP mirror of bash
     * convert_offer_from_facts (detect_backend.sh). A layered home whose persist
     * folder is NOT on a USB stick can become plain folders in place. Offer IFF:
     *   - $type == 'home'                    (agents keep their layers, R11)
     *   - $deviceBackend == 'passthrough'    (the device verdict already picks
     *                                         plain folders for anything new)
     *   - $probeWear != 'wear_sensitive'     (never a USB stick: those keep
     *                                         layers and get the #1380 relocation)
     *   - $effectiveBackend == 'flash'       (the home is layered today)
     *   - $hasLayers                          (the layers pin it to flash)
     * Conservative: an empty or odd fact refuses. The probe's failure fallback is
     * wear_sensitive, so a failed probe never offers. Leaves canGraduate alone.
     */
    public static function canConvert(string $deviceBackend, string $probeWear, string $effectiveBackend, bool $hasLayers, string $type): bool
    {
        return $type === 'home'
            && $deviceBackend === 'passthrough'
            && $probeWear !== '' && $probeWear !== 'wear_sensitive'
            && $effectiveBackend === 'flash'
            && $hasLayers;
    }

    /**
     * #496: the facts canConvert needs for ONE home, read without mounting or
     * changing anything: the raw device verdict and the probe wear axis of the
     * home persist folder, and whether `home_<user>_*.sqsh` layers exist there
     * (the same glob StorageMetricsService counts). Memoised per request by the
     * two probes it calls.
     * @return array{device:string,wear:string,effective:string,has_layers:bool,persist:string}
     */
    public static function convertFactsForHome(string $user): array
    {
        $persist = self::persistPathFor('home', $user);
        $device  = (string)(self::backendForPath($persist)['backend'] ?? '');
        $wear    = (string)(self::probeTarget($persist)['wear'] ?? '');
        $hasLayers = $persist !== '' && preg_match('/^[A-Za-z0-9._-]+$/D', $user) === 1
            && count(glob(rtrim($persist, '/') . '/home_' . $user . '_*.sqsh') ?: []) > 0;
        $effective = self::effectiveBackendCaps($device, $hasLayers)['backend'];
        return ['device' => $device, 'wear' => $wear, 'effective' => $effective,
                'has_layers' => $hasLayers, 'persist' => $persist];
    }

    /** #496: can this one home be converted to plain folders now? Never throws. */
    public static function canConvertHome(string $user): bool
    {
        try {
            $f = self::convertFactsForHome($user);
            return self::canConvert($f['device'], $f['wear'], $f['effective'], $f['has_layers'], 'home');
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Resolve the persist path for an entity (lazy-loads the resolver). */
    private static function persistPathFor(string $type, string $id): string
    {
        require_once __DIR__ . '/StoragePathResolver.php';
        return $type === 'home'
            ? (string) StoragePathResolver::homePersistPath($id)
            : (string) StoragePathResolver::agentPersistPath();
    }

    /** Run a storagectl verb for an entity; returns [exit, decodedJsonArray]. */
    private static function seam(string $verb, string $type, string $id, string $persist, array $extra = []): array
    {
        // S-08 (#1353): AICLI_STORAGECTL is the TEST-ONLY script-path override
        // (same hook probeTarget has used since S-01) so StorageJobLedgerTest can
        // stub the status fast-path without a live seam. Production never sets it.
        $script = getenv('AICLI_STORAGECTL') ?: self::STORAGECTL;
        // R-06: AICLI_TRACE_ID=<id> env prefix (TraceContext::shellPrefix —
        // empty when no request trace; id is format-validated, interpolation-safe)
        // so every storagectl verb's shell log lines join the AJAX trace.
        // #825: an agent layer is written only by an install that a person waits
        // for, so it bakes with the interactive CPU profile (common.sh _batch_plan).
        $profile = ($type === 'agent' && ($verb === 'bake' || $verb === 'consolidate'))
            ? 'AICLI_BATCH_PROFILE=interactive ' : '';
        $cmd = TraceContext::shellPrefix() . $profile
            . 'bash ' . escapeshellarg($script) . ' ' . escapeshellarg($verb)
            . ' --type ' . escapeshellarg($type)
            . ' --id ' . escapeshellarg($id)
            . ' --persist ' . escapeshellarg($persist);
        foreach ($extra as $flag => $val) {
            $cmd .= ' ' . escapeshellarg($flag);
            if ($val !== null && $val !== '') { $cmd .= ' ' . escapeshellarg((string)$val); }
        }
        $out = [];
        $exit = 1;
        $stderrCapture = null;
        // nosemgrep: php.lang.security.exec-use.exec-use
        // #571: a bake or merge can run for minutes with no output. Keep the install's
        // tray entry alive while the process lives (a no-op when no such entry exists).
        if ($verb === 'bake' || $verb === 'consolidate') {
            require_once __DIR__ . '/ActivityService.php';
            [$exit, $out] = \AICliAgents\Services\ActivityService::runWatched(
                $cmd . ' 2>/dev/null', $type === 'agent' ? "install_$id" : null, 15, 'Baking SquashFS delta');
        } else {
            if ($verb === 'backend-migrate') {
                $stderrCapture = @tempnam(sys_get_temp_dir(), 'aicli-backend-migrate-');
                if (is_string($stderrCapture) && $stderrCapture !== '') {
                    $cmd .= ' 2>' . escapeshellarg($stderrCapture);
                } else {
                    $stderrCapture = null;
                    $cmd .= ' 2>/dev/null';
                }
            } else {
                $cmd .= ' 2>/dev/null';
            }
            // nosemgrep: php.lang.security.exec-use.exec-use
            exec($cmd, $out, $exit);
        }
        $json = [];
        $jsonLine = null;
        foreach ($out as $index => $line) {
            $decoded = json_decode((string)$line, true);
            if (is_array($decoded)) {
                $json = $decoded;
                $jsonLine = $index;
            }
        }
        $stdoutDiagnostic = [];
        foreach ($out as $index => $line) {
            if ($index !== $jsonLine && trim((string)$line) !== '') $stdoutDiagnostic[] = (string)$line;
        }
        if ($stderrCapture !== null) {
            $diagnostic = @file_get_contents($stderrCapture);
            @unlink($stderrCapture);
            if (is_string($diagnostic) && trim($diagnostic) !== '') $stdoutDiagnostic[] = $diagnostic;
        }
        if ($verb === 'backend-migrate') {
            $diagnostic = self::boundedMigrationDiagnostic(implode("\n", $stdoutDiagnostic));
            if ($diagnostic !== '') $json['diagnostic'] = $diagnostic;
            $json['reason'] = (string)($json['reason'] ?? $json['defer_reason'] ?? '');
        }
        return [$exit, $json];
    }

    /** Keep the last shell output lines that explain a failed backend migration. */
    private static function boundedMigrationDiagnostic(string $diagnostic): string
    {
        $diagnostic = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $diagnostic);
        $lines = preg_split('/\r\n|\r|\n/', $diagnostic) ?: [];
        $diagnostic = trim(implode("\n", array_slice($lines, -20)));
        return strlen($diagnostic) > 2000 ? substr($diagnostic, -2000) : $diagnostic;
    }

    /**
     * ensureReady(entity): the entity's storage is mounted and writable.
     *
     * The mount path has irreducible PHP-resident concerns (the per-entity flock, the
     * Bug#1054 owner-fix, the overlay health-check, the migration gate), so — unlike
     * release/status — ensureReady keeps routing through the mount methods, which shell
     * the storagectl mount seam internally. L5 (WP#1333): it now surfaces the seam's
     * exit code (via the by-ref $exit) instead of collapsing exit 2 to a bool, so the
     * 'deferred' state its DTO models is reachable (a busy mount kept its live overlay —
     * usable AND deferred, not just "ready").
     */
    public static function ensureReady(string $entity, array $opts = []): FileStorageReadiness
    {
        ['type' => $type, 'id' => $id] = self::parseEntity($entity);
        require_once __DIR__ . '/StorageMountService.php';
        $exit = 1;
        $ok = ($type === 'home')
            ? StorageMountService::ensureHomeMounted($id, $exit)
            : StorageMountService::ensureAgentMounted($id, $exit);
        $reason = $exit === 2 ? self::peekDeferReason($type, $id) : null;
        if (!$ok && $exit === 2 && $reason === 'storage_move_active') {
            return FileStorageReadiness::unavailableDeferred($reason);
        }
        return FileStorageReadiness::fromExit($ok ? $exit : 1, ($ok && $exit === 2) ? $reason : null);
    }

    /**
     * Unconditionally remount an agent overlay, bypassing the healthy-mount
     * fast-path in ensureReady/ensureAgentMounted. Used by
     * InstallerService::forceAgentRefresh (R3 verify-live gate) to swap a
     * stale lowerdir for the newest baked layer after a deferred refresh.
     *
     * Entity format: "agent/<id>" — same as ensureReady; home entities are
     * rejected (home overlays have no stale-lowerdir problem).
     *
     * Returns true when op_mount exits usably (exit 0 or 2).
     */
    public static function forceRemount(string $entity): bool
    {
        ['type' => $type, 'id' => $id] = self::parseEntity($entity);
        if ($type !== 'agent') {
            throw new \InvalidArgumentException("forceRemount only supports agent entities, got: '$type'");
        }
        require_once __DIR__ . '/StorageMountService.php';
        return StorageMountService::remountAgent($id);
    }

    /**
     * S-08 (#1353, docs/specs/STORAGE_ASYNC_JOBS.md): NON-BLOCKING readiness.
     *
     * Fast path: the entity's merged overlay is already mounted → {state:'ready'}
     * (one status seam call, no mount work). Otherwise a supervisor `mount` job
     * is enqueued (priority 5 — user-facing) and {state:'mounting', job_id} is
     * returned; the caller polls `storage_job_status` (or rides the activity
     * tray) and retries once the job lands. An ACTIVE mount job for the entity
     * is ridden instead of re-enqueued, so poll/retry loops can never pile jobs.
     *
     * Sync `ensureReady` stays for CLI/event/supervisor/auto-launch contexts
     * (headless callers with nobody to poll); if the enqueue itself fails
     * (queue helpers missing) this falls back to the sync path so a caller is
     * never left with neither a mount nor a job.
     *
     * @return array{state:string, job_id?:string, wait_s?:int, exit?:int, defer_reason?:?string}
     */
    public static function ensureReadyAsync(string $entity, array $opts = []): array
    {
        ['type' => $type, 'id' => $id] = self::parseEntity($entity);

        // Fast path — mounted now? (status() is read-only; ~one shell call.)
        if (self::status($entity)->mounted) {
            return ['state' => 'ready'];
        }

        require_once __DIR__ . '/SupervisorService.php';

        // Dedup: ride an existing active mount job for this entity.
        $existing = SupervisorService::findActiveJob($type, $id, 'mount');
        if ($existing !== null && !empty($existing['job_id'])) {
            return ['state' => 'mounting', 'job_id' => (string)$existing['job_id'], 'wait_s' => self::targetWaitS()];
        }

        // Backstop: make sure a supervisor is up to drain the job (cheap no-op
        // when running; best-effort — the queue entry is durable either way).
        SupervisorService::start();

        $jobId = SupervisorService::enqueueJob(
            $type, $id, 'mount', (string)($opts['reason'] ?? 'workspace_open'), 5
        );
        if ($jobId === null) {
            // Queue unavailable — degrade to the synchronous path rather than
            // stranding the caller with neither a mount nor a job.
            $r = self::ensureReady($entity, $opts);
            return [
                'state'        => $r->ok ? 'ready' : 'unavailable',
                'exit'         => $r->exit,
                'defer_reason' => $r->deferReason,
            ];
        }
        return ['state' => 'mounting', 'job_id' => $jobId, 'wait_s' => self::targetWaitS()];
    }

    /** S-08: deferred-mount wait budget (cfg storage_target_wait_s, default 300, min 30). */
    private static function targetWaitS(): int
    {
        require_once __DIR__ . '/ConfigService.php';
        $raw = ConfigService::getConfig()['storage_target_wait_s'] ?? '';
        $s = is_numeric($raw) ? (int)$raw : 300;
        return max(30, $s);
    }

    /**
     * persist(entity): flush in-RAM changes to durable storage (subsumes bake).
     *
     * L5 (WP#1333): persist's consumer-policy now lives in the FACADE (moved verbatim
     * from the deleted StorageMountService::commitChanges) and routes through the
     * storagectl seam directly — op_bake records the manifest under the entity lock
     * (F6), so persist sits at the same depth as release/status (no middle layer).
     */
    public static function persist(string $entity, array $opts = []): FileStoragePersistResult
    {
        ['type' => $type, 'id' => $id] = self::parseEntity($entity);
        require_once __DIR__ . '/StorageMountService.php';
        require_once __DIR__ . '/StoragePathResolver.php';
        require_once __DIR__ . '/LogService.php';
        require_once __DIR__ . '/LifecycleLogService.php';
        $persist = self::persistPathFor($type, $id);

        if ($type === 'agent') {
            // WP#748 J: agents always collapse to a single layer on install/upgrade. If
            // the consolidate DEFERS (overlay busy), fall back to a delta bake so the
            // ZRAM data is at least safe on Flash — without this all agent data lives
            // only in ZRAM and is lost on reboot. mapAgentCommitResult keeps the data-
            // safety contract (deferred + bake-ok must NOT be fatal) unit-tested.
            $deferred = false;
            $consolidated = StorageMountService::consolidate($type, $id, $deferred);
            $bakeRc = 0;
            $bakeReason = null;
            if (!$consolidated && $deferred) {
                [$bakeRc, $bakeJson] = self::seam('bake', $type, $id, $persist);
                // #357: an exit 2 can mean "not saved" (bake_lock_held after the
                // lock wait) — pass the reason so the mapping can tell.
                $bakeReason = ((int)$bakeRc === 2)
                    ? (($bakeJson['defer_reason'] ?? null) ?: self::peekDeferReason($type, $id))
                    : null;
            }
            $exit = StorageMountService::mapAgentCommitResult($consolidated, $deferred, (int)$bakeRc, $bakeReason);
            if ($exit === 1 && !$consolidated && $deferred) {
                LogService::log("Agent $id: consolidation deferred AND fallback delta bake did not save (rc=$bakeRc, reason=" . ($bakeReason ?? 'none') . ") — data remains in ZRAM only.", LogService::LOG_ERROR, "FileStorage");
            } elseif ($exit === 2) {
                LogService::log("Agent $id: consolidation deferred; delta bake succeeded — data is safe on Flash, consolidation deferred to next install.", LogService::LOG_WARN, "FileStorage");
            }
            $reason = ($exit === 2) ? self::peekDeferReason($type, $id) : null;
            return FileStoragePersistResult::fromExit($exit, $reason);
        }

        // Home: flush straight through the seam.
        if (!StorageMountService::isPathAvailable($persist)) {
            LogService::log("Persist skipped for $type $id: storage path $persist not accessible.", LogService::LOG_WARN, "FileStorage");
            return FileStoragePersistResult::fromExit(1, null);
        }
        $upperDir = StoragePathResolver::zramUpper($type, $id);
        $dirtyMB = 0;
        if (is_dir($upperDir)) {
            $io = shell_exec("du -sm " . escapeshellarg($upperDir) . " 2>/dev/null | cut -f1");
            $dirtyMB = (int)trim((string)$io);
        }
        LogService::log("Initiating SquashFS persistence bake for $type $id ($dirtyMB MB dirty)...", LogService::LOG_INFO, "FileStorage");
        LifecycleLogService::log(LifecycleLogService::LEVEL_INFO, 'FileStorage', 'bake_start', ['type' => $type, 'id' => $id, 'dirty_mb' => $dirtyMB, 'persist_path' => $persist]);

        [$exit, $bakeJson] = self::seam('bake', $type, $id, $persist);
        $reason = ($exit === 2)
            ? (($bakeJson['defer_reason'] ?? null) ?: self::peekDeferReason($type, $id))
            : null;

        if ($exit === 0) {
            LogService::log("Successfully persisted $dirtyMB MB of RAM storage to Flash disk for $type $id.", LogService::LOG_INFO, "FileStorage");
            LifecycleLogService::log(LifecycleLogService::LEVEL_INFO, 'FileStorage', 'bake_ok', ['type' => $type, 'id' => $id, 'dirty_mb' => $dirtyMB, 'result' => 0]);
        } elseif ($exit === 2 && !self::bakeResultSaved($exit, $reason)) {
            // #357: no layer was written (another storage operation held the lock
            // past the wait, or a database copy was locked). Never "Backed up".
            LogService::log("NOT saved: $dirtyMB MB for $type $id stay in RAM (reason=" . ($reason ?? 'unknown') . "); the next save captures them.", LogService::LOG_WARN, "FileStorage");
            LifecycleLogService::log(LifecycleLogService::LEVEL_WARN, 'FileStorage', 'bake_not_saved', ['type' => $type, 'id' => $id, 'dirty_mb' => $dirtyMB, 'reason' => $reason ?? 'unknown']);
        } elseif ($exit === 2) {
            LogService::log("Backed up $dirtyMB MB to Flash for $id, RAM flush deferred (reason=" . ($reason ?? 'unknown') . ").", LogService::LOG_INFO, "FileStorage");
            LifecycleLogService::log(LifecycleLogService::LEVEL_INFO, 'FileStorage', 'bake_deferred', ['type' => $type, 'id' => $id, 'dirty_mb' => $dirtyMB, 'reason' => $reason ?? 'unknown']);
        } else {
            LogService::log("FAILED SquashFS persistence bake for $type $id.", LogService::LOG_ERROR, "FileStorage");
            LifecycleLogService::log(LifecycleLogService::LEVEL_ERROR, 'FileStorage', 'bake_failed', ['type' => $type, 'id' => $id, 'result' => $exit]);
        }
        $res = FileStoragePersistResult::fromExit($exit, $reason);
        // #567: outcome "noop" = exit 0 with an empty writable layer.
        $res->nothingToSave = ($exit === 0 && ((string)($bakeJson['outcome'] ?? '')) === 'noop');
        return $res;
    }

    /**
     * Read (without consuming) the defer-reason marker for an entity.
     *
     * S-03 (#1352): a marker older than the TTL (cfg defer_marker_ttl_h, default
     * 24 h) is STALE — its op either retried since or was abandoned — and is
     * silently ignored (the supervisor's reconcile reaps the file). Mirrors the
     * bash-side _defer_marker_fresh in common.sh; keep the two in sync.
     */
    private static function peekDeferReason(string $type, string $id): ?string
    {
        $safe = preg_replace('/[^a-zA-Z0-9_-]/', '_', $id);
        $marker = SecretPaths::stateRoot() . "/.bake_defer_reason_{$type}_{$safe}";
        if (is_file($marker)) {
            $mtime = @filemtime($marker);
            if ($mtime !== false && (time() - $mtime) >= self::deferMarkerTtlH() * 3600) {
                return null; // stale — ignore (reconcile will reap the file)
            }
            $raw = @file_get_contents($marker);
            if ($raw !== false) { $r = trim($raw); return $r !== '' ? $r : null; }
        }
        return null;
    }

    /** S-03 (#1352): defer-marker TTL in hours — cfg defer_marker_ttl_h, default 24, min 1. */
    private static function deferMarkerTtlH(): int
    {
        require_once __DIR__ . '/ConfigService.php';
        $config = ConfigService::getConfig();
        $raw = $config['defer_marker_ttl_h'] ?? '';
        $ttl = is_numeric($raw) ? (int)$raw : 24;
        return max(1, $ttl);
    }

    /** release(entity): tear down for shutdown/close (subsumes unmount + flush). */
    public static function release(string $entity, array $opts = []): FileStorageReleaseResult
    {
        ['type' => $type, 'id' => $id] = self::parseEntity($entity);
        $persist = self::persistPathFor($type, $id);
        // Epic #1310: the `release` verb (flush-then-unmount) — the central
        // manifest-under-lock bake path is the only writer.
        [$exit, $j] = self::seam('release', $type, $id, $persist);
        return FileStorageReleaseResult::fromExit($exit, $j['defer_reason'] ?? null);
    }

    /** status(entity): health / capabilities / dirty bytes for the UI + supervisor. */
    public static function status(string $entity): FileStorageStatus
    {
        ['type' => $type, 'id' => $id] = self::parseEntity($entity);
        $persist = self::persistPathFor($type, $id);
        [, $j] = self::seam('status', $type, $id, $persist);
        // L6 (WP#1333): $j is already the decoded seam array — build from it directly
        // (no json_encode→json_decode round-trip).
        return FileStorageStatus::fromArray(is_array($j) ? $j : []);
    }

    /**
     * Whether an agent's current storage backend can stage and bake a successor
     * without changing the generation in service. This deliberately uses the
     * raw seam result rather than the status DTO: a missing or failed status
     * response must not be treated as permission to write beside live sessions.
     * Both layering and plain-directory agent storage expose a versioned
     * activation path; homes continue to use their normal close/flush boundary.
     */
    public static function agentStorageSupportsSideBySide(string $agentId): bool
    {
        if ($agentId === '') {
            return false;
        }
        try {
            ['type' => $type, 'id' => $id] = self::parseEntity('agent/' . $agentId);
        } catch (\InvalidArgumentException $e) {
            return false;
        }
        $persist = self::persistPathFor($type, $id);
        [$exit, $j] = self::seam('status', $type, $id, $persist);
        return $exit === 0
            && (($j['supportsSideBySide'] ?? false) === true
                || (($j['backend'] ?? null) === 'flash' && ($j['supportsBake'] ?? false) === true));
    }

    /** Run one crash-safe per-entity storage-engine conversion. */
    public static function migrateBackend(string $type, string $id, string $target, bool $forceDirect = false, bool $rollback = false): array
    {
        if (!in_array($type, ['agent', 'home'], true) || $id === '') {
            return ['exit' => 64, 'outcome' => 'failed', 'reason' => 'invalid_entity'];
        }
        $target = StorageBackendPolicyService::normalizeMode($target);
        $persist = self::persistPathFor($type, $id);
        $extra = ['--target' => $target];
        if ($forceDirect) $extra['--force-direct'] = null;
        if ($rollback) $extra['--rollback'] = null;
        [$exit, $json] = self::seam('backend-migrate', $type, $id, $persist, $extra);
        $json['exit'] = $exit;
        return $json;
    }

    /** Bracket the all-entity engine migration with its own crash marker. */
    public static function migrateBackendPolicy(string $from, string $to, callable $work): FileStorageMigrationResult
    {
        self::writeBackendMigrationMarker(['trigger' => 'backend', 'from' => $from, 'to' => $to, 'phase' => 'running']);
        try {
            $ok = (bool)$work();
        } catch (\Throwable $e) {
            self::clearBackendMigrationMarker();
            return FileStorageMigrationResult::make(false, 'failed', $e->getMessage());
        }
        self::clearBackendMigrationMarker();
        return FileStorageMigrationResult::make($ok, $ok ? 'migrated' : 'failed');
    }

    // ---- Migration: the TWO bounded triggers (Epic #1310 #1321/#1322) ---------
    // Migration is NEVER in the hot path. The component is TOLD to migrate at two
    // explicit moments; between them, the operate path assumes current-format,
    // current-path data.
    //
    // The in-progress marker SUPPRESSES the supervisor's path_drift discovery-halt
    // WHILE a migration runs (the config path moves ahead of the manifest mid-copy).
    // F4 (WP#1327): it is NOT a boot resume/rollback mechanism — there is no boot
    // consumer, and the marker lives on tmpfs (gone at reboot). The supervisor's check
    // is ts/mtime-bounded so a leaked marker (kill-mid-migration) cannot disable
    // drift protection for the rest of the uptime. The migration itself re-points the
    // manifest in-transaction (repointManifestPaths) so a COMPLETED migration leaves
    // no drift to discover; an INTERRUPTED one is re-discovered by the classifier at
    // next boot (the marker is gone), exactly as before the marker existed.

    /** The migration marker in RAM (the state root under test is the sandbox). */
    private static function defaultMigrationMarker(): string { return SecretPaths::stateRoot() . '/.migration_inprogress.json'; }

    /**
     * Trigger 1 — persist/agent PATH change. The settings layer TELLS the
     * component "X → Y, migrate", so a normal boot never discovers a drifted path
     * to halt on (this is what makes the supervisor/boot path_drift discovery-halt
     * redundant). A crash-safe resumable marker is held for the WHOLE migration, so
     * an interrupted copy leaves an unambiguous marker for boot rather than tripping
     * normal ops.
     *
     * The real path-change consumer (StorageHandler::runPathMove, run by the supervisor job) owns a rich,
     * proven copy flow (per-file progress, agent+home, pre/post consolidation), so
     * it passes that work as $work and migratePath simply MARKER-BRACKETS it — it
     * does NOT replace the logic. With no $work, falls back to the proven
     * StorageMigrationService::migratePersistence rsync (the dark default).
     *
     * @param callable|null $work runs the actual migration under the marker;
     *        returns truthy on success. null → migratePersistence($new).
     */
    public static function migratePath(string $old, string $new, $work = null): FileStorageMigrationResult
    {
        self::writeMigrationMarker(['trigger' => 'path', 'from' => $old, 'to' => $new, 'phase' => 'running']);
        try {
            if (is_callable($work)) {
                $ok = (bool) $work();
            } else {
                require_once __DIR__ . '/StorageMigrationService.php';
                $ok = (bool) StorageMigrationService::migratePersistence($new);
            }
        } catch (\Throwable $e) {
            self::clearMigrationMarker();
            return FileStorageMigrationResult::make(false, 'failed', $e->getMessage());
        }
        self::clearMigrationMarker();
        return FileStorageMigrationResult::make($ok, $ok ? 'migrated' : 'failed');
    }

    /**
     * Is a format migration warranted? Pure gate for the "once per version bump"
     * trigger: any version change (including first install where $from is empty)
     * counts; a no-op re-save of the same version does NOT.
     */
    public static function formatMigrationNeeded(string $from, string $to): bool
    {
        return $from !== $to;
    }

    /**
     * Trigger 2 — plugin VERSION upgrade. The installer calls this ONCE on a
     * version bump to run any on-disk FORMAT migration (btrfs→squashfs,
     * geminicli→aicliagents, seq-keying). The scripts are idempotent + self-
     * detecting, so this is a thin, safe trigger; afterwards the data is
     * current-format. (NOTE: this does NOT convert flash→passthrough — that would
     * strand existing layered data; it's a separate, explicit, backed-up op.)
     */
    public static function migrateFormat(string $from, string $to): FileStorageMigrationResult
    {
        // "Once per version bump" gate — a same-version re-save is not a migration.
        if (!self::formatMigrationNeeded($from, $to)) {
            return FileStorageMigrationResult::make(true, 'none');
        }
        // This is the SINGLE explicit "version bumped → format-migration point" so a
        // normal boot never has to DISCOVER a format drift and halt.
        //
        // Deliberately NOT run synchronously here:
        //   • migrate-from-geminicli.sh — destructively tears down the *sibling*
        //     geminicli plugin (mv/rm -rf) and is a one-time legacy concern, not a
        //     per-bump migration. Resurrecting it on every upgrade (incl. production)
        //     would silently delete a co-installed geminicli plugin. Left dark.
        //   • migrate-btrfs-to-squashfs.sh — slow; stays BACKGROUNDED by the .plg
        //     installer (D-308 anti-hang) under its own migration.lock; running it
        //     sync would re-hang the installer.
        //
        // There is no safe synchronous per-bump format script today, so this trigger
        // is a no-op beyond the version gate. When one IS added, wrap its run in
        // writeMigrationMarker()/clearMigrationMarker() (mirroring migratePath) so an
        // interrupted format migration leaves a resumable .migration_inprogress.json.
        return FileStorageMigrationResult::make(true, 'none');
    }

    /** Uninstall: remove an entity's storage entirely (upper + layers + manifest). */
    public static function removeEntity(string $entity, array $opts = []): bool
    {
        ['type' => $type, 'id' => $id] = self::parseEntity($entity);
        $persist = self::persistPathFor($type, $id);
        [$exit, ] = self::seam('wipe', $type, $id, $persist);
        return $exit === 0;
    }

    /**
     * Bug #1379: permanently delete a HOME entity and ALL its residue.
     * Single authoritative deletion routine used by the AJAX handler AND
     * (via storagectl wipe) by the harness _purge_test_entity helper.
     *
     * Steps:
     *   1. Validate entity is type=home + id exists in manifest (or has .sqsh files)
     *   2. Refuse if the merge mount is in-use (fuser -sm → entity_in_use)
     *   3. storagectl wipe: unmount overlay, remove .sqsh layers, clear manifest
     *   4. Best-effort cleanup of residue: defer-reason marker, work dir, bake lock,
     *      commit/consolidate markers, halt markers
     *   5. Log lifecycle event home_entity_deleted
     *
     * @return array{ok:bool, reason?:string, message?:string}
     */
    public static function deleteHomeEntity(string $id): array
    {
        if ($id === '' || !preg_match('/^[a-zA-Z0-9._-]{1,64}$/D', $id)) {
            return ['ok' => false, 'reason' => 'invalid_id', 'message' => 'Invalid home id'];
        }

        $entity  = "home/$id";
        $persist = self::persistPathFor('home', $id);
        $safeId  = str_replace(['/', ' '], '_', $id);

        // Check if entity has any presence (manifest or .sqsh files on disk).
        require_once __DIR__ . '/LayerManifestService.php';
        $mentry     = LayerManifestService::getEntity($entity);
        $sqshGlob   = LayerManifestService::layerFilesOfEntity($persist, 'home', $id);   // R-002: not bob_smith's layers
        if ($mentry === null && empty($sqshGlob)) {
            return ['ok' => false, 'reason' => 'entity_not_found',
                    'message' => "No storage entity found for home/$id"];
        }

        // Refuse if merge mount is busy (a live terminal session is open).
        $mnt = SecretPaths::stateRoot() . "/work/{$id}/home";
        if (is_dir($mnt) && self::_mountIsBusy($mnt)) {
            return ['ok' => false, 'reason' => 'entity_in_use',
                    'message' => "Home $id has an active session — close all terminals for this user first."];
        }

        // Core deletion: storagectl wipe (umount + rm .sqsh + manifest remove).
        [$exit, ] = self::seam('wipe', 'home', $id, $persist);
        if ($exit !== 0) {
            return ['ok' => false, 'reason' => 'wipe_failed',
                    'message' => "storagectl wipe for home/$id exited $exit — check lifecycle log."];
        }

        // Best-effort residue cleanup (storagectl wipe may not remove all markers).
        $stateRoot = SecretPaths::stateRoot();
        @unlink("$stateRoot/.bake_defer_reason_home_{$safeId}");
        @unlink("$stateRoot/.bake_defer_reason_home_{$id}");
        @unlink("$stateRoot/.commit_marker_home_{$id}");
        @unlink("$stateRoot/.consolidate_marker_home_{$id}");
        @unlink("/var/run/aicli-bake-home-{$safeId}.lock");
        @unlink("/var/run/aicli-bake-home-{$id}.lock");
        // #357: the lock owner record next to the lock.
        @unlink("/var/run/aicli-bake-home-{$safeId}.lock.owner");
        // Work dir (contains merge mountpoint, upper, work subdirs when not in use).
        $workDir = "$stateRoot/work/{$id}";
        if (is_dir($workDir)) {
            // nosemgrep: php.lang.security.exec-use.exec-use — workDir derived from validated id
            @shell_exec('rm -rf ' . escapeshellarg($workDir) . ' 2>/dev/null');
        }
        // Halt markers for this entity. There are two current producers:
        // HaltService writes halts/<type>/<id>[.json], while the bash
        // supervisor writes halts/<type>_<id>:<reason>. Clear both exact,
        // validated-id forms so a deleted entity cannot remain visibly halted.
        self::clearEntityHalts('home', $id);

        // Invalidate boot integrity cache so next fetch reflects the deletion.
        @unlink($stateRoot . '/.boot_integrity_cache.json');

        // Lifecycle event.
        require_once __DIR__ . '/LifecycleLogService.php';
        LifecycleLogService::log(
            LifecycleLogService::LEVEL_INFO,
            'file_storage', 'home_entity_deleted',
            ['id' => $id, 'persist' => $persist]
        );

        return ['ok' => true, 'message' => "Home storage for '$id' deleted successfully."];
    }

    /**
     * Check whether a merge-mount directory has open file descriptors (fuser -sm).
     * Used by deleteHomeEntity() to refuse deletion of a live home.
     */
    private static function _mountIsBusy(string $mnt): bool
    {
        if (!is_dir($mnt)) return false;
        // mountpoint -q: is it actually mounted?
        // nosemgrep: php.lang.security.exec-use.exec-use — $mnt derived from validated id
        $isMounted = @shell_exec('mountpoint -q ' . escapeshellarg($mnt) . ' 2>/dev/null && echo 1');
        if (trim((string)$isMounted) !== '1') return false;
        // fuser -sm: are there open fds on the mount?
        // nosemgrep: php.lang.security.exec-use.exec-use — $mnt fully escaped
        $fuserOut = @shell_exec('fuser -sm ' . escapeshellarg($mnt) . ' 2>/dev/null && echo busy');
        return str_contains((string)$fuserOut, 'busy');
    }

    /** Remove structured PHP and flat supervisor halt markers for one entity. */
    private static function clearEntityHalts(string $type, string $id): void
    {
        require_once __DIR__ . '/HaltService.php';
        $base = HaltService::directory();
        @unlink("$base/$type/$id");
        @unlink("$base/$type/$id.json");
        @unlink("$base/{$type}_{$id}");
        foreach (glob("$base/{$type}_{$id}:*") ?: [] as $halt) {
            if (is_file($halt)) @unlink($halt);
        }
    }

    // ---- Manifest intent verbs (Epic #1310 Follow-on 2) ----------------------
    // Two niche manifest mutations consumers used to do directly. Routing them
    // through the facade keeps the manifest a PRIVATE storage-internal concern:
    // consumers express intent, never touch LayerManifestService. Both validate
    // the entity at the boundary, then delegate to the lock-guarded owner.

    /**
     * Drop the manifest entry for an ORPHAN/GHOST entity — an agent removed from
     * the registry, or an uninstalled agent whose lingering entry would otherwise
     * make the next boot-integrity sweep flag a phantom "missing" entity.
     * Idempotent (absent entry → no-op true).
     */
    public static function dropManifestEntry(string $entity): bool
    {
        self::parseEntity($entity); // validate at the facade boundary
        require_once __DIR__ . '/LayerManifestService.php';
        return LayerManifestService::removeEntity($entity);
    }

    /**
     * Point the manifest at a RESTORED layer set — e.g. a version-rollback that
     * swapped the on-disk layers back to a prior backup. Replaces the entity's
     * recorded layers + persistence path atomically under the manifest lock.
     *
     * @param array<int,array<string,mixed>> $layers
     */
    public static function pointManifestAtLayers(string $entity, array $layers, string $persistPath): bool
    {
        self::parseEntity($entity);
        require_once __DIR__ . '/LayerManifestService.php';
        return LayerManifestService::replaceLayers($entity, $layers, $persistPath);
    }

    /**
     * F3 (WP#1327): re-point the manifest's recorded persistence paths after a
     * COMPLETED path migration (old → new), scoped to one entity type ('home/' |
     * 'agent/'). Called from inside the migration marker bracket so a finished
     * migration leaves the manifest at the new path and a normal reconcile/boot never
     * DISCOVERS a stale path to false-halt as path_drift. Returns the count moved.
     */
    public static function repointManifestPaths(string $oldPrefix, string $newPrefix, string $entityPrefix = ''): int
    {
        require_once __DIR__ . '/LayerManifestService.php';
        return LayerManifestService::repointPathPrefix($oldPrefix, $newPrefix, $entityPrefix);
    }

    /**
     * Resolve the crash-safe marker path. AICLI_MIGRATION_MARKER overrides the
     * default (test hook — same pattern as AICLI_PROC_MOUNTS / AICLI_ITEST_BACKEND),
     * so PHPUnit can point it at a writable temp path box-independently.
     */
    private static function markerPath(): string
    {
        $env = getenv('AICLI_MIGRATION_MARKER');
        return ($env !== false && $env !== '') ? $env : self::defaultMigrationMarker();
    }

    /**
     * Is a fresh path-move marker owned by a live migration process?
     *
     * @phpstan-impure The marker and lock state can change between checks.
     */
    public static function isMigrationInProgress(): bool
    {
        $marker = self::markerPath();
        if (!is_file($marker)) return false;

        $lock = self::acquireMigrationLock();
        if ($lock === null) {
            // Home mounts hold a shared lock. A shared reader can coexist with
            // them, so only a failed shared probe means an exclusive move may
            // own the marker.
            $shared = self::acquireMigrationSharedLock();
            if ($shared !== null) {
                self::releaseMigrationLock($shared);
                return false;
            }
            $mtime = @filemtime($marker);
            return $mtime === false || (time() - $mtime) <= self::MIGRATION_MARKER_MAX_AGE_S;
        }

        try {
            // A killed worker releases flock but cannot remove its marker. The
            // free lock proves that no move owns this marker, so remove the
            // crash residue while holding the same lock used by every move.
            if (@unlink($marker) && class_exists(LogService::class)) {
                LogService::log('Removed an orphaned storage-move marker because its lock was free.', LogService::LOG_WARN, 'FileStorage');
            }
        } finally {
            self::releaseMigrationLock($lock);
        }
        return false;
    }

    /** Is the global engine migration marker present? */
    public static function isBackendMigrationInProgress(): bool
    {
        return is_file(self::backendMigrationMarkerPath());
    }

    /** The engine marker lives beside, but does not replace, the path-move marker. */
    private static function backendMigrationMarkerPath(): string
    {
        $env = getenv('AICLI_BACKEND_MIGRATION_MARKER');
        return ($env !== false && $env !== '')
            ? $env
            : dirname(self::markerPath()) . '/.backend_migration_inprogress.json';
    }

    /**
     * #652/#707: the common exclusive lock for path and engine migrations.
     * A non-blocking flock on one lock file prevents concurrent migration writes.
     * Migration callers can wait for a short, bounded time for shared home mounts.
     * Returns the open lock handle (keep it until the request ends, then release it with
     * releaseMigrationLock()) or null when another migration holds it.
     * @return resource|null
     */
    public static function acquireMigrationLock(float $waitSeconds = 0.0, ?callable $wait = null)
    {
        $path = self::markerPath() . '.lock';
        @mkdir(dirname($path), 0755, true);
        $fh = @fopen($path, 'c');
        if ($fh === false) return null;
        $deadline = microtime(true) + max(0.0, $waitSeconds);
        do {
            if (@flock($fh, LOCK_EX | LOCK_NB)) return $fh;
            $remaining = $deadline - microtime(true);
            if ($remaining <= 0.0) {
                @fclose($fh);
                return null;
            }
            $pause = min(100000, max(1, (int)ceil($remaining * 1000000)));
            if ($wait !== null) {
                $wait($pause);
            } else {
                usleep($pause);
            }
        }
        while (true);
    }

    /** Acquire the shared lock used by a home mount while it reads the path. */
    public static function acquireMigrationSharedLock()
    {
        $path = self::markerPath() . '.lock';
        @mkdir(dirname($path), 0755, true);
        $fh = @fopen($path, 'c');
        if ($fh === false) return null;
        if (!@flock($fh, LOCK_SH | LOCK_NB)) {
            @fclose($fh);
            return null;
        }
        return $fh;
    }

    /** @param resource|null $fh */
    public static function releaseMigrationLock($fh): void
    {
        if (is_resource($fh)) {
            @flock($fh, LOCK_UN);
            @fclose($fh);
        }
    }

    private static function writeMigrationMarker(array $plan): void
    {
        self::writeMarker(self::markerPath(), $plan);
    }

    private static function writeBackendMigrationMarker(array $plan): void
    {
        self::writeMarker(self::backendMigrationMarkerPath(), $plan);
    }

    private static function writeMarker(string $marker, array $plan): void
    {
        @mkdir(dirname($marker), 0755, true);
        $plan['ts'] = gmdate('c');
        @file_put_contents($marker, json_encode($plan));
    }

    /** Refresh the path-move marker age while a long migration reports progress. */
    public static function refreshMigrationMarker(): bool
    {
        $marker = self::markerPath();
        return is_file($marker) && @touch($marker);
    }

    private static function clearMigrationMarker(): void
    {
        @unlink(self::markerPath());
    }

    private static function clearBackendMigrationMarker(): void
    {
        @unlink(self::backendMigrationMarkerPath());
    }
}
