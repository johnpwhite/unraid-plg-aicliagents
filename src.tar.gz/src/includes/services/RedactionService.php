<?php
/**
 * <module_context>
 *     <name>RedactionService</name>
 *     <description>Fail-closed layered redaction for the diagnostics support bundle (R-08, Feature #1371).
 *     Layers: (1) structural allowlist is enforced by DiagnosticsService (raw secrets.cfg / env files are
 *     never read into a bundle — this service never sees them as content); (2) known-key value scrub:
 *     key NAMES are read from the vault + workspace secret files and any VALUE found verbatim in an
 *     excerpt is replaced with «REDACTED:keyname»; (3) pattern scrub (assignments, vendor token prefixes,
 *     Bearer/Authorization, long base64/hex runs, emails); (4) optional strict-anonymize (shares→share-NN
 *     stable map, hostname→unraid-host, LAN IPs masked); (5) self-test: assertClean() throws when any
 *     known secret VALUE survives — the bundle build aborts rather than ships.</description>
 *     <dependencies>SecretService (paths only — key/value map via its readers)</dependencies>
 *     <constraints>Never logs secret values (exception messages carry key NAMES only). Verbatim value
 *     matching uses str_replace/strpos, never regex, so metacharacters in secrets cannot break matching.
 *     Test hooks: AICLI_SECRETS_VAULT / AICLI_SECRETS_DIR env overrides (AICLI_MANIFEST_PATH precedent).</constraints>
 * </module_context>
 */

namespace AICliAgents\Services;

require_once __DIR__ . '/SecretService.php';

class RedactionService {

    /** Values shorter than this are not scrubbed/self-tested verbatim (a 1-char
     *  "value" like "1" would corrupt the whole excerpt). Same threshold is used
     *  by BOTH the scrub and the self-test so no gap opens between them. */
    public const MIN_VALUE_LEN = 4;

    // ------------------------------------------------------------------
    // Layer 2 — known-key value scrub
    // ------------------------------------------------------------------

    /**
     * Load key NAMES + values from the agent vault and every workspace secret
     * file. The map is used to (a) scrub values verbatim and (b) self-test the
     * final bundle bytes. Multiline values contribute each line >= MIN_VALUE_LEN.
     *
     * @return array<string,string> keyname => value
     */
    public static function loadKnownSecrets(): array {
        $out = [];

        $vault = getenv('AICLI_SECRETS_VAULT');
        $vault = ($vault !== false && $vault !== '') ? $vault : SecretService::getAgentSecretsPath();
        foreach (self::readIniSafe($vault) as $k => $v) {
            $out[$k] = $v;
        }

        $dir = getenv('AICLI_SECRETS_DIR');
        $dir = ($dir !== false && $dir !== '') ? $dir : SecretService::getWorkspaceSecretsDir();
        if (is_dir($dir)) {
            foreach (glob(rtrim($dir, '/') . '/*.cfg') ?: [] as $file) {
                foreach (self::readIniSafe($file) as $k => $v) {
                    // Workspace key may shadow a vault key with a different value —
                    // keep both values testable by suffixing the source on collision.
                    if (isset($out[$k]) && $out[$k] !== $v) {
                        $out[$k . '@' . basename($file)] = $v;
                    } else {
                        $out[$k] = $v;
                    }
                }
            }
        }
        return $out;
    }

    /**
     * Replace every verbatim occurrence of a known secret value with
     * «REDACTED:keyname». Pure string replacement (no regex) — metacharacters
     * in secrets are matched literally. Multiline values are also replaced
     * line-by-line so a partial leak of a multiline secret is still caught.
     */
    public static function knownKeyScrub(string $text, array $knownSecrets): string {
        foreach (self::expandSecretValues($knownSecrets) as $key => $values) {
            foreach ($values as $value) {
                $text = str_replace($value, "\u{AB}REDACTED:$key\u{BB}", $text);
            }
        }
        return $text;
    }

    /**
     * Expand the secrets map into testable fragments: the full value plus each
     * line of a multiline value, dropping fragments < MIN_VALUE_LEN. Longest
     * fragments first so a full-value replace wins over a line replace.
     *
     * @return array<string,array<int,string>> keyname => [fragment, ...]
     */
    private static function expandSecretValues(array $knownSecrets): array {
        $out = [];
        foreach ($knownSecrets as $key => $value) {
            $value = (string)$value;
            $frags = [$value];
            if (strpos($value, "\n") !== false) {
                foreach (preg_split('/\r?\n/', $value) ?: [] as $line) {
                    $frags[] = $line;
                }
            }
            $frags = array_values(array_unique(array_filter(array_map('trim', $frags), function ($f) {
                return strlen($f) >= self::MIN_VALUE_LEN;
            })));
            usort($frags, function ($a, $b) { return strlen($b) - strlen($a); });
            if ($frags !== []) {
                $out[(string)$key] = $frags;
            }
        }
        return $out;
    }

    // ------------------------------------------------------------------
    // Layer 3 — pattern scrub
    // ------------------------------------------------------------------

    /**
     * Regex-based scrub for secret-shaped content with no known key. Order
     * matters: line-level Authorization redaction first, then assignments
     * (keep key, drop value), then vendor prefixes, long encoded runs, emails.
     */
    public static function patternScrub(string $text): string {
        // Authorization: lines wholesale (any header casing).
        $text = (string)preg_replace(
            '/^.*\bAuthorization\s*:.*$/mi',
            "\u{AB}Authorization line redacted\u{BB}",
            $text
        );
        // PEM private key blocks (#645): the whole block, header to footer. An unterminated
        // block (a truncated log) is cut to the end of the text.
        $text = (string)preg_replace(
            '/-----BEGIN [A-Z0-9 ]*PRIVATE KEY(?: BLOCK)?-----.*?(?:-----END [A-Z0-9 ]*PRIVATE KEY(?: BLOCK)?-----|\z)/s',
            "\u{AB}redacted:pem\u{BB}",
            $text
        );
        // JSON form (#645): "api_key": "value". The lifecycle log and the JSON debug log are
        // JSON, where the key is followed by a quote, so the assignment rule below sees no
        // "=" or ":" after the key name. Keep the key, drop a string value. The escaped
        // form (a JSON line inside a JSON string: \"api_key\":\"value\") is covered too.
        // The (?!) keeps a layer-2 marker intact.
        $text = (string)preg_replace(
            '/("[A-Za-z0-9_.-]*(?:KEY|TOKEN|SECRET|PASSWORD|PASSWD|CREDENTIAL)[A-Za-z0-9_.-]*"\s*:\s*)(?!"\xC2\xAB)"(?:[^"\\\\]|\\\\.)*"/i',
            '$1"' . "\u{AB}redacted\u{BB}" . '"',
            $text
        );
        $text = (string)preg_replace(
            '/(\\\\"[A-Za-z0-9_.-]*(?:KEY|TOKEN|SECRET|PASSWORD|PASSWD|CREDENTIAL)[A-Za-z0-9_.-]*\\\\"\s*:\s*)(?!\\\\"\xC2\xAB)\\\\"(?:[^"\\\\]|\\\\\\\\|\\\\(?!"))*\\\\"/i',
            '$1\\\\"' . "\u{AB}redacted\u{BB}" . '\\\\"',
            $text
        );
        // Flags with the value after a space (#645): --token abc, --api-key abc, --password=abc.
        // A value that starts with "-" is the next flag, not a value.
        $text = (string)preg_replace(
            '/(--[A-Za-z0-9_-]*(?:key|token|secret|password|passwd|credential)[A-Za-z0-9_-]*)(\s+|=)(?!-)(?!\xC2\xAB)("[^"]*"|\'[^\']*\'|\S+)/i',
            '$1$2' . "\u{AB}redacted\u{BB}",
            $text
        );
        // KEY|TOKEN|SECRET|PASSWORD|PASSWD|CREDENTIAL-bearing assignments: keep key, drop value.
        // (?!«) keeps a layer-2 «REDACTED:keyname» marker intact rather than
        // overwriting it with the anonymous «redacted».
        $text = (string)preg_replace(
            '/\b([A-Za-z0-9_.-]*(?:KEY|TOKEN|SECRET|PASSWORD|PASSWD|CREDENTIAL)[A-Za-z0-9_]*)(\s*[=:]\s*)(?!\xC2\xAB)("[^"]*"|\'[^\']*\'|\S+)/i',
            '$1$2' . "\u{AB}redacted\u{BB}",
            $text
        );
        // Bearer <token> (same layer-2 marker guard)
        $text = (string)preg_replace('/\bBearer\s+(?!\xC2\xAB)\S+/i', "Bearer \u{AB}redacted\u{BB}", $text);
        // Vendor token prefixes.
        $text = (string)preg_replace('/\bsk-[A-Za-z0-9_-]{16,}/',            "\u{AB}redacted:sk\u{BB}",   $text); // OpenAI/Anthropic
        $text = (string)preg_replace('/\bgh[pos]_[A-Za-z0-9]{16,}/',         "\u{AB}redacted:gh\u{BB}",   $text); // GitHub ghp_/gho_/ghs_
        $text = (string)preg_replace('/\bxox[abprs]-[A-Za-z0-9-]{10,}/',    "\u{AB}redacted:slack\u{BB}", $text);
        $text = (string)preg_replace('/\bAIza[0-9A-Za-z_-]{30,}/',           "\u{AB}redacted:aiza\u{BB}", $text);
        // #645: short vendor tokens that the long-run rules below never reach.
        $text = (string)preg_replace('/\bglpat-[A-Za-z0-9_-]{20,}/',         "\u{AB}redacted:gitlab\u{BB}", $text); // GitLab personal access token
        $text = (string)preg_replace('/\bgithub_pat_[A-Za-z0-9_]{20,}/',     "\u{AB}redacted:gh\u{BB}",   $text); // GitHub fine-grained token
        $text = (string)preg_replace('/\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/',      "\u{AB}redacted:aws\u{BB}",  $text); // AWS access key id
        $text = (string)preg_replace('/\b[sr]k_(?:live|test)_[A-Za-z0-9]{16,}/', "\u{AB}redacted:stripe\u{BB}", $text);
        $text = (string)preg_replace('/\bnpm_[A-Za-z0-9]{30,}/',             "\u{AB}redacted:npm\u{BB}",  $text);
        // A whole JWT: three dot-separated base64url parts, the first starting with the header "eyJ".
        $text = (string)preg_replace('/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*/', "\u{AB}redacted:jwt\u{BB}", $text);
        // Long encoded runs: base64(url) >= 40 chars, hex >= 40 chars.
        //
        // '/' is a base64 alphabet character, so this rule used to match ACROSS path
        // separators and join short directory names into an imaginary 40-character
        // token: every filesystem path longer than 40 characters without a dot was
        // reported as a secret. In a diagnostics bundle that is noise; in the
        // plugin-management log tool (2026-09-08) it replaced ordinary log lines with
        // «redacted:b64» and made them useless.
        //
        // Evaluate each slash-separated RUN on its own instead. This is a precision
        // fix, not a relaxation: a 40-character opaque segment is still redacted
        // wherever it appears, including inside a path. Only the accidental joining of
        // several short segments stops producing a false positive. A secret long
        // enough to matter does not survive being split at a '/' it does not contain.
        // A run is treated as a path, and split per segment, ONLY when it is
        // path-anchored: it either starts with '/', or reaches its first '/'
        // immediately after an '=' (the shape of every "key=/some/path" our own log
        // writes, e.g. "saveWorkspaces ok: count=6 path=/tmp/..."). '=' is in the
        // base64 alphabet, so without that second case the whole "path=/tmp/..." run
        // is one match that does not begin with '/' and the real log lines this rule
        // exists to protect were still destroyed — found 2026-09-08 by checking an
        // actual log line instead of a hand-written example.
        //
        // Anything NOT path-anchored keeps the original whole-run redaction. That
        // restraint matters: splitting every run would let a base64 secret containing
        // a '/' escape when neither half reached 40 characters, and a 44-character
        // base64 token contains a '/' about half the time. Base64 padding only ever
        // trails a token, so a legitimate secret never shows '=' just before a '/'.
        $text = (string)preg_replace_callback('/[A-Za-z0-9+\/=_-]{40,}/', static function (array $m): string {
            $slash = strpos($m[0], '/');
            $anchored = $slash === 0 || ($slash > 0 && $m[0][$slash - 1] === '=');
            if (!$anchored) return "\u{AB}redacted:b64\u{BB}";   // opaque blob: unchanged strength
            $parts = explode('/', $m[0]);
            foreach ($parts as $i => $part) {
                if (preg_match('/^[A-Za-z0-9+=_-]{40,}$/D', $part)) $parts[$i] = "\u{AB}redacted:b64\u{BB}";
            }
            return implode('/', $parts);
        }, $text);
        $text = (string)preg_replace('/\b[0-9a-fA-F]{40,}\b/',               "\u{AB}redacted:hex\u{BB}",  $text);
        // Emails.
        $text = (string)preg_replace('/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/', "\u{AB}email\u{BB}", $text);
        return $text;
    }

    // ------------------------------------------------------------------
    // Layer 4 — optional strict-anonymize
    // ------------------------------------------------------------------

    /**
     * Stable share map for strict-anonymize: sorted unique share names →
     * share-01..NN. Passing the same share list always yields the same map.
     *
     * @param array<int,string>|null $shares null = enumerate /mnt/user
     * @return array<string,string> sharename => share-NN
     */
    public static function shareMap(?array $shares = null): array {
        if ($shares === null) {
            $shares = [];
            foreach (glob('/mnt/user/*', GLOB_ONLYDIR) ?: [] as $d) {
                $shares[] = basename($d);
            }
        }
        $shares = array_values(array_unique(array_filter(array_map('strval', $shares))));
        sort($shares, SORT_STRING);
        $map = [];
        foreach ($shares as $i => $name) {
            $map[$name] = sprintf('share-%02d', $i + 1);
        }
        return $map;
    }

    /**
     * Strict-anonymize pass: share names (path-context only — /mnt/user/<x>,
     * /mnt/user0/<x>, /mnt/diskN/<x>, /mnt/cache/<x>) via the stable map,
     * hostname → unraid-host, RFC1918 LAN IPs → «ip». Public IPs untouched.
     */
    public static function anonymize(string $text, ?array $shares = null, ?string $hostname = null): string {
        foreach (self::shareMap($shares) as $name => $alias) {
            $text = (string)preg_replace(
                '#(/mnt/(?:user0?|disk[0-9]+|cache)/)' . preg_quote($name, '#') . '(?=/|\s|"|\'|$)#m',
                '$1' . $alias,
                $text
            );
        }
        $hostname = $hostname ?? (string)@php_uname('n');
        if ($hostname !== '' && strlen($hostname) >= 2) {
            $text = str_ireplace($hostname, 'unraid-host', $text);
        }
        // RFC1918: 10/8, 172.16/12, 192.168/16
        $text = (string)preg_replace(
            '/\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3})\b/',
            "\u{AB}ip\u{BB}",
            $text
        );
        return $text;
    }

    // ------------------------------------------------------------------
    // Combined redaction + Layer 5 self-test
    // ------------------------------------------------------------------

    /**
     * Apply layers 2 → 3 → (4) in order. Caller (DiagnosticsService) is
     * responsible for layer 1 (structural allowlist) and layer 5 (assertClean
     * over the final bytes of every bundle file).
     */
    public static function redact(string $text, ?array $knownSecrets = null, bool $anonymize = false): string {
        $knownSecrets = $knownSecrets ?? self::loadKnownSecrets();
        $text = self::knownKeyScrub($text, $knownSecrets);
        $text = self::patternScrub($text);
        if ($anonymize) {
            $text = self::anonymize($text);
        }
        return $text;
    }

    /**
     * Layer 5 self-test: returns the key NAMES whose secret VALUE (or any
     * multiline fragment >= MIN_VALUE_LEN) still appears verbatim in $text.
     * Empty array = clean. Never returns or logs values.
     *
     * @return array<int,string>
     */
    public static function findSurvivors(string $text, array $knownSecrets): array {
        $survivors = [];
        foreach (self::expandSecretValues($knownSecrets) as $key => $values) {
            foreach ($values as $value) {
                if (strpos($text, $value) !== false) {
                    $survivors[] = $key;
                    break;
                }
            }
        }
        return $survivors;
    }

    /**
     * Fail-closed gate: throws when any known secret value survives. The
     * exception message carries key NAMES only.
     *
     * @throws \RuntimeException
     */
    public static function assertClean(string $text, array $knownSecrets, string $label = 'content'): void {
        $survivors = self::findSurvivors($text, $knownSecrets);
        if ($survivors !== []) {
            throw new \RuntimeException(
                "Redaction self-test FAILED for $label: secret value(s) survived for key(s) "
                . implode(', ', $survivors) . ' — bundle build aborted'
            );
        }
    }

    // ------------------------------------------------------------------
    // Internal
    // ------------------------------------------------------------------

    /** parse_ini_file with the same key-shape gate SecretService applies. */
    private static function readIniSafe(string $file): array {
        if ($file === '' || !is_file($file)) return [];
        $parsed = @parse_ini_file($file);
        if (!is_array($parsed)) return [];
        $out = [];
        foreach ($parsed as $k => $v) {
            if (preg_match('/^[A-Z][A-Z0-9_]{1,127}$/D', (string)$k)) {
                $out[$k] = (string)$v;
            }
        }
        return $out;
    }
}
